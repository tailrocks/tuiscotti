# Merged-main CLI check and accept evidence

Collected on native macOS arm64 from Tuiscotti commit `6d01628170de8bed3f00f52713f3a510b782e41e` (merged `origin/main`). The release CLI was built from that exact source with `MBX_GC_AUTO=false`, using `cargo build --release --locked --offline -p tuiscotti-cli`. CLI SHA-256: `4c39bc547a0444e5b41d3ac9f5ddb2aaddcb7b9dca30913d5771208b2a15712c`.

The inputs are the 20 preserved public-writer level-22 outputs: ten `state` and ten `state-and-pixels` samples. They were copied byte-for-byte from the final-source public-writer archive. Each check pass ran all 20 real CLI checks sequentially against byte-identical disposable baselines. Five passes all passed: median full-pass wall 0.598698 s (range 0.575313–0.612106 s), 100 checks total, maximum child RSS 58,736,640 bytes. The artifact directory remained empty and input hashes were unchanged.

Five valid acceptance passes then ran over the same 20 samples (100 accepts total). `CI` was removed from each child environment. Every write was confined to the disposable baseline tree, and every accepted file remained byte-identical to its candidate. Median full-pass wall was 1.946359 s (range 1.809100–2.029665 s), maximum child RSS 171,540,480 bytes. This is feasibility evidence for valid accepts only; it does not measure rejection, real downstream approval review, or captures.

The CLI full-pass wall covers process launches and result verification in the Python runner. Per-child `/usr/bin/time -l` records are included. The host was a Mac17,6, Darwin 27.2, aarch64, 18 logical CPUs; Rust 1.99.1 and MBX 1.29.2. This is native macOS evidence only and must not be used for relative codec rankings. It does not close the codec matrix, real update-history, report, capture, Linux, or cross-platform requirements.

Files:

- `inputs/`: the 20 exact sample containers.
- `check-summary.json`, `accept-summary.json`: aggregate results and scope.
- `raw/check/`, `raw/accept/`: per-invocation CLI JSON and `/usr/bin/time -l` output.
- `run.py`, `run-accept.py`: replayable harnesses. Set `TUISCOTTI_CLI` to a release CLI built from the exact source commit, then run `MBX_GC_AUTO=false python3 run.py` followed by `MBX_GC_AUTO=false python3 run-accept.py`. Both scripts reject a CLI whose SHA-256 differs from the recorded release binary. Set `TUISCOTTI_CLI` to that exact binary; the scripts use the bundled `inputs/` by default and rebuild disposable work/results under the extraction directory.
- `SHA256SUMS`: hashes of all bundle contents except the checksum file itself.

Source worktree was isolated under `/private/tmp/tuiscotti-benchmark-closure-main-20261108`; the primary checkout and feature branch were not edited. Workspace `target/` build products are outside this archive.
