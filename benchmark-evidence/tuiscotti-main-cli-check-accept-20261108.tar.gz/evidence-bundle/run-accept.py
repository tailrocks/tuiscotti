#!/usr/bin/env python3
import hashlib, json, os, pathlib, shutil, subprocess, sys, time

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path(os.environ.get('TUISCOTTI_CHECKOUT', '.')).resolve()
cli = pathlib.Path(os.environ.get('TUISCOTTI_CLI', str(repo / 'target/release/tuiscotti')))
EXPECTED_SOURCE_COMMIT = '6d01628170de8bed3f00f52713f3a510b782e41e'
EXPECTED_CLI_SHA256 = '4c39bc547a0444e5b41d3ac9f5ddb2aaddcb7b9dca30913d5771208b2a15712c'
work = root / 'work'
results = root / 'accept-results'
if results.exists():
    shutil.rmtree(results)
results.mkdir()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

actual_cli_sha256 = sha(cli)
if actual_cli_sha256 != EXPECTED_CLI_SHA256:
    raise SystemExit(f'CLI hash mismatch: expected {EXPECTED_CLI_SHA256}, got {actual_cli_sha256}')

items = []
for sample in sorted((work/'samples').rglob('*.tui.pb')):
    stdout = subprocess.run([str(cli), '--json', 'check', '--sample', str(sample),
                             '--baselines', str(work/'baselines'), '--artifacts', str(work/'artifacts')],
                            capture_output=True, text=True, check=True).stdout
    checked = json.loads(stdout)
    test_id = checked['test_id']
    baseline = work / 'baselines' / (test_id + '.tui.pb')
    digest = sha(sample)
    if digest != sha(baseline):
        raise SystemExit(f'prepared candidate and baseline differ for {test_id}')
    items.append({'sample': sample, 'test_id': test_id, 'candidate_sha256':digest,
                  'baseline': baseline, 'baseline_sha256':sha(baseline)})

summary = {'schema':'tuiscotti.cli-accept-benchmark.v1', 'source_commit':EXPECTED_SOURCE_COMMIT,
           'cli_sha256':actual_cli_sha256, 'sample_count':len(items), 'accept_calls':0, 'passes':[],
           'scope':'Valid accepts of byte-identical sample/baseline pairs only; writes are confined to disposable scratch baselines. CI is unset.'}
for p in range(1, 6):
    ordered = items[p-1:] + items[:p-1]
    pdir = results / f'pass-{p:02d}'
    pdir.mkdir()
    start = time.perf_counter()
    calls = []
    for i, item in enumerate(ordered, 1):
        out = pdir / f'{i:02d}.json'
        timing = pdir / f'{i:02d}.time.txt'
        env = {k:v for k,v in os.environ.items() if k != 'CI'}
        cmd = ['/usr/bin/time', '-l', '-o', str(timing), str(cli), '--json', 'accept',
               '--candidate', str(item['sample']), '--candidate-sha256', item['candidate_sha256'],
               '--expect-baseline', item['baseline_sha256'], '--baselines', str(work/'baselines')]
        proc = subprocess.run(cmd, capture_output=True, text=True, env=env)
        out.write_text(proc.stdout)
        if proc.returncode != 0:
            raise SystemExit(f"accept failed ({proc.returncode}) {item['test_id']}: {proc.stdout} {proc.stderr}")
        result = json.loads(proc.stdout)
        if result.get('status') != 'pass' or result.get('test_id') != item['test_id']:
            raise SystemExit(f"unexpected result {item['test_id']}: {result}")
        calls.append({'test_id':item['test_id'], 'candidate_sha256':item['candidate_sha256'],
                      'accepted_sha256':sha(item['baseline']), 'stdout_sha256':sha(out),
                      'time_file':str(timing.relative_to(root))})
    elapsed = time.perf_counter() - start
    (pdir / 'calls.json').write_text(json.dumps(calls, indent=2) + '\n')
    summary['passes'].append({'pass':p, 'wall_s':round(elapsed,6), 'accepts_passed':len(calls)})
    summary['accept_calls'] += len(calls)
summary['all_passed'] = True
summary['all_accepted_bytes_equal_candidate'] = all(
    sha(item['sample']) == sha(item['baseline']) for item in items)
summary['baseline_count'] = sum(1 for x in (work/'baselines').rglob('*.tui.pb'))
summary['artifacts_written'] = sum(1 for x in (work/'artifacts').rglob('*') if x.is_file())
(root/'accept-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
