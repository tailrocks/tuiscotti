#!/usr/bin/env python3
import hashlib, json, os, pathlib, shutil, subprocess, sys, time

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path(os.environ.get('TUISCOTTI_CHECKOUT', '.')).resolve()
cli = pathlib.Path(os.environ.get('TUISCOTTI_CLI', str(repo / 'target/release/tuiscotti')))
source = pathlib.Path(os.environ.get('TUISCOTTI_BENCH_INPUT', str(root / 'inputs')))
EXPECTED_SOURCE_COMMIT = '6d01628170de8bed3f00f52713f3a510b782e41e'
EXPECTED_CLI_SHA256 = '4c39bc547a0444e5b41d3ac9f5ddb2aaddcb7b9dca30913d5771208b2a15712c'
records = json.loads((source / 'codec-source-records.json').read_text())['records']
work = root / 'work'
results = root / 'results'
if work.exists():
    shutil.rmtree(work)
if results.exists():
    shutil.rmtree(results)
(work / 'samples').mkdir(parents=True)
(work / 'baselines').mkdir()
(work / 'artifacts').mkdir()
results.mkdir()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

actual_cli_sha256 = sha(cli)
if actual_cli_sha256 != EXPECTED_CLI_SHA256:
    raise SystemExit(f'CLI hash mismatch: expected {EXPECTED_CLI_SHA256}, got {actual_cli_sha256}')

prepared = []
for record in records:
    name = record['sample_file'].replace('.json', '.tui.pb')
    src = source / name
    test_id = record['test_id']
    candidate = work / 'samples' / name
    baseline = work / 'baselines' / (test_id + '.tui.pb')
    candidate.parent.mkdir(parents=True, exist_ok=True)
    baseline.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, candidate)
    shutil.copyfile(src, baseline)
    prepared.append({'name': name, 'test_id': test_id, 'gate': record['gate'],
                     'input_sha256': sha(src), 'candidate': candidate, 'baseline': baseline})

host = subprocess.run(['/usr/sbin/sysctl', '-n', 'hw.model'], capture_output=True, text=True, check=True).stdout.strip()
cpu = subprocess.run(['/usr/sbin/sysctl', '-n', 'hw.logicalcpu'], capture_output=True, text=True, check=True).stdout.strip()
summary = {'schema':'tuiscotti.cli-check-benchmark.v1', 'source_commit':EXPECTED_SOURCE_COMMIT,
           'cli_sha256':actual_cli_sha256, 'host_model':host, 'logical_cpus':int(cpu), 'platform':sys.platform,
           'sample_count':len(prepared), 'gate_counts':{}, 'passes':[],
           'scope':'Each sample is checked against a byte-identical copy in a disposable baseline tree. No accept is invoked; artifact directory is expected to stay empty.'}
for item in prepared:
    summary['gate_counts'][item['gate']] = summary['gate_counts'].get(item['gate'], 0) + 1

for p in range(1, 6):
    ordered = prepared[p-1:] + prepared[:p-1]
    pdir = results / f'pass-{p:02d}'
    pdir.mkdir()
    start = time.perf_counter()
    checks = []
    for i, item in enumerate(ordered, 1):
        stdout = pdir / f'{i:02d}.json'
        timing = pdir / f'{i:02d}.time.txt'
        cmd = ['/usr/bin/time', '-l', '-o', str(timing), str(cli), '--json', 'check',
               '--sample', str(item['candidate']), '--baselines', str(work / 'baselines'),
               '--artifacts', str(work / 'artifacts')]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        stdout.write_text(proc.stdout)
        if proc.returncode != 0:
            raise SystemExit(f"check failed ({proc.returncode}) {item['test_id']}: {proc.stdout} {proc.stderr}")
        result = json.loads(proc.stdout)
        if result.get('status') != 'pass' or result.get('test_id') != item['test_id']:
            raise SystemExit(f"unexpected result {item['test_id']}: {result}")
        checks.append({'test_id':item['test_id'], 'gate':item['gate'], 'sha256':result.get('candidate_sha256'),
                       'stdout_sha256':sha(stdout), 'time_file':str(timing.relative_to(root))})
    elapsed = time.perf_counter() - start
    (pdir / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    summary['passes'].append({'pass':p, 'wall_s':round(elapsed, 6), 'checks_passed':len(checks),
                              'state':sum(c['gate']=='state' for c in checks),
                              'state_and_pixels':sum(c['gate']=='state-and-pixels' for c in checks)})

summary['all_passed'] = True
summary['artifacts_written'] = sum(1 for x in (work/'artifacts').rglob('*') if x.is_file())
summary['input_hashes_unchanged'] = all(sha(source / item['name']) == item['input_sha256'] for item in prepared)
summary['baseline_count'] = sum(1 for x in (work/'baselines').rglob('*.tui.pb'))
summary['candidate_count'] = sum(1 for x in (work/'samples').rglob('*.tui.pb'))
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('passes',)}, indent=2))
