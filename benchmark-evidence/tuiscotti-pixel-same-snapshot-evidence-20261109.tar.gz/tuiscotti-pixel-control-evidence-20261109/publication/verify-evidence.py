#!/usr/bin/env python3
import base64,hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
fail=[];checked=0;deferred=[]
ledger=json.loads((root/'publication/reproduction-ledger.json').read_text())
excluded={x['path']:x['sha256'] for x in ledger['omitted_compiled_binaries']}
entries={}
for line in (root/'evidence-files.sha256').read_text().splitlines():
 expected,rel=line.split('  ',1);entries[rel]=expected;p=root/rel
 if rel in excluded:
  if expected!=excluded[rel]:fail.append('ledger hash mismatch: '+rel)
  if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()!=expected:fail.append('binary mismatch: '+rel)
  if not p.exists():deferred.append(rel)
  else:checked+=1
  continue
 if not p.is_file():fail.append('missing: '+rel);continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:fail.append('hash mismatch: '+rel)
 checked+=1
if set(excluded)!={p for p in entries if p.startswith('targets/cargo-target/release/')} :fail.append('binary ledger path set mismatch')
for rel,expected in excluded.items():
 if rel not in entries or entries[rel]!=expected:fail.append('omitted binary not bound by evidence manifest: '+rel)
# Check all archive payload checksums.
for line in (root/'SHA256SUMS').read_text().splitlines():
 expected,rel=line.split('  ',1);p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:fail.append('archive payload checksum mismatch: '+rel)
# Verify commit-source archives against their recorded SHA-256.
for name,info in ledger['source_archives'].items():
 p=root/info['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=info['sha256']:fail.append('source archive hash mismatch: '+name)
resolution=json.loads((root/ledger['public_git_commit_resolution']['path']).read_text())
if hashlib.sha256((root/ledger['public_git_commit_resolution']['path']).read_bytes()).hexdigest()!=ledger['public_git_commit_resolution']['sha256']:fail.append('public Git record hash mismatch')
if resolution['repository']!='https://github.com/tailrocks/tuiscotti':fail.append('unexpected public Git repository')
expected=[('d8d54155947f6303a41dfd6079b53c0abc16f29a','1e421b2e95c368efc14293fe156bef423539481b'),('92ef2d9ee082b35f68e066c5129fedbf07675a80','d8b16a10c7cfb783c55d10f68321984db14e8df8')]
if [(x['commit'],x['tree']) for x in resolution['resolved']]!=expected:fail.append('public Git commit/tree resolution mismatch')
for name,rev in [('old','d8d54155947f6303a41dfd6079b53c0abc16f29a'),('new','92ef2d9ee082b35f68e066c5129fedbf07675a80')]:
 manifest=(root/f'control-src/{name}/Cargo.toml').read_text()
 lock=(root/f'control-src/{name}/Cargo.lock').read_text()
 if rev not in manifest or rev not in lock:fail.append('Cargo source pin mismatch: '+name)
# Validate the full recorded run-result/provenance/log/input/marker chain.
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def archived_path(recorded):
 token='/run/'
 if token not in recorded:raise ValueError('recorded path is outside original scratch: '+recorded)
 rel=recorded.split(token,1)[1]
 return root/rel
def validate_run(kind,outer_name,manifest_name,inner_marker_name,manifest_key,inner_path_key,inner_hash_key,input_map_key):
 base=root/kind;outer=json.loads((base/outer_name).read_text());result_path=base/'run-result.json';prov_path=base/'provenance-before.json'
 if digest(result_path)!=outer.get('run_result_sha256'):fail.append('outer run-result hash mismatch: '+kind)
 result=json.loads(result_path.read_text());prov=json.loads(prov_path.read_text())
 if result.get('exit')!=0:fail.append('run did not exit successfully: '+kind)
 if digest(prov_path)!=result.get('provenance_before_sha256'):fail.append('run provenance hash mismatch: '+kind)
 for log,key in [('stdout.log','stdout_sha256'),('stderr.log','stderr_sha256')]:
  if digest(base/log)!=result.get(key):fail.append('run '+log+' hash mismatch: '+kind)
 command=prov.get('command',[])
 source_records=prov.get('files_sha256',prov.get('source_and_parent_sha256',{}))
 if len(command)<3 or command[:2]!=['/usr/bin/sandbox-exec','-f']:fail.append('run command lacks recorded Seatbelt wrapper: '+kind)
 profile_hash=prov.get('sandbox_profile_sha256') or source_records.get(command[2] if len(command)>2 else '')
 if not command or not profile_hash or digest(archived_path(command[2]))!=profile_hash:fail.append('sandbox profile binding mismatch: '+kind)
 for label,item in prov.get('inputs',{}).items():
  try:
   input_path=archived_path(item['path'])
   actual=digest(input_path) if input_path.is_file() else excluded.get(item['path'].split('/run/',1)[-1])
   if actual!=item['sha256']:fail.append('provenance named input hash mismatch: '+kind+' '+label)
  except (ValueError,OSError,KeyError) as e:fail.append(str(e))
 for recorded,expected_hash in source_records.items():
  try:
   p=archived_path(recorded)
   if p.is_file():actual=digest(p)
   elif recorded in excluded:actual=excluded[recorded]
   else:fail.append('missing provenance input: '+recorded);continue
   if actual!=expected_hash:fail.append('provenance input hash mismatch: '+recorded)
  except (ValueError,OSError) as e:fail.append(str(e))
 identities=json.loads((root/'source-identities.json').read_text())
 before=prov.get('sources',prov.get('source_identities',{}));after=result.get('sources_after',result.get('source_identities_after',{}))
 for label in ('old','new'):
  expected=identities[label]
  for group,entry in [('provenance',before.get(label,{})),('run result',after.get(label,{}))]:
   if entry.get('head')!=expected['head'] or entry.get('tracked_status',entry.get('tracked_and_untracked_status'))!='':fail.append(kind+' '+group+' source identity mismatch: '+label)
 manifest=root/manifest_name;inner=root/inner_marker_name
 mhash=digest(manifest);ihash=digest(inner)
 if outer.get(manifest_key)!=mhash:fail.append('outer manifest hash mismatch: '+kind)
 if outer.get(inner_path_key,'').split('/run/',1)[-1]!=inner_marker_name:fail.append('outer inner-marker path mismatch: '+kind)
 if outer.get(inner_hash_key)!=ihash:fail.append('outer inner-marker hash mismatch: '+kind)
 if inner.read_text().strip()!=mhash:fail.append('inner marker does not bind manifest: '+kind)
validate_run('comparison-run','RUN_SUCCESS','pixel-comparison/pair-manifest.json','pixel-comparison/SUCCESS','inner_manifest_sha256','inner_success_path','inner_success_sha256','files_sha256')
validate_run('negative-controls-run','RUN_SUCCESS','negative-controls/control-manifest.json','negative-controls/CONTROL_SUCCESS','control_manifest_sha256','control_success_path','control_success_sha256','source_and_parent_sha256')
pair=json.loads((root/'pixel-comparison/pair-manifest.json').read_text())
if pair.get('complete_fields_including_metadata_contract_png_and_rgba_equal') is not True:fail.append('pair equality flag is false')
old=json.loads((root/'pixel-comparison/old-reader.projection.json').read_text())['sample']
new=json.loads((root/'pixel-comparison/new-reader.projection.json').read_text())['sample']
if old!=new:fail.append('typed reader projections differ')
if old.get('snapshot',{}).get('metadata')!=new.get('snapshot',{}).get('metadata'):fail.append('metadata projections differ')
image=old.get('image') or {};png=base64.b64decode(image.get('png_base64',''),validate=True);rgba=base64.b64decode(image.get('rgba_base64',''),validate=True)
if hashlib.sha256(png).hexdigest()!=pair['png_sha256'] or pair['png_sha256']!=pair['computed_png_sha256']:fail.append('PNG digest mismatch')
if hashlib.sha256(rgba).hexdigest()!=pair['rgba_sha256'] or pair['rgba_sha256']!=pair['computed_rgba_sha256']:fail.append('RGBA digest mismatch')
if image.get('png_sha256')!=pair['png_sha256'] or image.get('rgba_sha256')!=pair['rgba_sha256']:fail.append('projection image digests differ')
builds=ledger['build_records']
binary_roles={
 'targets/cargo-target/release/pixel-same-snapshot-old':'old-writer',
 'targets/cargo-target/release/pixel-same-snapshot-new':'new-writer',
 'targets/cargo-target/release/tuiscotti-old-pair-projection':'old-reader',
 'targets/cargo-target/release/tuiscotti-new-pair-projection':'new-reader',
 'targets/cargo-target/release/showcase':'tcb-showcase',
 'targets/cargo-target/release/tuiscotti-bench-producer-old':'live-producer',
}
for rel,role in binary_roles.items():
 if excluded.get(rel)!=builds[role]['executable_sha256_after']:fail.append('binary/build record hash mismatch: '+rel)
pair=json.loads((root/'pixel-comparison/pair-manifest.json').read_text())
for label,role in [('old_writer','old-writer'),('new_writer','new-writer'),('old_reader','old-reader'),('new_reader','new-reader')]:
 if pair['executables'][label]['sha256']!=builds[role]['executable_sha256_after']:fail.append('pair/build record hash mismatch: '+label)
producer=json.loads((root/'capture/produced-retry/samples/showcase-home-120x40.record.json').read_text())
if producer['binary_sha256']!=builds['tcb-showcase']['executable_sha256_after']:fail.append('producer TCB executable hash mismatch')
producer_run=json.loads((root/'capture/producer-provenance-before.json').read_text())
if producer_run['inputs_sha256'][builds['live-producer']['executable']]!=builds['live-producer']['executable_sha256_after']:fail.append('live producer executable hash mismatch')
audit=json.loads((root/'same-snapshot-audit.json').read_text())
if audit['producer_reference']['tcb_revision']!='60b5fb2762d91a3549bd4ac63b1d77d534ee53d2':fail.append('TCB revision mismatch')
if audit['producer_reference']['tuiscotti_revision']!='d8d54155947f6303a41dfd6079b53c0abc16f29a':fail.append('Tuiscotti revision mismatch')
print(f'checked={checked} deferred_binaries={len(deferred)} failures={len(fail)}')
print('deferred='+','.join(deferred))
print('\n'.join(fail))
if fail:sys.exit(1)
