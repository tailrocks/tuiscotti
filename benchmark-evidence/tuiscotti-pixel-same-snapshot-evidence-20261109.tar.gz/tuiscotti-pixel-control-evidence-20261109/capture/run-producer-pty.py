import hashlib,json,os,platform,subprocess,sys
from pathlib import Path
s=Path('/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run')
exe=s/'targets/cargo-target/release/tuiscotti-bench-producer-old'
manifest=s/'capture/manifests/scenario-one.json'
binroot=s/'targets/cargo-target/release'
out=s/'capture/produced-retry'
snapshots=s/'capture/snapshots-retry'
if out.exists() or snapshots.exists(): raise SystemExit('fresh output roots required')
home=s/'capture/producer-home-retry'; home.mkdir(parents=True)
env={'HOME':str(home),'PATH':'/usr/bin:/bin','TMPDIR':str(s/'env/tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','PIXEL_CONTROL_SNAPSHOT_ROOT':str(snapshots)}
cmd=['/usr/bin/sandbox-exec','-f',str(s/'env/sandbox-pty.sb'),'--','/usr/bin/env','-i',*[f'{k}={v}' for k,v in env.items()],str(exe),'tcb-reference-pixel-control','d8d54155947f6303a41dfd6079b53c0abc16f29a',str(manifest),str(binroot),str(out)]
record={'command':cmd,'cwd':str(s/'tcb-source'),'environment':env,'platform':{'machine':platform.machine(),'system':platform.system(),'python':sys.version,'executable':sys.executable},'inputs_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [exe,manifest,s/'tcb-source/Cargo.lock',s/'capture/producer/Cargo.lock',s/'control-src/producer-snapshot-tee.rs',s/'control-src/producer-reference.rs',s/'env/sandbox-pty.sb']},'tcb_commit':subprocess.check_output(['/usr/bin/git','-C',str(s/'tcb-source'),'rev-parse','HEAD'],text=True).strip(),'tuiscotti_commit':'d8d54155947f6303a41dfd6079b53c0abc16f29a'}
(s/'capture/producer-provenance-before.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
r=subprocess.run(cmd,cwd=s/'tcb-source',capture_output=True,text=True,timeout=240)
(s/'capture/producer.stdout.log').write_text(r.stdout);(s/'capture/producer.stderr.log').write_text(r.stderr)
result={'exit':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr.encode()).hexdigest(),'provenance_sha256':hashlib.sha256((s/'capture/producer-provenance-before.json').read_bytes()).hexdigest()}
(s/'capture/producer-result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
raise SystemExit(r.returncode)
