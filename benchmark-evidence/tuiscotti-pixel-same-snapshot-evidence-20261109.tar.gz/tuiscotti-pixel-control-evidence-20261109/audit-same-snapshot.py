import base64,hashlib,json,subprocess
from pathlib import Path
s=Path('/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run')
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha(p):return sha_bytes(Path(p).read_bytes())
snapshot_path=s/'capture/snapshots-retry/showcase-home-120x40.snapshot.json'
snapshot=json.loads(snapshot_path.read_bytes())
pair_path=s/'pixel-comparison/pair-manifest.json';pair=json.loads(pair_path.read_text())
old=json.loads((s/'pixel-comparison/old-reader.projection.json').read_text())
new=json.loads((s/'pixel-comparison/new-reader.projection.json').read_text())
old_sample=old['sample'];new_sample=new['sample']
assert old_sample==new_sample
assert old_sample['gate']=='state-and-pixels'
expected_metadata=dict(snapshot['metadata']); expected_metadata['captured_at_ms']=str(expected_metadata['captured_at_ms']); expected_metadata['revision']=str(expected_metadata['revision'])
assert old_sample['snapshot']['metadata']==expected_metadata
assert new_sample['snapshot']['metadata']==expected_metadata
assert old_sample['image']==new_sample['image']
img=old_sample['image'];png=base64.b64decode(img['png_base64'],validate=True);rgba=base64.b64decode(img['rgba_base64'],validate=True)
assert sha_bytes(png)==img['png_sha256']==img['png_sha256_computed']==pair['png_sha256']==pair['computed_png_sha256']
assert sha_bytes(rgba)==img['rgba_sha256']==img['rgba_sha256_computed']==pair['rgba_sha256']==pair['computed_rgba_sha256']
assert img['png_sha256_matches'] and img['rgba_sha256_matches'] and img['dimensions_match']
assert img['width']*img['height']*4==len(rgba)
record=json.loads((s/'capture/produced-retry/samples/showcase-home-120x40.record.json').read_text())
assert record['png_sha256']==pair['png_sha256'] and record['rgba_sha256']==pair['rgba_sha256']
assert record['snapshot_projection_sha256']
manifest=json.loads((s/'negative-controls/control-manifest.json').read_text())
assert len(manifest['cases'])==4 and {x['case'] for x in manifest['cases']}=={'metadata','text','style','palette'}
by={x['case']:x for x in manifest['cases']}
assert by['metadata']['state_digest_equal'] and by['metadata']['difference_paths']==['/snapshot/metadata/captured_at_ms']
assert not by['text']['state_digest_equal'] and by['text']['png_sha256']!=pair['png_sha256'] and by['text']['rgba_sha256']!=pair['rgba_sha256']
result={
 'schema':'same-snapshot-pixel-control-audit.v1',
 'scope':'one fresh live macOS arm64 capture; paired old/new public Sample writers/readers; no baseline acceptance',
 'snapshot':{'path':str(snapshot_path),'sha256':sha(snapshot_path),'metadata_source_json':snapshot['metadata'],'metadata_source_canonical_json_sha256':sha_bytes(json.dumps(snapshot['metadata'],sort_keys=True,separators=(',',':')).encode()),'metadata_reader_projection':expected_metadata,'metadata_reader_projection_canonical_json_sha256':sha_bytes(json.dumps(expected_metadata,sort_keys=True,separators=(',',':')).encode())},
 'source_revisions':{'old':'d8d54155947f6303a41dfd6079b53c0abc16f29a','new':'92ef2d9ee082b35f68e066c5129fedbf07675a80','capture_tcb':'60b5fb2762d91a3549bd4ac63b1d77d534ee53d2'},
 'pair':{'test_id':pair['test_id'],'equal_complete_projection':pair['complete_fields_including_metadata_contract_png_and_rgba_equal'],'old_sample_sha256':pair['old_sample_sha256'],'new_sample_sha256':pair['new_sample_sha256'],'state_digest':pair['state_digest'],'metadata_equal_to_capture':True,'render_contract_equal':True,'png_sha256':pair['png_sha256'],'rgba_sha256':pair['rgba_sha256'],'png_dimensions':[img['width'],img['height']],'png_bytes_sha256_recomputed':sha_bytes(png),'rgba_bytes_sha256_recomputed':sha_bytes(rgba),'rgba_length':len(rgba)},
 'producer_reference':{'binary_sha256':record['binary_sha256'],'tcb_revision':'60b5fb2762d91a3549bd4ac63b1d77d534ee53d2','tuiscotti_revision':record['tuiscotti_revision'],'producer_record':str(s/'capture/produced-retry/samples/showcase-home-120x40.record.json')},
 'negative_controls':{'outer_run_success':(s/'negative-controls-run/RUN_SUCCESS').is_file(),'cases':{name:{'difference_count':v['difference_count'],'difference_paths':v['difference_paths'],'state_digest_equal':v['state_digest_equal'],'png_sha256':v['png_sha256'],'rgba_sha256':v['rgba_sha256']} for name,v in by.items()}},
 'markers':{'comparison_run_success_sha256':sha(s/'comparison-run/RUN_SUCCESS'),'pair_success_sha256':sha(s/'pixel-comparison/SUCCESS'),'negative_control_run_success_sha256':sha(s/'negative-controls-run/RUN_SUCCESS'),'negative_control_success_sha256':sha(s/'negative-controls/CONTROL_SUCCESS')}
}
(s/'same-snapshot-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
