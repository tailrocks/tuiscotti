#!/bin/sh
set -eu
SCR=/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run
export HOME="$SCR/env/home"
export PATH=/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run/cache/mise-data/installs/mr-boxington/1.29.2/.mise-bins:/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run/cache/cargo-home/bin:/usr/bin:/bin:/Users/donbeave/.local/bin
export TMPDIR="$SCR/env/tmp"
export MISE_DATA_DIR="$SCR/cache/mise-data"
export MISE_CACHE_DIR="$SCR/cache/mise-cache"
export MISE_STATE_DIR="$SCR/cache/mise-state"
export MISE_CONFIG_DIR="$SCR/cache/mise-config"
export MISE_CONFIG_FILE="$SCR/control-src/mise-min.toml"
export MISE_AUTO_INSTALL=0
export MISE_TRUSTED_CONFIG_PATHS="$SCR/control-src"
export CARGO_HOME="$SCR/cache/cargo-home"
export CARGO_TARGET_DIR="$SCR/targets/cargo-target"
export CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE:-true}
export RUSTUP_HOME="$SCR/cache/rustup-home"
export MBX_CACHE_DIR="$SCR/cache/mbx-cache"
export MBX_TARGET_ROOT="$SCR/targets/mbx-target"
export MBX_GC_AUTO=0
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null
export GIT_TERMINAL_PROMPT=0
mkdir -p "$HOME" "$TMPDIR"
cd "$SCR/control-src"
exec /Users/donbeave/.local/bin/mise "$@"
