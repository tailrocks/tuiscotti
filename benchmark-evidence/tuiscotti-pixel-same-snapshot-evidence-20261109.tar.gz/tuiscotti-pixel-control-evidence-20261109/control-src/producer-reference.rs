use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::Duration;

use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use tui_test::{
    render::style::Style, AutomaticRecording, Backend, LaunchEnvMode, LaunchOptions,
    RunOptions, Session, SnapshotScope, Timeouts,
    WaitQuietOptions,
};
use tui_test::profile::Profile as TerminalProfile;
use tuiscotti::{render_profile, sample::{Observation, Sample}, SAMPLE_SCHEMA};

#[derive(Debug, Deserialize)]
struct Manifest {
    schema: String,
    capture_host: String,
    inputs: Vec<Input>,
}

#[derive(Debug, Deserialize)]
struct Input {
    id: String,
    binary: String,
    args: Vec<String>,
    cols: u16,
    rows: u16,
    client_platform: String,
}

fn sha256(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn write(path: &Path, bytes: &[u8]) -> Result<(), Box<dyn std::error::Error>> {
    if let Some(parent) = path.parent() { fs::create_dir_all(parent)?; }
    fs::write(path, bytes)?;
    Ok(())
}

fn canonical_json<T: serde::Serialize>(value: &T) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
    Ok(serde_json::to_vec(value)?)
}

fn capture(input: &Input, binary_root: &Path, output: &Path, producer: &str, revision: &str) -> Result<(), Box<dyn std::error::Error>> {
    let binary = binary_root.join(&input.binary);
    let binary_bytes = fs::read(&binary)?;
    let home = output.join("homes").join(&input.id);
    fs::create_dir_all(&home)?;
    for name in ["config", "cache", "data"] { fs::create_dir_all(home.join(name))?; }

    let launch = LaunchOptions::new(&binary)
        .with_args(input.args.iter().cloned())
        .with_cwd(&home)
        .with_env_mode(LaunchEnvMode::Cleared)
        .with_env("HOME", &home)
        .with_env("XDG_CONFIG_HOME", home.join("config"))
        .with_env("XDG_CACHE_HOME", home.join("cache"))
        .with_env("XDG_DATA_HOME", home.join("data"))
        .with_env("SHELL", "/bin/sh")
        .with_env("PATH", "/usr/bin:/bin")
        .with_env("TERM", "xterm-256color")
        .with_env("COLORTERM", "truecolor")
        .with_env("LANG", "C.UTF-8")
        .with_env("LC_ALL", "C.UTF-8")
        .with_env("TZ", "UTC")
        .with_env("JUNIE_TUI_CLIENT_PLATFORM", &input.client_platform)
        .with_env("HOLLA_NO_HISTORY", "1");

    let session = Session::new(format!("tuiscotti-bench-{}", input.id));
    session.spawn_with(launch, RunOptions {
        backend: Backend::default(),
        program: binary.to_string_lossy().into_owned(),
        args: input.args.clone(),
        profile: TerminalProfile::default(),
        cols: input.cols,
        rows: input.rows,
        cwd: Some(home.to_string_lossy().into_owned()),
        env: Vec::new(),
        wait_ready: None,
        restart: false,
        timeouts: Timeouts::default(),
        recording: AutomaticRecording::default(),
        style: Style::default(),
    })?;
    let quiet = WaitQuietOptions::new(Duration::from_secs(15), Duration::from_millis(500))?;
    session.wait_quiet(&quiet)?;
    let snapshot = session.capture_snapshot(SnapshotScope::ActiveScreen)?;
    session.close()?;

    let mut snapshot_projection: serde_json::Value = serde_json::to_value(&snapshot)?;
    if let Some(object) = snapshot_projection.as_object_mut() { object.remove("metadata"); }
    let snapshot_projection_bytes = canonical_json(&snapshot_projection)?;
    let state_id = format!("bench/{}", input.id);
    let state = Sample::state(&state_id, snapshot.clone(), Observation::empty())?;
    let state_bytes = state.to_bytes()?;
    let state_projection = json!({
        "gate": "state",
        "snapshot": snapshot_projection,
    });
    let state_projection_bytes = canonical_json(&state_projection)?;

    let profile = render_profile::resolve_profile("tuiscotti-pinned-v1")?;
    let pixel_id = format!("{state_id}/pixels-{}", render_profile::platform_key());
    let pixels = Sample::with_pixels(&pixel_id, &snapshot, Observation::empty(), profile)?;
    let pixels_bytes = pixels.to_bytes()?;
    let image = pixels.image().ok_or("pixel sample missing image")?;
    let contract = pixels.render_contract().ok_or("pixel sample missing render contract")?;
    let pixels_projection = json!({
        "gate": "state-and-pixels",
        "snapshot": snapshot_projection,
        "render_contract": contract,
        "rgba_sha256": image.rgba_sha256(),
    });
    let pixels_projection_bytes = canonical_json(&pixels_projection)?;

    let base = output.join("samples").join(&input.id);
    write(&base.with_extension("state.json"), &state_bytes)?;
    write(&base.with_extension("pixels.json"), &pixels_bytes)?;
    write(&base.with_extension("state.projection.json"), &state_projection_bytes)?;
    write(&base.with_extension("pixels.projection.json"), &pixels_projection_bytes)?;
    let record = json!({
        "schema": "tuiscotti-real-capture-record.v1",
        "tuiscotti_schema": SAMPLE_SCHEMA,
        "producer": producer,
        "tuiscotti_revision": revision,
        "tui_test_version": "0.2.1",
        "scenario_id": input.id,
        "binary": input.binary,
        "binary_sha256": sha256(&binary_bytes),
        "argv": input.args,
        "cols": input.cols,
        "rows": input.rows,
        "client_platform": input.client_platform,
        "platform_key": render_profile::platform_key(),
        "snapshot_projection_sha256": sha256(&snapshot_projection_bytes),
        "state_domain_projection_sha256": sha256(&state_projection_bytes),
        "pixels_domain_projection_sha256": sha256(&pixels_projection_bytes),
        "png_sha256": image.png_sha256(),
        "rgba_sha256": image.rgba_sha256(),
        "png_width": image.width(),
        "png_height": image.height(),
        "render_profile": profile.name(),
        "render_policy": render_profile::Profile::raster_policy(),
        "render_contract": serde_json::to_value(contract)?,
        "state_bytes": state_bytes.len(),
        "pixels_bytes": pixels_bytes.len(),
    });
    write(&base.with_extension("record.json"), &serde_json::to_vec_pretty(&record)?)?;
    Ok(())
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args = env::args_os().skip(1);
    let producer = args.next().ok_or("usage: producer PRODUCER REVISION MANIFEST BINARY_ROOT OUTPUT_DIR")?.to_string_lossy().into_owned();
    let revision = args.next().ok_or("usage: producer PRODUCER REVISION MANIFEST BINARY_ROOT OUTPUT_DIR")?.to_string_lossy().into_owned();
    let manifest_path = PathBuf::from(args.next().ok_or("usage: producer PRODUCER REVISION MANIFEST BINARY_ROOT OUTPUT_DIR")?);
    let binary_root = PathBuf::from(args.next().ok_or("usage: producer PRODUCER REVISION MANIFEST BINARY_ROOT OUTPUT_DIR")?);
    let output = PathBuf::from(args.next().ok_or("usage: producer PRODUCER REVISION MANIFEST BINARY_ROOT OUTPUT_DIR")?);
    let manifest_bytes = fs::read(&manifest_path)?;
    let manifest: Manifest = serde_json::from_slice(&manifest_bytes)?;
    if manifest.schema != "tuiscotti-real-capture-bench.v1" { return Err("unexpected manifest schema".into()); }
    fs::create_dir_all(&output)?;
    write(&output.join("input-manifest.json"), &manifest_bytes)?;
    let mut records = Vec::new();
    for input in &manifest.inputs {
        capture(input, &binary_root, &output, &producer, &revision)?;
        records.push(input.id.as_str());
    }
    write(&output.join("producer-complete.json"), &serde_json::to_vec_pretty(&json!({
        "schema":"tuiscotti-producer-complete.v1",
        "producer":producer,
        "tuiscotti_revision":revision,
        "capture_host":manifest.capture_host,
        "scenario_ids":records,
        "manifest_sha256":sha256(&manifest_bytes)
    }))?)?;
    Ok(())
}
