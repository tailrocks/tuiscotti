#!/usr/bin/env python3
"""Write old/new pixel samples from one upstream snapshot, compare their full domains."""
import argparse, hashlib, json, os, re, subprocess
from pathlib import Path
from oracle_protocol import read_exact, send_request, validate_projection, validate_worker_response, compare_paths
OLD='d8d54155947f6303a41dfd6079b53c0abc16f29a'
NEW='92ef2d9ee082b35f68e066c5129fedbf07675a80'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024): h.update(b)
    return h.hexdigest()

def projection(worker,rev,sample,test_id,out,label):
    p=subprocess.Popen([str(worker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
    try:
        send_request(p,0,test_id,sample)
        header=read_exact(p.stdout,8,30.0)
        if header is None or len(header)!=8: raise RuntimeError('reader frame header missing or truncated')
        size=int.from_bytes(header,'big')
        if size > 512*1024*1024: raise RuntimeError('reader frame exceeds limit')
        payload=read_exact(p.stdout,size,30.0)
        if payload is None or len(payload)!=size: raise RuntimeError('reader frame payload missing or truncated')
        (out/f'{label}-reader.frame').write_bytes(header+payload)
        value=json.loads(payload)
        if not isinstance(value,dict): raise RuntimeError('reader frame must be an object')
        p.stdin.close(); p.stdin=None
        extra,err=p.communicate(timeout=30)
        (out/f'{label}-reader.stderr').write_bytes(err)
        if extra: raise RuntimeError('reader returned unexpected trailing stdout')
        (out/f'{label}-reader.projection.json').write_text(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n')
        validate_worker_response(value,0,test_id,rev)
        if p.returncode or value.get('ok') is not True: raise RuntimeError(f'projection failed: {err!r} {value}')
        if value.get('original_file_sha256') != sha(sample): raise RuntimeError('projection input hash mismatch')
        return value,validate_projection(value,test_id,rev)
    finally:
        if p.poll() is None: p.kill(); p.wait()

def main():
    ap=argparse.ArgumentParser(allow_abbrev=False)
    for flag in ('snapshot','snapshot-sha','test-id','old-writer','old-writer-sha','new-writer','new-writer-sha','old-reader','old-reader-sha','new-reader','new-reader-sha','out'): ap.add_argument('--'+flag,required=True)
    a=ap.parse_args(); scratch=Path(os.environ['PIXEL_CONTROL_SCRATCH']).resolve(strict=True)
    snapshot=Path(a.snapshot).resolve(strict=True); snapshot.relative_to(scratch)
    if not re.fullmatch('[0-9a-f]{64}',a.snapshot_sha) or sha(snapshot)!=a.snapshot_sha: raise RuntimeError('snapshot hash mismatch')
    binaries=[]
    binary_expected=[]
    for path,expected in ((a.old_writer,a.old_writer_sha),(a.new_writer,a.new_writer_sha),(a.old_reader,a.old_reader_sha),(a.new_reader,a.new_reader_sha)):
        p=Path(path).resolve(strict=True)
        if not re.fullmatch('[0-9a-f]{64}',expected) or sha(p)!=expected: raise RuntimeError(f'executable hash mismatch: {p}')
        binaries.append(p)
        binary_expected.append(expected)
    out=Path(a.out).resolve(); out.relative_to(scratch); out.mkdir(parents=True,exist_ok=False)
    (out/'INCOMPLETE').write_text('No result until SUCCESS exists.\n')
    paths=[out/'old.tui.json',out/'new.tui.pb']
    for label,writer,target in zip(('old','new'),binaries[:2],paths):
        r=subprocess.run([str(writer),a.test_id,str(snapshot),str(target)],capture_output=True,text=True,timeout=120)
        (out/f'{label}-writer.stdout').write_text(r.stdout)
        (out/f'{label}-writer.stderr').write_text(r.stderr)
        if r.returncode != 0: raise RuntimeError(f'{label} writer failed: {r.returncode}')
        if json.loads(r.stdout) != {'test_id':a.test_id,'snapshot_sha256':a.snapshot_sha,'sample_sha256':sha(target)}: raise RuntimeError('writer output hash mismatch')
    old,old_sample=projection(binaries[2],OLD,paths[0],a.test_id,out,'old')
    new,new_sample=projection(binaries[3],NEW,paths[1],a.test_id,out,'new')
    n,paths_diff=compare_paths(old_sample,new_sample,'',64)
    if n or old['state_digest']!=new['state_digest']: raise RuntimeError(f'pixel pair differs: {n} paths={paths_diff}')
    image=old_sample['image']
    if old_sample['gate']!='state-and-pixels' or old_sample['render_contract'] is None or image is None: raise RuntimeError('not a pixel-bearing pair')
    if not all(image.get(k) is True for k in ('png_sha256_matches','rgba_sha256_matches','dimensions_match')): raise RuntimeError('image validation failed')
    evidence_names=['old.tui.json','new.tui.pb','old-writer.stdout','old-writer.stderr','new-writer.stdout','new-writer.stderr','old-reader.stderr','new-reader.stderr','old-reader.frame','new-reader.frame','old-reader.projection.json','new-reader.projection.json']
    evidence={name:sha(out/name) for name in evidence_names}
    if sha(snapshot)!=a.snapshot_sha: raise RuntimeError('snapshot changed during comparison')
    for path,expected in zip(binaries,binary_expected):
        if sha(path)!=expected: raise RuntimeError(f'executable changed during comparison: {path}')
    executable_records={label:{'path':str(path),'sha256':expected} for label,path,expected in zip(('old_writer','new_writer','old_reader','new_reader'),binaries,binary_expected)}
    result={'test_id':a.test_id,'snapshot_path':str(snapshot),'snapshot_sha256':a.snapshot_sha,'old_sample_sha256':sha(paths[0]),'new_sample_sha256':sha(paths[1]),'executables':executable_records,'evidence_sha256':evidence,'png_sha256':image['png_sha256'],'rgba_sha256':image['rgba_sha256'],'computed_png_sha256':image['png_sha256_computed'],'computed_rgba_sha256':image['rgba_sha256_computed'],'old_tuiscotti':OLD,'new_tuiscotti':NEW,'complete_fields_including_metadata_contract_png_and_rgba_equal':True,'state_digest':old['state_digest'],'snapshot_transport':'upstream TerminalSnapshot JSON; independently reconstructed', 'scope':'single native pixel capture; no baseline acceptance'}
    (out/'pair-manifest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    (out/'SUCCESS').write_text(sha(out/'pair-manifest.json')+'\n')
    print(json.dumps(result,sort_keys=True))
if __name__=='__main__': main()
