#[path = "../../common/pixel_writer.rs"]
mod pixel_writer;
fn main() { if let Err(error) = pixel_writer::run() { eprintln!("pixel writer: {error}"); std::process::exit(2); } }
