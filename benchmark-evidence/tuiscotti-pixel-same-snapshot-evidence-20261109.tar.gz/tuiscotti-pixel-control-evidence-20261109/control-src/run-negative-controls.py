#!/usr/bin/env python3
"""Run new-reader snapshot-mutation controls with recorded isolated provenance."""
import argparse, hashlib, json, os, platform, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OLD='d8d54155947f6303a41dfd6079b53c0abc16f29a'
NEW='92ef2d9ee082b35f68e066c5129fedbf07675a80'
INPUTS=('snapshot','baseline-pb','pair-manifest','outer-success','new-writer','new-reader')

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b)
    return h.hexdigest()

def source_identity(path, expected):
    repo=Path(path).resolve(strict=True)
    head=subprocess.run(['/usr/bin/git','-C',str(repo),'rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
    status=subprocess.run(['/usr/bin/git','-C',str(repo),'status','--porcelain','--untracked-files=no'],check=True,capture_output=True,text=True).stdout
    if head!=expected or status:raise RuntimeError(f'source HEAD or tracked status mismatch: {repo}')
    return {'path':str(repo),'head':head,'tracked_status':status}

def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    for item in INPUTS:
        parser.add_argument('--'+item,required=True)
        parser.add_argument('--'+item+'-sha',required=True)
    for item in ('old-repo','new-repo','old-lock','new-lock','new-reader-source','new-reader-build-record','new-writer-build-record','sandbox-profile','sandbox-profile-sha','control-out','run-out'):
        parser.add_argument('--'+item,required=True)
    a=parser.parse_args(); scratch=Path(os.environ['PIXEL_CONTROL_SCRATCH']).resolve(strict=True)
    run_out=Path(a.run_out); control_out=Path(a.control_out)
    for p in (run_out,control_out):
        if not p.is_absolute() or p.exists() or p.is_symlink():raise RuntimeError(f'output must be a fresh absolute path: {p}')
        p.resolve().relative_to(scratch)
    run_out=run_out.resolve();control_out=control_out.resolve()
    if run_out==control_out or run_out in control_out.parents or control_out in run_out.parents:raise RuntimeError('outputs must be disjoint')
    inputs={}
    for name in INPUTS:
        val=getattr(a,name.replace('-','_')); expected=getattr(a,name.replace('-','_')+'_sha')
        p=Path(val).resolve(strict=True)
        if name in ('snapshot','baseline-pb','pair-manifest','outer-success'):p.relative_to(scratch)
        if len(expected)!=64 or sha(p)!=expected:raise RuntimeError(f'input hash mismatch: {name}')
        inputs[name]={'path':str(p),'sha256':expected}
    source_before={'old':source_identity(a.old_repo,OLD),'new':source_identity(a.new_repo,NEW)}
    profile=Path(a.sandbox_profile).resolve(strict=True)
    if sha(profile)!=a.sandbox_profile_sha:raise RuntimeError('sandbox profile hash mismatch')
    source_files=[ROOT/'negative-controls.py',ROOT/'compare-pixel.py',ROOT/'oracle_protocol.py',ROOT/'common/pixel_writer.rs',ROOT/'new/Cargo.toml',ROOT/'new/src/main.rs',Path(a.old_lock),Path(a.new_lock),Path(a.new_reader_source),Path(a.new_reader_build_record),Path(a.new_writer_build_record),Path(__file__),profile]
    sources={str(p.resolve(strict=True)):sha(p.resolve(strict=True)) for p in source_files}
    # Capture parent artifacts and their inputs as part of the post-run identity set.
    outer=Path(inputs['outer-success']['path']); pair=Path(inputs['pair-manifest']['path'])
    marker=pair.parent/'SUCCESS'; run_result=outer.parent/'run-result.json'
    for p in (marker,run_result):
        if not p.is_file():raise RuntimeError(f'missing parent evidence: {p}')
        sources[str(p.resolve())]=sha(p)
    run_out.mkdir(parents=True,exist_ok=False)
    home=run_out/'home'; home.mkdir()
    env={'HOME':str(home),'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','TMPDIR':str(run_out),'XDG_CONFIG_HOME':str(home/'config'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_DATA_HOME':str(home/'data'),'PIXEL_CONTROL_SCRATCH':str(scratch)}
    command=['/usr/bin/sandbox-exec','-f',str(profile),'--',sys.executable,str(ROOT/'negative-controls.py')]
    for name in INPUTS:command += ['--'+name,inputs[name]['path'],'--'+name+'-sha',inputs[name]['sha256']]
    command += ['--out',str(control_out)]
    before={'command':command,'cwd':str(ROOT),'environment':env,'platform':{'machine':platform.machine(),'system':platform.system(),'python':sys.version,'executable':sys.executable},'inputs':inputs,'source_identities':source_before,'source_and_parent_sha256':sources}
    (run_out/'provenance-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
    result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=900)
    (run_out/'stdout.log').write_text(result.stdout);(run_out/'stderr.log').write_text(result.stderr)
    source_after={'old':source_identity(a.old_repo,OLD),'new':source_identity(a.new_repo,NEW)}
    if source_after!=source_before:raise RuntimeError('source identity changed')
    for name,info in inputs.items():
        if sha(Path(info['path']))!=info['sha256']:raise RuntimeError(f'input changed: {name}')
    for path,expected in sources.items():
        if sha(Path(path))!=expected:raise RuntimeError(f'source or parent evidence changed: {path}')
    run_result={'exit':result.returncode,'stdout_sha256':sha(run_out/'stdout.log'),'stderr_sha256':sha(run_out/'stderr.log'),'provenance_before_sha256':sha(run_out/'provenance-before.json'),'source_identities_after':source_after}
    (run_out/'run-result.json').write_text(json.dumps(run_result,indent=2,sort_keys=True)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
    control_marker=control_out/'CONTROL_SUCCESS';manifest=control_out/'control-manifest.json'
    if not control_marker.is_file() or not manifest.is_file() or control_marker.read_text().strip()!=sha(manifest):raise RuntimeError('negative control marker or manifest invalid')
    success={'run_result_sha256':sha(run_out/'run-result.json'),'control_success_path':str(control_marker),'control_success_sha256':sha(control_marker),'control_manifest_sha256':sha(manifest)}
    (run_out/'RUN_SUCCESS').write_text(json.dumps(success,sort_keys=True)+'\n')
if __name__=='__main__':main()
