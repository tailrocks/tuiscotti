# Same-snapshot pixel control (prepared, not run)

This is a research-only, native macOS arm64 control. It captures one upstream `TerminalSnapshot`, transfers that exact snapshot through upstream serde JSON to two separately pinned writers, and compares full projected sample values, including metadata, ordered contract/fonts, exact encoded PNG bytes, decoded RGBA bytes and all recorded/recomputed image hashes. It is not a JSON-sample-to-Protobuf converter; neither writer reads a Tuiscotti sample. It does not approve or write baselines and cannot establish historical baseline-update costs.

## Sources and scope

`producer-reference.rs` is the existing frozen benchmark producer (SHA-256 `f63f863702f9c08df21d01920143c3d12b5d14e2fff2672f2aee2010808e8f74`). `producer-snapshot-tee.rs` differs only by an opt-in, create-new snapshot write immediately after `Session::capture_snapshot` and session close; it retains the existing producer's state/pixel creation and checks. Its hash is `8d6a1797fc97c50fbb986cd16ed772300154240bda8eae85c2281ec38f396d0f`. The existing archive's 10 scenarios are at `/private/tmp/tuiscotti-codec-benchmark-archive-verify-20261105/tuiscotti-codec-benchmark-archive-20261105/scenarios-10.json`; their recorded reference executable revision is TCB `60b5fb2762d91a3549bd4ac63b1d77d534ee53d2`. Bind each scenario, exact executable hash, source revision, cwd, complete environment, profile and vendored fonts before capture. The recorded benchmark archive's candidate source-tree was not the merged new revision, so do not reuse it as the new writer's source identity.

`old` and `new` manifests pin Tuiscotti `d8d54155947f6303a41dfd6079b53c0abc16f29a` and `92ef2d9ee082b35f68e066c5129fedbf07675a80` respectively, upstream `tuiscotti-tui-test = 0.2.1`. Each runs the same `common/pixel_writer.rs`, which reads only an upstream snapshot, validates exact serde round-trip, calls that version's public `Sample::with_pixels` with the pinned profile and empty observation, and creates a new output exclusively. The output is a temporary research sample, not an accepted baseline.

## Outstanding runtime work after the active matrix

1. Review this code and the exact old/new API and dependency feature unification; it has **not been compiled**. Generate and inspect separate Cargo lockfiles and record their hashes. Fetch dependencies into isolated scratch before switching offline. Build with the user's pinned native arm64 mise-managed MBX and `--locked --offline`; no target, tools, caches or existing worktree should be modified. Record hashes, `file`/architecture, versions, exact build commands and source identity for both writers and both existing paired-oracle readers. External executable hashes supplied to the comparator are assertions and must be independently verified against those records.
2. From a verified disposable snapshot of the preserved producer workspace, install the tee source as the producer `src/main.rs`, preserving and recording exact source/patch hashes. Run one exact scenario with verified native reference executable in an isolated sandbox with disposable HOME/XDG and output directories. Set `PIXEL_CONTROL_SNAPSHOT_ROOT` to a new scratch-only directory. Save actual command, test/producer exit status and scenario manifest. A producer failure, missing/extra snapshot, or changed reference executable is a failed control. Never use a saved historic sample as a substitute for a live snapshot.
3. Set `PIXEL_CONTROL_SCRATCH` to the isolated run root. Set `SNAPSHOT` to the newly captured fixture; calculate its exact SHA-256 as `SNAPSHOT_SHA`. Choose a valid pixel ID ending `pixels-macos-aarch64` and provide the independently recorded writer and reader executable hashes. `compare-pixel.py` writes into a fresh output root beneath scratch and fails on writer errors, input hash mismatch, typed-field mismatch, state-digest mismatch, invalid image digest/dimensions, or missing pixels. The inner comparator writes `SUCCESS` after its checks, but it alone does not qualify as a completed run; only the wrapper’s `RUN_SUCCESS` after all postchecks qualifies. A failed run may leave `INCOMPLETE` and partial files.

```sh
python3 compare-pixel.py --snapshot "$SNAPSHOT" --snapshot-sha "$SNAPSHOT_SHA" \
  --test-id 'bench/pixel-control/pixels-macos-aarch64' \
  --old-writer "$OLD_WRITER" --old-writer-sha "$OLD_WRITER_SHA256" \
  --new-writer "$NEW_WRITER" --new-writer-sha "$NEW_WRITER_SHA256" \
  --old-reader "$OLD_READER" --old-reader-sha "$OLD_READER_SHA256" \
  --new-reader "$NEW_READER" --new-reader-sha "$NEW_READER_SHA256" \
  --out "$PIXEL_CONTROL_SCRATCH/pixel-comparison"
```

4. Independently review the original source capture and resulting manifest, verify old/new sample and PNG/RGBA hashes and all records, and run targeted controls for metadata-only change and one real pixel/PNG difference. The current comparator has no independent mutation fixtures for new pixel-domain fields; shared projection omissions remain a risk. Any renderer/profile/glyph error stays a failure, not an omitted row. Repeat representative scenarios if required by the declared benchmark; a single pair cannot establish corpus-wide or cross-platform equivalence. No existing sample, approval or historical receipt is modified.

The success manifest additionally records each verified writer/reader executable path and SHA-256, the writer stdout/stderr, exact length-prefixed reader frames and parsed projections with hashes, reader stderr, and recorded and recomputed PNG/RGBA digests. Missing evidence fails before `SUCCESS`. These artifacts can be large because they retain PNG and RGBA bytes.

For the actual run, prefer `run-control.py`: it requires absolute old/new source repositories at the pinned revisions with no tracked changes, the two generated writer Cargo lockfiles, both reader sources, four writer/reader build records, and an explicitly SHA-verified sandbox profile. It records exact comparator argv, cwd, a deliberately restricted environment, platform, source HEADs, source/lock/profile hashes and post-run output/status. Pass comparator arguments after `--` (including the comparator's own `--out` beneath scratch), and give the wrapper a different fresh `--out` directory. The wrapper records the comparison phase only; the earlier live producer capture still needs its own exact argv, environment, source and executable provenance. Neither wrapper nor comparator has been executed against real workers.

`RUN_SUCCESS` in the wrapper output is required for a valid result and binds `run-result.json`, the inner `SUCCESS`, and the inner manifest. An inner `SUCCESS` alone is insufficient. Source Git status checks cover tracked files only; they do not prove absence of untracked source/build inputs, which must be independently inventoried before the run. The separate live producer capture needs its own exact source, lockfile, executable, command and environment provenance.

The wrapper requires exactly one canonical inner `--out` argument followed by an absolute, nonexistent path; `--out=...`, duplicates, abbreviated options, relative paths, and existing outputs are rejected. It verifies the marker and manifest only at that exact output location.

## Prepared new-reader negative controls

`negative-controls.py` is a separate, as-yet-unrun control. Given a completed paired control with valid outer `RUN_SUCCESS`, it mutates the **upstream snapshot fixture** in four disposable copies: captured timestamp, one visible ASCII cell's text, that cell's bold attribute, and one palette entry. The new public pixel writer serializes each new sample; the new reader must expose each expected field change. Timestamp-only mutation must leave the state digest equal. The text mutation must also change both encoded PNG bytes and decoded RGBA bytes and their validated digests. The script verifies and records the parent pair/outer marker, source fixture, baseline PB, new writer/reader hashes, generated inputs/outputs and full reader frames. It creates `CONTROL_SUCCESS` only after all controls and final input/executable rehashes succeed.

This is a targeted observability check for one live-capture-derived snapshot, **not** an independent exhaustive field oracle. The PNG/RGBA difference is driven by a text mutation; it is not an independently generated image-only mutation. Some captures may have no eligible visible `A`, `B`, `M`, or `W` cell, a replacement that does not alter rendered pixels, an unsupported glyph, or a canonical-JSON transport mismatch; these conditions fail closed and must not be silently changed into passes. The script must run in the same explicit sandbox and controlled environment as the comparator; retain its command, cwd, environment, status and source hashes separately.

```sh
python3 negative-controls.py \
  --snapshot "$SNAPSHOT" --snapshot-sha "$SNAPSHOT_SHA" \
  --baseline-pb "$COMPARISON_OUTPUT/new.tui.pb" --baseline-pb-sha "$BASELINE_PB_SHA" \
  --pair-manifest "$COMPARISON_OUTPUT/pair-manifest.json" --pair-manifest-sha "$PAIR_MANIFEST_SHA" \
  --outer-success "$WRAPPER_OUTPUT/RUN_SUCCESS" --outer-success-sha "$OUTER_SUCCESS_SHA" \
  --new-writer "$NEW_WRITER" --new-writer-sha "$NEW_WRITER_SHA256" \
  --new-reader "$NEW_READER" --new-reader-sha "$NEW_READER_SHA256" \
  --out "$PIXEL_CONTROL_SCRATCH/negative-controls"
```

`run-negative-controls.py` is the prepared outer runner for those controls. It requires the six control inputs and their expected hashes, pinned tracked-clean old/new source repositories, both Cargo lockfiles, the new reader's source, new writer/reader build records, a SHA-verified sandbox profile, and separate fresh absolute `--control-out` and `--run-out` paths inside `PIXEL_CONTROL_SCRATCH`. It constructs the exact control argv itself, launches under the profile with a restricted recorded environment and cwd, and records input, parent evidence, source, lock, build-record and profile hashes. After the controls exit it rechecks those identities and binds `run-result.json`, the inner `CONTROL_SUCCESS`, and its manifest in the outer `RUN_SUCCESS`; only the outer marker qualifies. As with the pixel wrapper, tracked-only Git checks do not establish untracked source closure; build-record contents and executable-to-source bindings still require independent review. The producer capture has separate provenance and is not executed by either runner.

Obtain the exact command options from `python3 run-negative-controls.py --help` after reviewing the files. This runner and its real negative controls have not been executed; do not treat its existence or synthetic mutation tests as a completed control.
