import importlib.util, tempfile, unittest
from pathlib import Path
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('control',root/'run-control.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class OutputTests(unittest.TestCase):
    def test_unambiguous_fresh_absolute_output_only(self):
        with tempfile.TemporaryDirectory(dir=root) as t:
            scratch=Path(t); outer=scratch/'outer'; fresh=scratch/'inner'
            self.assertEqual(m.resolve_inner_output(['--out',str(fresh)],scratch,outer),fresh)
            for args in (['--out='+str(fresh)],['--out',str(fresh),'--out='+str(fresh)],['--out',str(fresh),'--out',str(fresh)],['--out','relative'],['--out'],['--o',str(fresh)]):
                with self.subTest(args=args), self.assertRaises((RuntimeError,ValueError)):m.resolve_inner_output(args,scratch,outer)
            fresh.mkdir()
            with self.assertRaises(RuntimeError):m.resolve_inner_output(['--out',str(fresh)],scratch,outer)
if __name__=='__main__':unittest.main()
