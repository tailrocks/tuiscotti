use std::error::Error;
use std::fs::{File, OpenOptions};
use std::io::{Read as _, Write as _};
use std::path::Path;
use sha2::{Digest, Sha256};
use tui_test::TerminalSnapshot;
use tuiscotti::{render_profile, sample::{Observation, Sample}};

pub fn run() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    if args.len() != 3 { return Err("usage: pixel-writer TEST_ID SNAPSHOT_JSON OUTPUT_SAMPLE".into()); }
    let id = args[0].to_str().ok_or("test ID must be UTF-8")?;
    let mut input = Vec::new();
    File::open(Path::new(&args[1]))?.take(64 * 1024 * 1024 + 1).read_to_end(&mut input)?;
    if input.len() > 64 * 1024 * 1024 { return Err("snapshot exceeds 64 MiB".into()); }
    let snapshot: TerminalSnapshot = serde_json::from_slice(&input)?;
    if serde_json::to_vec(&snapshot)? != input { return Err("snapshot transport is not byte-exact after validated reconstruction".into()); }
    let profile = render_profile::resolve_profile("tuiscotti-pinned-v1")?;
    let sample = Sample::with_pixels(id, &snapshot, Observation::empty(), profile)?;
    let bytes = sample.to_bytes()?;
    let path = Path::new(&args[2]);
    std::fs::create_dir_all(path.parent().ok_or("output has no parent")?)?;
    let mut file = OpenOptions::new().write(true).create_new(true).open(path)?;
    file.write_all(&bytes)?;
    println!("{{\"test_id\":{},\"snapshot_sha256\":\"{:x}\",\"sample_sha256\":\"{:x}\"}}", serde_json::to_string(id)?, Sha256::digest(&input), Sha256::digest(&bytes));
    Ok(())
}
