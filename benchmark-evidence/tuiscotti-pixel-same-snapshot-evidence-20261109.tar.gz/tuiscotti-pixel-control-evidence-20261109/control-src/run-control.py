#!/usr/bin/env python3
"""Run the prepared pixel comparator inside an explicit sandbox; retain provenance."""
import argparse, hashlib, json, os, platform, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OLD='d8d54155947f6303a41dfd6079b53c0abc16f29a'
NEW='92ef2d9ee082b35f68e066c5129fedbf07675a80'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024): h.update(b)
    return h.hexdigest()

def git_identity(repo,expected):
    p=Path(repo).resolve(strict=True)
    head=subprocess.run(['/usr/bin/git','-C',str(p),'rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
    dirty=subprocess.run(['/usr/bin/git','-C',str(p),'status','--porcelain','--untracked-files=no'],check=True,capture_output=True,text=True).stdout
    if head!=expected or dirty: raise RuntimeError(f'source revision or tracked cleanliness mismatch: {p}')
    return {'path':str(p),'head':head,'tracked_status':dirty}

def resolve_inner_output(args,scratch,out):
    if args.count('--out') != 1 or any(x.startswith('--out=') for x in args):
        raise RuntimeError('exactly one literal inner --out is required; --out= is forbidden')
    out_index=args.index('--out')
    if out_index+1 >= len(args) or args[out_index+1].startswith('-'):
        raise RuntimeError('inner --out requires an absolute path')
    inner_arg=Path(args[out_index+1])
    if not inner_arg.is_absolute() or inner_arg.exists() or inner_arg.is_symlink():
        raise RuntimeError('inner --out must be an absolute, nonexistent path')
    inner=inner_arg.resolve()
    inner.relative_to(scratch)
    if inner == out or out in inner.parents or inner in out.parents: raise RuntimeError('inner and wrapper outputs must be disjoint')
    return inner

def main():
    ap=argparse.ArgumentParser()
    for f in ('old-repo','new-repo','old-lock','new-lock','old-reader-source','new-reader-source','old-reader-build-record','new-reader-build-record','old-writer-build-record','new-writer-build-record','sandbox-profile','sandbox-profile-sha','out'):ap.add_argument('--'+f,required=True)
    ap.add_argument('comparator_args',nargs=argparse.REMAINDER)
    a=ap.parse_args(); scratch=Path(os.environ['PIXEL_CONTROL_SCRATCH']).resolve(strict=True)
    out=Path(a.out).resolve(); out.relative_to(scratch)
    args=a.comparator_args
    if args and args[0]=='--': args=args[1:]
    if not args: raise RuntimeError('missing comparator arguments after --')
    inner=resolve_inner_output(args,scratch,out)
    profile=Path(a.sandbox_profile).resolve(strict=True)
    if sha(profile)!=a.sandbox_profile_sha: raise RuntimeError('sandbox profile hash mismatch')
    sources={'old':git_identity(a.old_repo,OLD),'new':git_identity(a.new_repo,NEW)}
    files={}
    for path in [ROOT/'common/pixel_writer.rs',ROOT/'compare-pixel.py',ROOT/'oracle_protocol.py',ROOT/'producer-reference.rs',ROOT/'producer-snapshot-tee.rs',ROOT/'old/Cargo.toml',ROOT/'new/Cargo.toml',ROOT/'old/src/main.rs',ROOT/'new/src/main.rs',Path(a.old_lock),Path(a.new_lock),Path(a.old_reader_source),Path(a.new_reader_source),Path(a.old_reader_build_record),Path(a.new_reader_build_record),Path(a.old_writer_build_record),Path(a.new_writer_build_record),Path(__file__).resolve(),profile]:
        p=path.resolve(strict=True)
        if not p.is_file(): raise RuntimeError(f'not a source file: {p}')
        files[str(p)]=sha(p)
    out.mkdir(parents=True,exist_ok=False)
    home=out/'home'; home.mkdir()
    env={'HOME':str(home),'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','TMPDIR':str(out),'XDG_CONFIG_HOME':str(home/'config'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_DATA_HOME':str(home/'data'),'PIXEL_CONTROL_SCRATCH':str(scratch)}
    cmd=['/usr/bin/sandbox-exec','-f',str(profile),'--',sys.executable,str(ROOT/'compare-pixel.py'),*args]
    record={'command':cmd,'cwd':str(ROOT),'environment':env,'platform':{'machine':platform.machine(),'system':platform.system(),'python':sys.version,'executable':sys.executable},'sources':sources,'files_sha256':files,'sandbox_profile_sha256':a.sandbox_profile_sha}
    (out/'provenance-before.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    completed=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=600)
    (out/'stdout.log').write_text(completed.stdout)
    (out/'stderr.log').write_text(completed.stderr)
    sources_after={'old':git_identity(a.old_repo,OLD),'new':git_identity(a.new_repo,NEW)}
    for path,expected in files.items():
        if sha(Path(path))!=expected: raise RuntimeError(f'provenance file changed during run: {path}')
    if sources_after != sources: raise RuntimeError('source identities changed during run')
    result={'exit':completed.returncode,'stdout_sha256':sha(out/'stdout.log'),'stderr_sha256':sha(out/'stderr.log'),'provenance_before_sha256':sha(out/'provenance-before.json'),'sources_after':sources_after}
    (out/'run-result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    if completed.returncode: raise SystemExit(completed.returncode)
    inner_marker=inner/'SUCCESS'
    inner_manifest=inner/'pair-manifest.json'
    if not inner_marker.is_file() or not inner_manifest.is_file() or inner_marker.read_text().strip()!=sha(inner_manifest): raise RuntimeError('inner success marker or manifest invalid')
    outer={'run_result_sha256':sha(out/'run-result.json'),'inner_success_path':str(inner_marker),'inner_success_sha256':sha(inner_marker),'inner_manifest_sha256':sha(inner_manifest)}
    (out/'RUN_SUCCESS').write_text(json.dumps(outer,sort_keys=True)+'\n')
if __name__=='__main__': main()
