import importlib.util,sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('controls',root/'negative-controls.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class MutationTests(unittest.TestCase):
 def test_mutations_leave_original_and_cover_four_fields(self):
  s={'cells':[{'width':1,'text':'A','invisible':False,'inverse':False,'bold':False}], 'metadata':{'captured_at_ms':5},'palette':['#000000']*256}
  cases=m.mutations(s)
  self.assertEqual([x[0] for x in cases],['metadata','text','style','palette'])
  self.assertEqual(s['metadata']['captured_at_ms'],5)
  self.assertEqual(cases[0][1]['metadata']['captured_at_ms'],6)
  self.assertEqual(cases[1][1]['cells'][0]['text'],'W')
  self.assertTrue(cases[2][1]['cells'][0]['bold'])
  self.assertEqual(cases[3][1]['palette'][0],'#010203')
 def test_no_visible_character_rejected(self):
  with self.assertRaises(RuntimeError):m.mutations({'cells':[],'metadata':{},'palette':[]})
 def test_timestamp_overflow_rejected(self):
  with self.assertRaises(RuntimeError):m.mutations({'cells':[{'width':1,'text':'A','bold':False}],'metadata':{'captured_at_ms':(1<<64)-1},'palette':['#000000']})
if __name__=='__main__':unittest.main()
