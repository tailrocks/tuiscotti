#!/usr/bin/env python3
"""Test new-reader observability using disposable upstream-snapshot mutations."""
import argparse, hashlib, importlib.util, json, os, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pixel_compare', ROOT/'compare-pixel.py')
pixel=importlib.util.module_from_spec(spec); spec.loader.exec_module(pixel)
NEW='92ef2d9ee082b35f68e066c5129fedbf07675a80'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while b:=f.read(1024*1024): h.update(b)
    return h.hexdigest()

def mutations(snapshot):
    cells=snapshot['cells']
    index=next((i for i,c in enumerate(cells) if c.get('width')==1 and c.get('text') in ('M','W','A','B') and not c.get('invisible') and not c.get('inverse')),None)
    if index is None: raise RuntimeError('no eligible visible one-column ASCII cell; select another capture')
    original=cells[index]['text']
    cases=[]
    def clone():return json.loads(json.dumps(snapshot))
    x=clone(); old=x['metadata']['captured_at_ms']
    if type(old) is not int or old<0 or old >= (1<<64)-1:raise RuntimeError('timestamp cannot increment')
    x['metadata']['captured_at_ms']=old+1; cases.append(('metadata',x,['snapshot','metadata','captured_at_ms'],str(old+1)))
    x=clone(); replacement='W' if original!='W' else 'M'; x['cells'][index]['text']=replacement; cases.append(('text',x,['snapshot','cells',index,'text'],replacement))
    x=clone(); old=x['cells'][index]['bold']
    if type(old) is not bool:raise RuntimeError('bold is not boolean')
    x['cells'][index]['bold']=not old; cases.append(('style',x,['snapshot','cells',index,'bold'],not old))
    x=clone(); old=x['palette'][0]
    if not isinstance(old,str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',old):raise RuntimeError('unexpected palette representation')
    replacement='#010203' if old.lower()!='#010203' else '#030201'; x['palette'][0]=replacement; cases.append(('palette',x,['snapshot','palette',0],[int(replacement[i:i+2],16) for i in (1,3,5)]))
    return cases

def get(obj,path):
    for part in path:obj=obj[part]
    return obj

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for f in ('snapshot','snapshot-sha','baseline-pb','baseline-pb-sha','pair-manifest','pair-manifest-sha','outer-success','outer-success-sha','new-writer','new-writer-sha','new-reader','new-reader-sha','out'):p.add_argument('--'+f,required=True)
    a=p.parse_args(); scratch=Path(os.environ['PIXEL_CONTROL_SCRATCH']).resolve(strict=True)
    if platform_machine()!='arm64':raise RuntimeError('native arm64 required')
    paths={}
    for label,path,expected in [('snapshot',a.snapshot,a.snapshot_sha),('baseline_pb',a.baseline_pb,a.baseline_pb_sha),('pair_manifest',a.pair_manifest,a.pair_manifest_sha),('outer_success',a.outer_success,a.outer_success_sha),('new_writer',a.new_writer,a.new_writer_sha),('new_reader',a.new_reader,a.new_reader_sha)]:
        q=Path(path).resolve(strict=True)
        if label in ('snapshot','baseline_pb','pair_manifest','outer_success'):q.relative_to(scratch)
        if not re.fullmatch('[0-9a-f]{64}',expected) or sha(q)!=expected:raise RuntimeError(f'{label} hash mismatch')
        paths[label]=(q,expected)
    pair=json.loads(paths['pair_manifest'][0].read_text()); outer=json.loads(paths['outer_success'][0].read_text())
    if pair.get('snapshot_sha256')!=a.snapshot_sha or pair.get('new_sample_sha256')!=a.baseline_pb_sha or outer.get('inner_manifest_sha256')!=a.pair_manifest_sha:raise RuntimeError('baseline is not bound to completed pair')
    marker=Path(outer.get('inner_success_path','')).resolve(strict=True)
    if marker.parent != paths['pair_manifest'][0].parent or marker.parent != paths['baseline_pb'][0].parent:raise RuntimeError('inner result paths are not co-located')
    if sha(marker)!=outer.get('inner_success_sha256') or marker.read_text().strip()!=a.pair_manifest_sha:raise RuntimeError('inner success marker mismatch')
    run_result=paths['outer_success'][0].parent/'run-result.json'
    if sha(run_result)!=outer.get('run_result_sha256'):raise RuntimeError('outer run result mismatch')
    if pair.get('executables',{}).get('new_writer',{}).get('sha256')!=a.new_writer_sha or pair.get('executables',{}).get('new_reader',{}).get('sha256')!=a.new_reader_sha:raise RuntimeError('control executables differ from completed pair')
    test_id=pair['test_id']; out=Path(a.out).resolve();out.relative_to(scratch);out.mkdir(parents=True,exist_ok=False)
    (out/'INCOMPLETE').write_text('Only CONTROL_SUCCESS qualifies as completed.\n')
    baseline_record,baseline=pixel.projection(paths['new_reader'][0],NEW,paths['baseline_pb'][0],test_id,out,'baseline')
    if baseline.get('gate')!='state-and-pixels' or baseline.get('image') is None:raise RuntimeError('baseline is not pixel-bearing')
    snapshot=json.loads(paths['snapshot'][0].read_bytes()); cases=mutations(snapshot); results=[]
    for name,mutated,field,expected in cases:
        fixture=out/f'{name}.snapshot.json';fixture.write_text(json.dumps(mutated,ensure_ascii=False,separators=(',',':')))
        sample=out/f'{name}.tui.pb'
        run=subprocess.run([str(paths['new_writer'][0]),test_id,str(fixture),str(sample)],capture_output=True,text=True,timeout=120)
        (out/f'{name}.writer.stdout').write_text(run.stdout);(out/f'{name}.writer.stderr').write_text(run.stderr)
        if run.returncode:raise RuntimeError(f'{name} writer failed: {run.returncode}')
        if json.loads(run.stdout)!={'test_id':test_id,'snapshot_sha256':sha(fixture),'sample_sha256':sha(sample)}:raise RuntimeError(f'{name} writer hash mismatch')
        record,projected=pixel.projection(paths['new_reader'][0],NEW,sample,test_id,out,name)
        if get(projected,field)!=expected or get(baseline,field)==expected:raise RuntimeError(f'{name} expected field not observed')
        count,diffs=pixel.compare_paths(baseline,projected,'',128)
        if name=='metadata':
            if count!=1 or diffs!=['/snapshot/metadata/captured_at_ms'] or record['state_digest']!=baseline_record['state_digest']:raise RuntimeError('metadata control did not remain state-digest equal')
        else:
            if record['state_digest']==baseline_record['state_digest']:raise RuntimeError(f'{name} change did not alter state digest')
        img=projected['image'];base_img=baseline['image']
        if name=='text' and (img['png_sha256']==base_img['png_sha256'] or img['rgba_sha256']==base_img['rgba_sha256'] or img['png_base64']==base_img['png_base64'] or img['rgba_base64']==base_img['rgba_base64']):raise RuntimeError('text mutation did not produce independently observable PNG and RGBA differences')
        results.append({'case':name,'observed_path':field,'expected':expected,'difference_count':count,'difference_paths':diffs,'paths_truncated':count>len(diffs),'state_digest_equal':record['state_digest']==baseline_record['state_digest'],'snapshot_sha256':sha(fixture),'pb_sha256':sha(sample),'png_sha256':img['png_sha256'],'rgba_sha256':img['rgba_sha256']})
    for label,(path,expected) in paths.items():
        if sha(path)!=expected:raise RuntimeError(f'{label} changed during control')
    evidence={p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='INCOMPLETE'}
    result={'scope':'new reader; synthetic upstream snapshot mutations from one real capture; no baseline acceptance','test_id':test_id,'parent_pair_manifest_sha256':a.pair_manifest_sha,'parent_outer_success_sha256':a.outer_success_sha,'executables':{k:{'path':str(paths[k][0]),'sha256':paths[k][1]} for k in ('new_writer','new_reader')},'baseline_png_sha256':baseline['image']['png_sha256'],'baseline_rgba_sha256':baseline['image']['rgba_sha256'],'cases':results,'evidence_sha256':evidence,'limitations':'Shared projection code; no independent exhaustive field oracle; text-driven PNG/RGBA change is not an independently generated image-only mutation.'}
    (out/'control-manifest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    (out/'CONTROL_SUCCESS').write_text(sha(out/'control-manifest.json')+'\n')
    print(json.dumps({'cases':len(results),'manifest_sha256':sha(out/'control-manifest.json')}))

def platform_machine():
    import platform
    return platform.machine()
if __name__=='__main__':main()
