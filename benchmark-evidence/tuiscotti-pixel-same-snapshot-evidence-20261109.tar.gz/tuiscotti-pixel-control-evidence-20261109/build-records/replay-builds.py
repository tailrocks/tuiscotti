import hashlib,json,subprocess,sys
from pathlib import Path
s=Path('/private/tmp/tuiscotti-pixel-same-snapshot-20261109/run')
profile=s/'env/sandbox.sb'
commands={
 'old-writer':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'control-src/old/Cargo.toml')],
 'new-writer':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'control-src/new/Cargo.toml')],
 'old-reader':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'control-src/reader-old/Cargo.toml')],
 'new-reader':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'control-src/reader-new/Cargo.toml')],
 'tcb-showcase':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'tcb-source/Cargo.toml'),'--bin','showcase'],
 'live-producer':['cargo','build','--locked','--offline','--release','--manifest-path',str(s/'capture/producer/Cargo.toml')],
}
binpaths={
 'old-writer':s/'targets/cargo-target/release/pixel-same-snapshot-old',
 'new-writer':s/'targets/cargo-target/release/pixel-same-snapshot-new',
 'old-reader':s/'targets/cargo-target/release/tuiscotti-old-pair-projection',
 'new-reader':s/'targets/cargo-target/release/tuiscotti-new-pair-projection',
 'tcb-showcase':s/'targets/cargo-target/release/showcase',
 'live-producer':s/'targets/cargo-target/release/tuiscotti-bench-producer-old',
}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,args in commands.items():
 exe=binpaths[name];before=sha(exe)
 command=['/usr/bin/sandbox-exec','-f',str(profile),'--','/usr/bin/env','-i','CARGO_NET_OFFLINE=true',str(s/'env/run-mise.sh'),'exec','--',*args]
 result=subprocess.run(command,cwd=s/'control-src',capture_output=True,text=True,timeout=600)
 log=s/'build-records'/f'{name}.build.log';log.write_text('STDOUT\n'+result.stdout+'\nSTDERR\n'+result.stderr)
 after=sha(exe)
 record={'command':command,'cwd':str(s/'control-src'),'exit':result.returncode,'executable':str(exe),'executable_sha256_before':before,'executable_sha256_after':after,'log_sha256':sha(log),'no_binary_change':before==after}
 (s/'build-records'/f'{name}.replay.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
 print(name,result.returncode, before==after, result.stdout.strip().splitlines()[-1:] if result.stdout.strip() else [])
 if result.returncode or before!=after:raise SystemExit(1)
