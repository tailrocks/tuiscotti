# Reconstructed selected-path Git history (prepared, not run)

`measure-history.py` is a draft measurement tool. Do not run it while the codec matrix is active. It requires five **future, already verified** same-snapshot JSON/PB pairs. They do not yet exist. It never calls `accept`, writes an active baseline, converts a JSON sample, or touches a source checkout. It creates two new isolated Git object databases under a new scratch output directory and copies the exact paired bytes as research inputs.

## Reconstructed stages and source mapping

The actual TCB stages are `17f03a` (focused control added), `f4727e` (same ID modified), `01921e` (browser box added), `3f1a69` (browser box deleted), `ea8cf1` (picker parent checkpoint), `bdc447` (picker modified). Preflight checks their full SHAs, chronological ancestry, source blob changes, browser deletion, and that the picker baseline's original Git blob at `17f03a` matches `ea8cf1`. Both fresh recaptured update pairs must have differing state digests. The picker baseline is seeded in a synthetic base commit from the future `ea8cf1` capture; original picker stored baseline bytes were unchanged between those source revisions, but the later fresh capture's metadata and other nondeterminism are not evidence of the earlier capture's full value. `ea8cf1` is a no-op checkpoint in the reconstructed selected-path histories.

The resulting JSON and PB histories contain only these selected paths, not the full original commits; metadata, topology, IDs and Git config are controlled identically across the two cases. A single selected occurrence per stage is required; retain all other occurrences separately with their hashes and do not treat them as nonexistent. This experiment measures reconstructed selected-path fresh-capture Git histories, **not** exact original historical values, the whole real commits, or proof that JSON/PB costs extrapolate across a wider update sequence. It adds no pixel or terminal-palette change. The spec's full pixel/palette and real-history requirements remain open.

## Mandatory preconditions

- Capture 17f focused, f472 focused, 019 browser, ea8 picker and bdc picker separately with their revision's original normal frozen test checks, using the scoped tee and old/new paired readers. Save exact command, nextest status, clean source+patch and binary identities, no-baseline-write evidence, complete raw occurrence sets, and per-stage full-field/metadata equality + digest evidence. Preserve and review all repeated captures. No candidate approval is implied or performed.
- The supplied manifest lives inside a fresh isolated scratch root and contains **exactly** the five stage keys `focused_add`, `focused_update`, `browser_add`, `picker_before`, `picker_update`. Each entry has:

```json
{
  "revision": "<full source revision>",
  "test_id": "functional/<exact test ID>",
  "old_json": "/absolute/scratch/path/to/old.tui.json",
  "old_json_sha256": "<64 lowercase hex>",
  "new_pb": "/absolute/scratch/path/to/new.tui.pb",
  "new_pb_sha256": "<64 lowercase hex>",
  "pair_manifest": "/absolute/scratch/path/to/pair-manifest.json",
  "pair_manifest_sha256": "<64 lowercase hex>",
  "pair_success": "/absolute/scratch/path/to/SUCCESS",
  "pair_success_sha256": "<64 lowercase hex>"
}
```

The manifest must refer to a single exact matching occurrence in the corresponding successful scoped comparator manifest. The script validates hashes, the scoped comparator’s exact revision, old/new reader and snapshot-transport fields, test exit field, full-field equality, metadata-only negative control and cross-stage state changes. The comparator manifest has no schema tag; its trusted source/build identity still needs external verification. It does **not** independently validate comparator source/executable bindings or the saved nextest log, or re-run renderers; those are prerequisites for the operator to audit. Full source/lock/binary hashes and baseline-tree before/after evidence must be retained separately. Secure the isolated scratch directory against concurrent mutation.

## After the active matrix

Use native arm64. Prepare the inputs and review them before launching; validate the pinned `tcb` repo is read-only and source objects are available. Set `HISTORY_SCRATCH` to the existing private scratch root, `INPUTS` to the completed manifest, and `INPUTS_SHA256` to its independently approved SHA-256. Choose a **new, nonexistent absolute** `OUTPUT` below scratch. Run in a sandbox allowing writes only beneath this scratch root and no network. There is no need to set or alter global Git/mise/Cargo config. Record exact shell command, environment, machine/Git version and process exit status.

```sh
python3 /private/tmp/tuiscotti-real-history-pair-design-20261109/git-history/measure-history.py \
  --tcb-repo "$TCB_SOURCE" --manifest "$INPUTS" --manifest-sha "$INPUTS_SHA256" \
  --scratch "$HISTORY_SCRATCH" --output "$OUTPUT"
```

The tool preflights all inputs before creating output. It configures a clean local Git environment, disables automatic GC and hooks, uses fixed benchmark-only commit identity and timestamps, and performs one identical `git repack -Adf --window=10 --depth=50` per isolated DB. It retains every input/proof/marker preflight SHA, checks source and copied bytes against it at consumption, and rechecks all inputs and the manifest before success. System/global Git attributes are disabled; each committed tree path and blob is read back and compared with the preflight SHA. It records consumed file identities, committed blob hashes, commit/tree IDs, pack SHA/size, `git count-objects -v`, repack wall time and limitations. `RUN_SUCCESS` is written only after both variants complete. Partial `INCOMPLETE` output is failure. This is one pack run, not repetitions, cold-clone cost, CPU/RSS, or statistical uncertainty; add separately planned trials before making speed claims.

The tool and two synthetic missing-input tests have only been syntax/unit checked. They have not been exercised against Git or future captures. Review independently and run disposable fixture tests before trusting a real measurement.
