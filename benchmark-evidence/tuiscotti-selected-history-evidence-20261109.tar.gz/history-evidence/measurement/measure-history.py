#!/usr/bin/env python3
"""Measure a narrowly scoped reconstruction of real TCB change stages."""
import argparse, hashlib, json, os, shutil, subprocess, time
from pathlib import Path

REVISIONS={
 'focused_add':'17f03a161fdbab08553e318f07b49d043e5e26eb',
 'focused_update':'f4727e553c68e605dd251c730678bfbf2799a8a5',
 'browser_add':'01921e962ba674e0399e33246e568bbda6d82f73',
 'browser_delete':'3f1a69fedea37402d25b947195665a8ea39ff038',
 'picker_before':'ea8cf188583be2a390ae65fd9f74d3aeb30492aa',
 'picker_update':'bdc44737842c4f2b6a4ba7b4814b8fff9f734de2',
}
IDS={
 'focused_add':'functional/showcase_fixedcontrols_focused_refused',
 'focused_update':'functional/showcase_fixedcontrols_focused_refused',
 'browser_add':'functional/showcase_fixeddialogs_browser_box',
 'picker_before':'functional/showcase_page_pickers',
 'picker_update':'functional/showcase_page_pickers',
}
STAGES=('base','focused_add','focused_update','browser_add','browser_delete','picker_before','picker_update')
CAP=64*1024*1024

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while data:=f.read(1024*1024):h.update(data)
    return h.hexdigest()

def checked_file(path,expected,root):
    p=Path(path)
    if p.is_symlink() or not p.is_file():raise RuntimeError(f'missing/nonregular input {p}')
    p=p.resolve(strict=True);p.relative_to(root)
    if p.stat().st_size>CAP or len(expected)!=64 or digest(p)!=expected:raise RuntimeError(f'bad input hash/size: {p}')
    return p

def source_git(repo,*args):
    return subprocess.run(['/usr/bin/git','-C',str(repo),*args],check=True,capture_output=True,text=True,env={'PATH':'/usr/bin:/bin','HOME':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_TERMINAL_PROMPT':'0'}).stdout.strip()

def preflight(repo,manifest,root):
    if set(manifest)!=set(IDS):raise RuntimeError('capture stages must exactly match requested five paired states')
    ordered=[REVISIONS[x] for x in ('focused_add','focused_update','browser_add','browser_delete','picker_before','picker_update')]
    for rev in ordered:
        if source_git(repo,'rev-parse','--verify',rev+'^{commit}')!=rev:raise RuntimeError('revision mismatch')
    for left,right in zip(ordered,ordered[1:]):source_git(repo,'merge-base','--is-ancestor',left,right)
    focus='tests/functional/baselines/functional/showcase_fixedcontrols_focused_refused.tui.json'
    picker='tests/functional/baselines/functional/showcase_page_pickers.tui.json'
    browser='tests/functional/baselines/functional/showcase_fixeddialogs_browser_box.tui.json'
    def blob(rev,path):return source_git(repo,'rev-parse','--verify',rev+':'+path)
    if blob(REVISIONS['focused_add'],focus)==blob(REVISIONS['focused_update'],focus):raise RuntimeError('focused source blob did not change')
    if blob(REVISIONS['picker_before'],picker)==blob(REVISIONS['picker_update'],picker):raise RuntimeError('picker source blob did not change')
    if blob(REVISIONS['focused_add'],picker)!=blob(REVISIONS['picker_before'],picker):raise RuntimeError('picker seed not unchanged across source revisions')
    blob(REVISIONS['browser_add'],browser)
    absent=subprocess.run(['/usr/bin/git','-C',str(repo),'cat-file','-e',REVISIONS['browser_delete']+':'+browser],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env={'PATH':'/usr/bin:/bin','HOME':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'})
    if absent.returncode==0:raise RuntimeError('browser deletion not present')
    pairs={}
    states={}
    input_hashes={}
    for stage,expected_id in IDS.items():
        row=manifest[stage]
        if row.get('revision')!=REVISIONS[stage] or row.get('test_id')!=expected_id:raise RuntimeError(f'stage identity mismatch {stage}')
        proof=checked_file(row['pair_manifest'],row['pair_manifest_sha256'],root)
        success=checked_file(row['pair_success'],row['pair_success_sha256'],root)
        if success.read_text().strip()!=digest(proof):raise RuntimeError(f'comparison success marker mismatch {stage}')
        detail=json.loads(proof.read_bytes())
        if (detail.get('revision')!=row['revision'] or detail.get('test_exit')!=0
            or detail.get('old_revision')!='d8d54155947f6303a41dfd6079b53c0abc16f29a'
            or detail.get('new_revision')!='92ef2d9ee082b35f68e066c5129fedbf07675a80'
            or detail.get('snapshot_transport')!='upstream TerminalSnapshot JSON, reconstructed in writer'):
            raise RuntimeError(f'bad test/capture evidence or scope {stage}')
        control=detail.get('metadata_negative_control',{})
        if control.get('changed_paths')!=['/snapshot/metadata/captured_at_ms'] or control.get('state_digest_unchanged') is not True:raise RuntimeError(f'negative control missing: {stage}')
        old=checked_file(row['old_json'],row['old_json_sha256'],root);new=checked_file(row['new_pb'],row['new_pb_sha256'],root)
        matches=[x for x in detail['pairs'] if x.get('test_id')==expected_id and x.get('old_json_sha256')==digest(old) and x.get('new_pb_sha256')==digest(new) and x.get('full_projection_equal_including_metadata') is True]
        if len(matches)!=1:raise RuntimeError(f'no unique full-field pair for {stage}')
        state=matches[0].get('state_digest')
        if not isinstance(state,str) or len(state)!=64:raise RuntimeError(f'missing state digest: {stage}')
        states[stage]=state
        pairs[stage]=((old,row['old_json_sha256']),(new,row['new_pb_sha256']))
        for path,expected in ((old,row['old_json_sha256']),(new,row['new_pb_sha256']),(proof,row['pair_manifest_sha256']),(success,row['pair_success_sha256'])):
            prior=input_hashes.setdefault(str(path),expected)
            if prior!=expected:raise RuntimeError(f'conflicting expected hashes: {path}')
    if states['focused_add']==states['focused_update'] or states['picker_before']==states['picker_update']:raise RuntimeError('fresh paired captures do not show both real state updates')
    return pairs,input_hashes

def run(repo,env,*args):
    p=subprocess.run(['/usr/bin/git','-C',str(repo),'-c','core.hooksPath=/dev/null','-c','gc.auto=0','-c','maintenance.auto=false','-c','core.autocrlf=false','-c','core.attributesFile=/dev/null',*args],env=env,check=True,capture_output=True,text=True)
    return p.stdout.strip()

def main():
    ap=argparse.ArgumentParser(allow_abbrev=False)
    ap.add_argument('--tcb-repo',required=True,type=Path);ap.add_argument('--manifest',required=True,type=Path);ap.add_argument('--manifest-sha',required=True);ap.add_argument('--scratch',required=True,type=Path);ap.add_argument('--output',required=True,type=Path)
    a=ap.parse_args();root=a.scratch.resolve(strict=True);out=a.output
    if not out.is_absolute() or out.exists() or out.is_symlink():raise RuntimeError('output must be new absolute path')
    out=out.resolve();out.relative_to(root)
    mf=checked_file(a.manifest,a.manifest_sha,root);repo=a.tcb_repo.resolve(strict=True)
    pairs,input_hashes=preflight(repo,json.loads(mf.read_bytes()),root)
    if digest(mf)!=a.manifest_sha:raise RuntimeError('manifest changed during preflight')
    out.mkdir(parents=True,exist_ok=False);(out/'INCOMPLETE').write_text('Do not use until RUN_SUCCESS exists.\n')
    home=out/'home';home.mkdir()
    base_env={'PATH':'/usr/bin:/bin','HOME':str(home),'GIT_CONFIG_NOSYSTEM':'1','GIT_ATTR_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_TERMINAL_PROMPT':'0','LC_ALL':'C','TZ':'UTC','GIT_AUTHOR_NAME':'Benchmark','GIT_AUTHOR_EMAIL':'benchmark@example.invalid','GIT_COMMITTER_NAME':'Benchmark','GIT_COMMITTER_EMAIL':'benchmark@example.invalid'}
    results={};consumed={}
    for kind,idx,ext in (('json',0,'tui.json'),('protobuf',1,'tui.pb')):
        db=out/kind;db.mkdir();run(db,base_env,'init','-q');parent=None;stage_rows=[];active={}
        for number,stage in enumerate(STAGES):
            if stage in ('base','focused_add','focused_update','browser_add','picker_update'):
                src_stage={'base':'picker_before'}.get(stage,stage);test_id=IDS[src_stage];source,expected_hash=pairs[src_stage][idx]
                if digest(source)!=expected_hash:raise RuntimeError(f'source changed before copy: {source}')
                dest=db/(test_id+'.'+ext);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
                copied_hash=digest(dest)
                if copied_hash!=expected_hash or digest(source)!=expected_hash:raise RuntimeError('copied bytes differ from preflight hash')
                consumed[f'{kind}:{stage}']={'source':str(source),'sha256':copied_hash}
                active[(test_id+'.'+ext)]=expected_hash
            elif stage=='browser_delete':
                (db/(IDS['browser_add']+'.'+ext)).unlink()
                del active[IDS['browser_add']+'.'+ext]
            run(db,base_env,'add','-A');tree=run(db,base_env,'write-tree')
            tree_paths=set(run(db,base_env,'ls-tree','-r','--name-only',tree).splitlines())
            if tree_paths!=set(active):raise RuntimeError(f'committed tree paths mismatch: {kind}:{stage}')
            tree_hashes={}
            for tree_path,expected_hash in active.items():
                content=subprocess.run(['/usr/bin/git','-C',str(db),'cat-file','blob',tree+':'+tree_path],env=base_env,check=True,capture_output=True).stdout
                actual_hash=hashlib.sha256(content).hexdigest()
                if actual_hash!=expected_hash:raise RuntimeError(f'Git tree content differs from source: {kind}:{stage}:{tree_path}')
                tree_hashes[tree_path]=actual_hash
            env=base_env | {'GIT_AUTHOR_DATE':f'@{1700000000+number} +0000','GIT_COMMITTER_DATE':f'@{1700000000+number} +0000'}
            command=['commit-tree',tree]+(['-p',parent] if parent else [])+['-m',f'{number:02d} {stage}']
            parent=run(db,env,*command);run(db,base_env,'update-ref','refs/heads/main',parent)
            stage_rows.append({'stage':stage,'source_commit':REVISIONS.get(stage),'tree':tree,'commit':parent,'tree_blob_sha256':tree_hashes})
        started=time.monotonic();run(db,base_env,'repack','-Adf','--window=10','--depth=50');elapsed=time.monotonic()-started
        packs=sorted((db/'.git/objects/pack').glob('*.pack'))
        if len(packs)!=1:raise RuntimeError('expected one Git pack')
        pack=packs[0];results[kind]={'stages':stage_rows,'pack_bytes':pack.stat().st_size,'pack_sha256':digest(pack),'repack_wall_seconds':elapsed,'git_count_objects':run(db,base_env,'count-objects','-v')}
    if digest(mf)!=a.manifest_sha:raise RuntimeError('input manifest changed during run')
    for path,expected in input_hashes.items():
        if digest(Path(path))!=expected:raise RuntimeError(f'input/proof changed during run: {path}')
    result={'schema':'tuiscotti.reconstructed-real-stages.v1','source_repo':str(repo),'source_commits':REVISIONS,'input_manifest_sha256':a.manifest_sha,'input_hashes':input_hashes,'consumed':consumed,'git_version':subprocess.run(['/usr/bin/git','--version'],capture_output=True,text=True,check=True).stdout.strip(),'environment':base_env,'stages':STAGES,'results':results,'limits':['Reconstructed selected-path histories; fresh paired captures are not original committed values.','Picker seed uses its later parent capture because its original stored baseline blob is unchanged from 17f through ea8; this does not establish identical capture metadata.','No pixel or palette update is measured.','No acceptance or approval is performed.']}
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');(out/'RUN_SUCCESS').write_text(digest(out/'result.json')+'\n')
    print(json.dumps({'result':str(out/'result.json'),'sha256':digest(out/'result.json')}))
if __name__=='__main__':main()
