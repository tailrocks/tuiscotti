#!/usr/bin/env python3
"""Compare isolated same-snapshot captures without reading a JSON sample in the PB writer."""
import argparse, hashlib, json, os, re, subprocess
from pathlib import Path
from oracle_protocol import read_frame, send_request, validate_projection, validate_worker_response, compare_paths

OLD = 'd8d54155947f6303a41dfd6079b53c0abc16f29a'
NEW = '92ef2d9ee082b35f68e066c5129fedbf07675a80'
CASES = {
 '17f03a161fdbab08553e318f07b49d043e5e26eb': {'functional/showcase_fixedcontrols_focused_refused'},
 'f4727e553c68e605dd251c730678bfbf2799a8a5': {'functional/showcase_fixedcontrols_focused_refused'},
 'ea8cf188583be2a390ae65fd9f74d3aeb30492aa': {'functional/showcase_page_pickers'},
 'bdc44737842c4f2b6a4ba7b4814b8fff9f734de2': {'functional/showcase_page_pickers'},
 '01921e962ba674e0399e33246e568bbda6d82f73': {'functional/showcase_fixeddialogs_browser_box'},
}
PATTERN = re.compile(r'^(functional/[a-z0-9_/-]+)\.capture-([0-9a-f]{16})$')
NS = re.compile(r'^process-[0-9]+-[0-9a-f]{32}-[0-9a-f]{4}$')
CAP = 64 * 1024 * 1024

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024): h.update(chunk)
    return h.hexdigest()

def inventory(root, suffix, allowed):
    if not root.is_dir() or root.is_symlink(): raise RuntimeError(f'invalid root: {root}')
    result = {}
    for path in root.rglob('*'):
        if path.is_symlink(): raise RuntimeError(f'symlink not allowed: {path}')
        if path.is_dir(): continue
        if not path.is_file() or not path.name.endswith(suffix): raise RuntimeError(f'unexpected file: {path}')
        rel = path.relative_to(root)
        if len(rel.parts) < 2 or not NS.fullmatch(rel.parts[0]): raise RuntimeError(f'invalid namespace: {path}')
        stem = Path(*rel.parts[1:]).as_posix()[:-len(suffix)]
        match = PATTERN.fullmatch(stem)
        if not match or match.group(1) not in allowed: raise RuntimeError(f'unexpected capture ID: {path}')
        key = (rel.parts[0], match.group(1), match.group(2))
        if key in result: raise RuntimeError(f'duplicate occurrence: {key}')
        if path.stat().st_size > CAP: raise RuntimeError(f'oversized input: {path}')
        result[key] = path
    return result

def project(worker, revision, path, test_id):
    p = subprocess.Popen([str(worker)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
    try:
        send_request(p, 0, test_id, path)
        response = read_frame(p.stdout, 30.0)
        p.stdin.close()
        p.stdin = None
        _, err = p.communicate(timeout=30)
        validate_worker_response(response, 0, test_id, revision)
        if p.returncode != 0 or response.get('ok') is not True: raise RuntimeError(f'worker failed: {err!r} {response}')
        if response.get('original_file_sha256') != digest(path): raise RuntimeError('worker input SHA mismatch')
        return response, validate_projection(response, test_id, revision)
    finally:
        if p.poll() is None: p.kill(); p.wait()

def main():
    ap = argparse.ArgumentParser()
    for flag in ('revision','snapshots','old-json','old-worker','new-worker','pb-writer','test-exit','out','old-worker-sha','new-worker-sha','pb-writer-sha'):
        ap.add_argument('--'+flag, required=True)
    args = ap.parse_args()
    if args.revision not in CASES: raise RuntimeError('unsupported capture revision')
    scratch = Path(os.environ['HISTORY_SCRATCH']).resolve(strict=True)
    for candidate in (args.snapshots, args.old_json, args.test_exit, args.out):
        Path(candidate).resolve().relative_to(scratch)
    if Path(args.test_exit).read_text().strip() != '0': raise RuntimeError('source test did not pass')
    binaries = [(Path(args.old_worker).resolve(strict=True),args.old_worker_sha),(Path(args.new_worker).resolve(strict=True),args.new_worker_sha),(Path(args.pb_writer).resolve(strict=True),args.pb_writer_sha)]
    for path, expected in binaries:
        if not re.fullmatch('[0-9a-f]{64}', expected) or digest(path) != expected: raise RuntimeError(f'binary hash mismatch: {path}')
    snapshots = inventory(Path(args.snapshots), '.snapshot.json', CASES[args.revision])
    old = inventory(Path(args.old_json), '.tui.json', CASES[args.revision])
    if not snapshots or snapshots.keys() != old.keys() or {k[1] for k in snapshots} != CASES[args.revision]:
        raise RuntimeError('capture inventory is incomplete, unexpected, or unpaired')
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    (out/'INCOMPLETE').write_text('Do not use this output until SUCCESS exists.\n')
    rows=[]
    for n,key in enumerate(sorted(snapshots)):
        namespace,test_id,sequence=key
        pb=out/'pairs'/namespace/f'{test_id}.capture-{sequence}.tui.pb'
        pb.parent.mkdir(parents=True,exist_ok=True)
        w=subprocess.run([str(binaries[2][0]),test_id,str(snapshots[key].resolve()),str(pb.resolve())],capture_output=True,text=True,timeout=60,check=True)
        report=json.loads(w.stdout)
        expected={'gate':'state','observation':{},'snapshot_sha256':digest(snapshots[key]),'sample_sha256':digest(pb),'test_id':test_id}
        if report != expected: raise RuntimeError(f'PB writer identity mismatch: {key}')
        old_record,old_sample=project(binaries[0][0],OLD,old[key].resolve(),test_id)
        new_record,new_sample=project(binaries[1][0],NEW,pb.resolve(),test_id)
        count,paths=compare_paths(old_sample,new_sample,'',64)
        if count or old_record['state_digest'] != new_record['state_digest']: raise RuntimeError(f'full-field/digest mismatch: {key} {count} {paths}')
        if old_sample['gate'] != 'state' or old_sample['observation'] != {'note':None} or old_sample['image'] is not None or old_sample['render_contract'] is not None: raise RuntimeError('unexpected domain scope')
        rows.append({'namespace':namespace,'test_id':test_id,'sequence':sequence,'snapshot_sha256':digest(snapshots[key]),'old_json_sha256':digest(old[key]),'new_pb_sha256':digest(pb),'state_digest':old_record['state_digest'],'full_projection_equal_including_metadata':True})
    key=sorted(snapshots)[0]
    namespace,test_id,sequence=key
    raw=snapshots[key].read_bytes()
    match=re.search(rb'(\"captured_at_ms\":)([0-9]+)',raw)
    if match is None or int(match.group(2)) >= (1 << 64)-1: raise RuntimeError('cannot mutate metadata timestamp')
    changed=raw[:match.start(2)]+str(int(match.group(2))+1).encode()+raw[match.end(2):]
    fixture=out/'metadata-control.snapshot.json'
    fixture.write_bytes(changed)
    mutated=out/'metadata-control.tui.pb'
    control=subprocess.run([str(binaries[2][0]),test_id,str(fixture.resolve()),str(mutated.resolve())],capture_output=True,text=True,timeout=60,check=True)
    control_report=json.loads(control.stdout)
    if control_report != {'gate':'state','observation':{},'snapshot_sha256':digest(fixture),'sample_sha256':digest(mutated),'test_id':test_id}: raise RuntimeError('metadata control writer identity mismatch')
    original_record,original=project(binaries[0][0],OLD,old[key].resolve(),test_id)
    changed_record,changed_projection=project(binaries[1][0],NEW,mutated.resolve(),test_id)
    count,paths=compare_paths(original,changed_projection,'',8)
    if count != 1 or paths != ['/snapshot/metadata/captured_at_ms'] or original_record['state_digest'] != changed_record['state_digest']: raise RuntimeError('metadata control failed')
    result={'revision':args.revision,'old_revision':OLD,'new_revision':NEW,'snapshot_transport':'upstream TerminalSnapshot JSON, reconstructed in writer','test_exit':0,'pairs':rows,'metadata_negative_control':{'changed_paths':paths,'state_digest_unchanged':True}}
    (out/'pair-manifest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    (out/'SUCCESS').write_text(digest(out/'pair-manifest.json')+'\n')
    print(json.dumps({'pairs':len(rows),'manifest_sha256':digest(out/'pair-manifest.json')}))
if __name__ == '__main__': main()
