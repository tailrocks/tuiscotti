#!/bin/sh
set -u
root=/private/tmp/tuiscotti-history-execution-20261109
while IFS=" " read -r tag rev testname; do
 mkdir -p "$root/capture-isolated-$tag/snapshots" "$root/capture-isolated-$tag/old-json"
 export HISTORY_TAG="$tag" TUISCOTTI_BENCH_SNAPSHOT_ROOT="$root/capture-isolated-$tag/snapshots" TUISCOTTI_BENCH_OLD_SAMPLE_ROOT="$root/capture-isolated-$tag/old-json" TUISCOTTI_BENCH_TEST_IDS="$root/work/capture-ids.tsv"
 cd "$root/work/tcb-$rev" || exit 1
 "$root/env/run-v3.sh" exec mr-boxington@1.29.2 rust@1.99.1 -- mbx nextest list -p junie-tui --test functional --locked --offline -E "test(=$testname)" > "$root/nextest-list-isolated-$tag.log" 2>&1
 status=$?; printf "%s\n" "$status" > "$root/nextest-list-isolated-$tag.exit"; [ "$status" -eq 0 ] || exit "$status"
 rg -F "junie-tui::functional $testname" "$root/nextest-list-isolated-$tag.log" >/dev/null || exit 99
 "$root/env/run-v3.sh" exec mr-boxington@1.29.2 rust@1.99.1 -- mbx nextest run -p junie-tui --test functional --locked --offline --no-tests fail -E "test(=$testname)" > "$root/capture-isolated-$tag.log" 2>&1
 status=$?; printf "%s\n" "$status" > "$root/capture-isolated-$tag.exit"; [ "$status" -eq 0 ] || exit "$status"
done <<"ROWS"
17f 17f03a161fdbab08553e318f07b49d043e5e26eb showcase::showcase_fixedcontrols_focused_refused
f472 f4727e553c68e605dd251c730678bfbf2799a8a5 showcase::showcase_fixedcontrols_focused_refused
ROWS
