#!/bin/sh
set -eu
SCR=/private/tmp/tuiscotti-history-execution-20261109
export HOME="$SCR/env/home" TMPDIR="$SCR/env/tmp" XDG_CONFIG_HOME="$SCR/env/xdg-config" XDG_CACHE_HOME="$SCR/env/xdg-cache" XDG_STATE_HOME="$SCR/env/xdg-state" XDG_DATA_HOME="$SCR/env/xdg-data"
export PATH="$SCR/cache-v2/mise-data/installs/mr-boxington/1.29.2/.mise-bins:$SCR/cache-v2/cargo-home/bin:/usr/bin:/bin"
export MISE_OFFLINE=1 MISE_DATA_DIR="$SCR/cache-v2/mise-data" MISE_CACHE_DIR="$SCR/cache-v2/mise-cache" MISE_STATE_DIR="$SCR/cache-v2/mise-state" MISE_CONFIG_DIR="$SCR/cache-v2/mise-config" MISE_CONFIG_FILE="$SCR/env/mise-v2.toml" MISE_AUTO_INSTALL=0 MISE_TRUSTED_CONFIG_PATHS="$SCR"
export CARGO_HOME="$SCR/cache-v2/cargo-home" CARGO_TARGET_DIR="$SCR/targets/cargo" CARGO_NET_OFFLINE=true RUSTUP_HOME="$SCR/cache-v2/rustup-home"
export MBX_CACHE_DIR="$SCR/cache-v2/mbx-cache" MBX_TARGET_ROOT="$SCR/targets/mbx" MBX_GC_AUTO=0 GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0
case "${HISTORY_TAG-}" in 17f|f472|019|ea8|bdc) ;; *) echo invalid-history-tag >&2; exit 2;; esac
export CARGO_TARGET_DIR="$SCR/isolated-targets/$HISTORY_TAG/cargo" MBX_TARGET_ROOT="$SCR/isolated-targets/$HISTORY_TAG/mbx" MBX_CACHE_DIR="$SCR/isolated-targets/$HISTORY_TAG/cache"
exec /private/tmp/tuiscotti-history-execution-20261109/env/bin/mise "$@"
