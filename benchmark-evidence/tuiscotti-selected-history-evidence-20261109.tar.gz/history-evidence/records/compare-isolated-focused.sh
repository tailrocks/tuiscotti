#!/bin/sh
set -eu
root=/private/tmp/tuiscotti-history-execution-20261109
export HISTORY_SCRATCH="$root"
while read -r tag rev; do
 /usr/bin/python3 "$root/compare-scoped.py" --revision "$rev" --snapshots "$root/capture-isolated-$tag/snapshots" --old-json "$root/capture-isolated-$tag/old-json" --old-worker "$root/tools/old-reader" --old-worker-sha 1e902359d0bc2036d3e64f0d93dd3c75189e67f0b6d5d4275a592096cf507221 --new-worker "$root/tools/new-reader" --new-worker-sha 698e0b0ed5ce1e8e4b05c5c4336468b0125be8653896d39a16de51e7fa089d0e --pb-writer "$root/tools/writer" --pb-writer-sha c44cd0336a45d7615fc15467625039ac15e0e917822d1ffbf67b0a19ef5840aa --test-exit "$root/capture-isolated-$tag.exit" --out "$root/comparison-isolated-$tag" > "$root/comparison-isolated-$tag.log" 2>&1 || exit $?
done <<"ROWS"
17f 17f03a161fdbab08553e318f07b49d043e5e26eb
f472 f4727e553c68e605dd251c730678bfbf2799a8a5
ROWS
