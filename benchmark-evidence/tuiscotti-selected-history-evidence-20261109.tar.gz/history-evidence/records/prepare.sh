#!/bin/sh
set -eu
# This script only creates isolated source copies and patches; it does not build or capture.
: "${TCB_SOURCE:?Set TCB_SOURCE to a local TCB Git repository}"
: "${TUISCOTTI_SOURCE:?Set TUISCOTTI_SOURCE to a local Tuiscotti Git repository}"
: "${HISTORY_SCRATCH:?Set HISTORY_SCRATCH to a fresh absolute scratch path}"
case "$HISTORY_SCRATCH" in /*) ;; *) echo 'HISTORY_SCRATCH must be absolute' >&2; exit 2;; esac
[ ! -e "$HISTORY_SCRATCH" ] || { echo 'scratch already exists' >&2; exit 2; }
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
python3 - "$HISTORY_SCRATCH" "$TCB_SOURCE" "$TUISCOTTI_SOURCE" <<'PYGUARD'
import os,sys
out=os.path.realpath(sys.argv[1])
for source in map(os.path.realpath, sys.argv[2:]):
    if os.path.commonpath((out, source)) in (out, source):
        raise SystemExit("scratch and source repositories must be disjoint")
PYGUARD
for spec in '17f03a161fdbab08553e318f07b49d043e5e26eb' 'f4727e553c68e605dd251c730678bfbf2799a8a5' '01921e962ba674e0399e33246e568bbda6d82f73' '3f1a69fedea37402d25b947195665a8ea39ff038' 'ea8cf188583be2a390ae65fd9f74d3aeb30492aa' 'bdc44737842c4f2b6a4ba7b4814b8fff9f734de2'; do
  test "$(git -C "$TCB_SOURCE" rev-parse --verify "$spec^{commit}")" = "$spec"
done
OLD=d8d54155947f6303a41dfd6079b53c0abc16f29a
NEW=92ef2d9ee082b35f68e066c5129fedbf07675a80
for spec in "$OLD" "$NEW"; do test "$(git -C "$TUISCOTTI_SOURCE" rev-parse --verify "$spec^{commit}")" = "$spec"; done
mkdir -p "$HISTORY_SCRATCH"
# Never use shared object databases or hardlinks; each repository has its own objects.
git clone --no-local --no-hardlinks --no-checkout "$TUISCOTTI_SOURCE" "$HISTORY_SCRATCH/old-tuiscotti"
git -C "$HISTORY_SCRATCH/old-tuiscotti" checkout --detach "$OLD"
python3 - "$HERE/tee-reference.patch" "$HISTORY_SCRATCH/tee-scoped.patch" <<'PY'
import pathlib,sys
p=pathlib.Path(sys.argv[1]).read_text()
p=p.replace('ids.len() != 1868', 'ids.len() != 4').replace('expected 1,868 IDs', 'expected 4 IDs')
if p.count('ids.len() != 4') != 1: raise SystemExit('unexpected tee patch shape')
pathlib.Path(sys.argv[2]).write_text(p)
PY
git -C "$HISTORY_SCRATCH/old-tuiscotti" apply --check "$HISTORY_SCRATCH/tee-scoped.patch"
git -C "$HISTORY_SCRATCH/old-tuiscotti" apply "$HISTORY_SCRATCH/tee-scoped.patch"
cat > "$HISTORY_SCRATCH/capture-ids.tsv" <<'IDS'
functional/showcase_fixedcontrols_focused_refused
functional/showcase_page_fixedcontrols
functional/showcase_page_pickers
functional/showcase_fixeddialogs_browser_box
IDS
for spec in '17f03a161fdbab08553e318f07b49d043e5e26eb' 'f4727e553c68e605dd251c730678bfbf2799a8a5' '01921e962ba674e0399e33246e568bbda6d82f73' '3f1a69fedea37402d25b947195665a8ea39ff038' 'ea8cf188583be2a390ae65fd9f74d3aeb30492aa' 'bdc44737842c4f2b6a4ba7b4814b8fff9f734de2'; do
  dest="$HISTORY_SCRATCH/tcb-$spec"
  git clone --no-local --no-hardlinks --no-checkout "$TCB_SOURCE" "$dest"
  git -C "$dest" checkout --detach "$spec"
  if rg -q '^\[patch\."https://github.com/tailrocks/tuiscotti"\]' "$dest/Cargo.toml"; then echo "existing patch table: $dest" >&2; exit 2; fi
  printf '\n[patch."https://github.com/tailrocks/tuiscotti"]\ntuiscotti = { path = "../old-tuiscotti/crates/tuiscotti" }\n' >> "$dest/Cargo.toml"
done
printf 'Prepared %s; no build, lockfile update, test, or capture was run.\n' "$HISTORY_SCRATCH"
