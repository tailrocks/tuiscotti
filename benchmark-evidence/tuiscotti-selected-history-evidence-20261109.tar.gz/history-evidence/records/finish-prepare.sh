#!/bin/sh
set -eu
src=/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/paired-oracle-20261108/fresh-capture-prototype/coverage-run/tcb
root=/private/tmp/tuiscotti-history-execution-20261109/work
for rev in 17f03a161fdbab08553e318f07b49d043e5e26eb f4727e553c68e605dd251c730678bfbf2799a8a5 01921e962ba674e0399e33246e568bbda6d82f73 3f1a69fedea37402d25b947195665a8ea39ff038 ea8cf188583be2a390ae65fd9f74d3aeb30492aa bdc44737842c4f2b6a4ba7b4814b8fff9f734de2; do
 dest="$root/tcb-$rev"
 if [ ! -d "$dest/.git" ]; then git clone --no-local --no-hardlinks --no-checkout "$src" "$dest"; fi
 git -C "$dest" fetch --no-tags "$src" "$rev"
 git -C "$dest" checkout --detach "$rev"
 printf '\n[patch."https://github.com/tailrocks/tuiscotti"]\ntuiscotti = { path = "../old-tuiscotti/crates/tuiscotti" }\n' >> "$dest/Cargo.toml"
done
