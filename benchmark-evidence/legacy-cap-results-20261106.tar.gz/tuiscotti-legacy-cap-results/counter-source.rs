use std::io::{self, BufRead};
use tuiscotti::sample::Sample;
fn bound(s: &Sample) -> (usize, usize, usize, usize, usize) {
    let snap = s.snapshot();
    let mut payload = "tuiscotti.sample.v1".len() + s.test_id().len();
    for c in snap.cells() { payload += c.text().len() + c.link_uri().map_or(0,str::len) + c.link_id().map_or(0,str::len); }
    payload += snap.title().map_or(0,str::len) + snap.metadata().backend.len() + snap.metadata().session.len();
    payload += s.observation().note().map_or(0,str::len);
    let mut fonts = 0;
    if let Some(r) = s.render_contract() {
        payload += r.profile().len() + r.renderer_version().len() + r.raster_policy().len() + r.palette_digest().len() + r.platform_key().len();
        fonts = r.fonts().len();
        for f in r.fonts() { payload += f.digest().len(); }
    }
    if let Some(i) = s.image() {
        let b64 = i.png_base64();
        let padding = b64.as_bytes().iter().rev().take_while(|&&b| b == b'=').count();
        payload += i.png_sha256().len() + i.rgba_sha256().len() + b64.len() / 4 * 3 - padding;
    }
    let message = payload + snap.cells().len() * 512 + fonts * 128 + 100_000;
    (message, zstd_safe::compress_bound(message) + 32, payload, snap.cells().len(), fonts)
}
fn main() {
    for line in io::stdin().lock().lines() {
        let path = line.unwrap();
        let result = std::fs::read(&path).map_err(|e| e.to_string()).and_then(|bytes| Sample::from_bytes(&bytes).map_err(|e| e.to_string()));
        match result { Ok(s) => { let (m,f,p,c,n) = bound(&s); println!("OK\t{m}\t{f}\t{p}\t{c}\t{n}\t{path}"); }, Err(e) => println!("ERR\t{path}\t{e}") }
    }
}
