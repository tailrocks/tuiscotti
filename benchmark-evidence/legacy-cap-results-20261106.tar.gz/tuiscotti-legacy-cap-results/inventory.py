import subprocess, pathlib, hashlib, json, sys
out=pathlib.Path(sys.argv[1]); roots=sys.argv[2:]; lines=[]; records=[]
for root in roots:
 paths=subprocess.check_output(['git','-C',root,'ls-files','-z','*.tui.json']).decode().split('\0')[:-1]
 sha=subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip()
 for p in paths:
  path=pathlib.Path(root)/p; b=path.read_bytes(); lines.append(str(path)); records.append({'revision':sha,'path':p,'size':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 print(sha,len(paths))
(out/'current-paths.txt').write_text('\n'.join(lines)+'\n')
(out/'current-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
print('max',max(records,key=lambda x:x['size']) if records else None)
