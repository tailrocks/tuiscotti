#!/usr/bin/env python3
"""Run the selected TCB tests and retain timestamped child-app RSS samples."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import time

REPO = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/tcb-capture-instrumented-534e0ff')
EVIDENCE = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/capture-timing-534e0ff/selected-capture-evidence/warm-rerun')
OUT = EVIDENCE / 'raw-sampled-rerun'
FUNCTIONAL = REPO / 'target/functional'
ENV = {
    'MBX_CACHE_DIR': '/private/tmp/tcb-capture-mbx-isolated-534e0ff-20261108/mbx-cache',
    'MBX_TARGET_ROOT': '/private/tmp/tcb-capture-mbx-isolated-534e0ff-20261108/mbx-target-root',
    'CARGO_TARGET_DIR': '/private/tmp/tcb-capture-mbx-isolated-534e0ff-20261108/cargo-target',
    'MBX_TARGET_VIEWS': '0',
    'MBX_GC_AUTO': '0',
    'MBX_SESSION_GC_AUTO': '0',
    'MBX_GC_MIN_FREE_SIZE': 'none',
}
TEST_ARGS = [
    'mise', 'exec', '--', 'mbx', 'nextest', 'run', '--workspace', '--locked', '--offline',
    '--filter-expr',
    'test(holla::holla_help_overlay) | test(showcase::showcase_page_diff) | test(tablepro::tablepro_resize_and_too_small_recovers)',
    '--jobs', '1',
]
COMMAND = 'env ' + ' '.join(f'{k}={v}' for k, v in ENV.items()) + ' /usr/bin/time -l ' + ' '.join(
    "'" + x.replace("'", "'\\''") + "'" if ' ' in x or '|' in x or '(' in x else x for x in TEST_ARGS
)
APP_PREFIX = ENV['CARGO_TARGET_DIR'] + '/debug/'
APP_NAMES = ('holla', 'showcase', 'tablepro')


def sha_manifest():
    entries = []
    for path in sorted((REPO / 'tests/functional/baselines').rglob('*.tui.pb')):
        entries.append(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path}')
    return '\n'.join(entries) + '\n'


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'command.txt').write_text(f'Working directory: {REPO}\n{COMMAND}\n')
    (OUT / 'environment.txt').write_text('\n'.join(f'{k}={v}' for k, v in ENV.items()) + '\n')
    (OUT / 'sampling-method.txt').write_text(
        'A standalone Python supervisor runs the command above from the stated cwd. '
        'While it runs, it polls `/bin/ps -A -o pid=,rss=,command=` every 0.1 seconds. '
        'It records UTC timestamp, PID, RSS KiB, matched app, and full ps command for each sample '
        'whose command contains an isolated-target debug binary holla, showcase, or tablepro. '
        'Sampling can miss brief processes/peaks; these are observed samples, not guaranteed RSS maxima.\n'
    )
    before_dirs = {p.name for p in FUNCTIONAL.iterdir() if p.is_dir()} if FUNCTIONAL.exists() else set()
    before = sha_manifest()
    (OUT / 'baselines-before.sha256').write_text(before)
    env = os.environ.copy()
    env.update(ENV)
    samples = []
    start = time.monotonic()
    pattern = APP_PREFIX
    with (OUT / 'run.log').open('wb') as log:
        proc = subprocess.Popen(['/bin/zsh', '-lc', COMMAND], cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
        while proc.poll() is None:
            elapsed = time.monotonic() - start
            stamp = datetime.now(timezone.utc).isoformat(timespec='milliseconds')
            ps = subprocess.run(['/bin/ps', '-A', '-o', 'pid=,rss=,command='], capture_output=True, text=True)
            for line in ps.stdout.splitlines():
                parts = line.strip().split(None, 2)
                if len(parts) < 3 or pattern not in parts[2]:
                    continue
                command = parts[2]
                app = next((name for name in APP_NAMES if f'{pattern}{name}' in command), None)
                if app is None:
                    continue
                try:
                    pid, rss_kib = int(parts[0]), int(parts[1])
                except ValueError:
                    continue
                samples.append((stamp, elapsed, app, pid, rss_kib, command))
            time.sleep(0.1)
        exit_code = proc.wait()
    with (OUT / 'rss-samples.tsv').open('w') as f:
        f.write('timestamp_utc\telapsed_seconds\tapp\tpid\trss_kib\tps_command\n')
        for row in samples:
            f.write('\t'.join(str(x) for x in row) + '\n')
    after = sha_manifest()
    (OUT / 'baselines-after.sha256').write_text(after)
    new_dirs = sorted((p for p in FUNCTIONAL.iterdir() if p.is_dir() and p.name not in before_dirs), key=lambda p: p.name)
    for src in new_dirs:
        if (src / 'capture-timings.jsonl').exists():
            shutil.copytree(src, OUT / 'sessions' / src.name, dirs_exist_ok=True)
    by_app = {}
    for app in APP_NAMES:
        group = [s for s in samples if s[2] == app]
        if group:
            maximum = max(group, key=lambda s: s[4])
            by_app[app] = {
                'sample_count': len(group), 'max_observed_rss_kib': maximum[4],
                'max_sample_pid': maximum[3], 'max_sample_timestamp_utc': maximum[0],
                'first_sample_timestamp_utc': group[0][0], 'last_sample_timestamp_utc': group[-1][0],
            }
    capture_rows = []
    visual_count = 0
    all_ns = []
    for path in sorted((OUT / 'sessions').glob('*/capture-timings.jsonl')):
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        ns = sorted(r['elapsed_ns'] for r in rows if r['callsite'] == 'screen' and r['status'] == 'ok')
        all_ns.extend(ns)
        actions = (path.parent / 'actions.txt').read_text().splitlines()
        passed = [line for line in actions if line.startswith('visual ') and line.endswith(' pass')]
        visual_count += len(passed)
        capture_rows.append({'session': path.parent.name, 'screen_calls': len(ns), 'passing_visual_gates': passed})
    all_ns.sort()
    summary = {
        'exit_code': exit_code, 'elapsed_wall_including_test_and_sampling_seconds': time.monotonic() - start,
        'selected_tests': ['holla::holla_help_overlay', 'showcase::showcase_page_diff', 'tablepro::tablepro_resize_and_too_small_recovers'],
        'session_count': len(capture_rows), 'passing_visual_gate_count': visual_count,
        'screen_capture_calls': len(all_ns), 'pooled_median_us': (statistics.median(all_ns) / 1000 if all_ns else None),
        'p95_rule': 'sorted_values[floor(0.95 * (n - 1))]',
        'pooled_p95_us': (all_ns[int(.95 * (len(all_ns)-1))] / 1000 if len(all_ns) else None),
        'pooled_max_us': (max(all_ns) / 1000 if all_ns else None),
        'app_rss_samples': by_app, 'session_summaries': capture_rows,
        'baseline_file_count': sum(1 for line in before.splitlines() if line),
        'baseline_manifests_equal': before == after,
        'sampling_interval_seconds': 0.1,
        'sampling_caveat': 'ps sampling can miss brief processes and memory peaks; RSS values are observed samples, not hard maxima.',
    }
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (OUT / 'exit_code.txt').write_text(str(exit_code) + '\n')
    if exit_code:
        raise SystemExit(exit_code)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
