# Warm rerun with standalone RSS sampling

`standalone-rss-runner.py` is the saved runner. It launches the command in `command.txt` from the recorded working directory and polls app processes with `/bin/ps -A -o pid=,rss=,command=` every 0.1 seconds. `rss-samples.tsv` retains each observed sample with UTC time, elapsed seconds, app name, PID, RSS in KiB, and full process command. The command output including stderr is `run.log`.

Three selected tests passed (2,021 skipped) with five passing visual-gate actions. Nextest run ID: `42bb0561-ad9e-4be7-a9c0-b49de9a363e1`. The four session folders contain raw capture timings, test actions, and binary identity. The compact archive excludes checkpoint frame payloads.

The run measured 225 ordinary `screen()` capture calls: median 128.041 µs, p95 137.792 µs using `sorted_values[floor(0.95 * (n - 1))]`, maximum 329.833 µs. The timer covers only `Session::capture_snapshot(ActiveScreen)`; it excludes waits, child lifecycle, frozen comparisons, and post-return hashing/logging.

Observed per-app RSS samples: Holla 9,488 KiB (12 samples), Showcase 12,576 KiB (12), and TablePro 6,944 KiB (56 across the resize/workbench and nocolor sessions). These are sampled observations, not guaranteed maxima; brief peaks can fall between polls. No aggregate `/usr/bin/time` RSS is attributed to individual app processes.

Before the run, read-only MBX settings confirmed `gc.auto=false`, cache `/private/tmp/tcb-capture-mbx-isolated-534e0ff-20261108/mbx-cache`, target root `/private/tmp/tcb-capture-mbx-isolated-534e0ff-20261108/mbx-target-root`, and `target.views=false`; complete query output is in `preflight-settings.log`. GC was not reported in the run log. Tool versions are retained.

The pre-run and post-run manifests cover 1,990 baseline PB files and match byte-for-byte. No baseline acceptance or conversion was performed. This is a single exploratory sample from an instrumented disposable checkout, not a comparative claim or completion of the full benchmark requirements.
