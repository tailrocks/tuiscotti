from pathlib import Path
import csv, hashlib, json, os, re, statistics, subprocess, time

root=Path('/private/tmp/tuiscotti-full-corpus-followup-20261108')
repo=Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/real-history-pr2-main/repo')
commit='534e0ff5af75b840d93038dd02ece0839cf4f71b'
cli=Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/current-main-clone/target/release/tuiscotti')
out_root=root/'full-tcb-534e0ff-render'
out_root.mkdir(exist_ok=False)
process_wall_cap_s=3600.0
process_rss_cap_bytes=1_073_741_824
pass_wall_cap_s=3600.0

inventory={r['path']:r for r in csv.DictReader(open(root/'tcb-534e0ff-sample-inventory.tsv'),delimiter='\t')}
raw=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only','-z',commit],text=False)
paths=sorted((repo/x.decode() for x in raw.split(b'\0') if x.endswith(b'.tui.pb')),key=lambda p:str(p))
if len(paths)!=2117: raise SystemExit(f'expected 2117 committed PB paths, got {len(paths)}')
if not cli.is_file(): raise SystemExit('release CLI binary is absent')

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def root_stratum(rel):
 s=rel.as_posix()
 if s.startswith('tests/functional/baselines/pre_refactor/'):return 'protected_historical_root'
 if s.startswith('tests/functional/baselines/functional/'):return 'selected_functional_root'
 if s.startswith('apps/jackin/tests/functional/baselines/functional/'):return 'selected_jackin_root'
 if s.startswith('tests/functional/baselines/showcase/buttons/'):return 'selected_buttons_root'
 if s.startswith('scripts/coverage-fixtures/'):return 'invalid_coverage_fixture'
 return 'other_repo_pb'

env=os.environ.copy(); env['MBX_GC_AUTO']='false'; env.pop('CI',None)
records=[]; results_by_path={}; start=time.monotonic(); before={}; outputs=[]
with (out_root/'raw-render-results.jsonl').open('w') as log, (out_root/'progress.log').open('w') as progress:
 for i,path in enumerate(paths,1):
  elapsed=time.monotonic()-start
  if elapsed>pass_wall_cap_s:
   records.append({'path':str(path),'error':'pass wall cap reached before this sample','index':i})
   continue
  rel=path.relative_to(repo); rels=rel.as_posix(); key=hashlib.sha256(rels.encode()).hexdigest()[:20]
  if not path.is_file():
   row={'path':rels,'path_sha256_prefix':key,'error':'committed input absent from retained worktree','stratum':root_stratum(rel)}
   records.append(row); log.write(json.dumps(row,sort_keys=True)+'\n'); log.flush(); continue
  input_hash=sha(path); size=path.stat().st_size; before[rels]=input_hash
  output=out_root/'png'/f'{key}.png'; output.parent.mkdir(exist_ok=True)
  cmd=['/usr/bin/time','-l',str(cli),'--json','render','--sample',str(path),'--out',str(output)]
  began=time.monotonic()
  try:
   proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=process_wall_cap_s)
   proc_wall=time.monotonic()-began; stdout=proc.stdout; stderr=proc.stderr; rc=proc.returncode
  except subprocess.TimeoutExpired as e:
   proc_wall=time.monotonic()-began; stdout=e.stdout or ''; stderr=e.stderr or ''; rc=124
  cli_json=None
  try:cli_json=json.loads(stdout)
  except Exception:pass
  m=re.search(r'([0-9.]+) real\s+([0-9.]+) user\s+([0-9.]+) sys',stderr)
  rss_m=re.search(r'([0-9]+)\s+maximum resident set size',stderr)
  child_time={'wall_s':float(m.group(1)),'user_s':float(m.group(2)),'sys_s':float(m.group(3))} if m else None
  rss=int(rss_m.group(1)) if rss_m else None
  success=bool(rc==0 and cli_json and cli_json.get('status')=='pass' and output.is_file())
  out_hash=None; out_size=0; width=height=0; out_error=None
  if success:
   data=output.read_bytes(); out_size=len(data)
   if len(data)<24 or data[:8]!=b'\x89PNG\r\n\x1a\n': success=False;out_error='invalid PNG signature/length'
   else:
    width=int.from_bytes(data[16:20],'big');height=int.from_bytes(data[20:24],'big');out_hash=hashlib.sha256(data).hexdigest();outputs.append((output,out_hash))
  if rss is not None and rss>process_rss_cap_bytes:
   success=False;out_error='process exceeded 1 GiB RSS cap'
  if proc_wall>process_wall_cap_s:
   success=False;out_error='process exceeded 3600 s wall cap'
  inv=inventory.get(str(path),{})
  record={'index':i,'path':rels,'path_sha256_prefix':key,'stratum':root_stratum(rel),'input_bytes':size,'input_sha256':input_hash,'inventory_gate':inv.get('gate'),'inventory_grid':f"{inv.get('cols','')}x{inv.get('rows','')}",'inventory_wide_cells':inv.get('wide_cells'),'inventory_nonascii_cells':inv.get('nonascii_cells'),'inventory_linked_cells':inv.get('linked_cells'),'inventory_unique_styles':inv.get('unique_styles'),'inventory_png_bytes':inv.get('png_bytes'),'return_code':rc,'cli_status':(cli_json or {}).get('status'),'cli_reason':(cli_json or {}).get('reason'),'cli_error_code':(cli_json or {}).get('error_code'),'child_time':child_time,'wrapper_wall_s':proc_wall,'max_rss_bytes':rss,'output_path':str(output) if output.exists() else None,'output_sha256':out_hash,'output_bytes':out_size,'image_width_px':width,'image_height_px':height,'success':success,'output_error':out_error,'stdout_json':stdout.strip(),'time_stderr':stderr}
  records.append(record); results_by_path[rels]=record
  log.write(json.dumps(record,sort_keys=True)+'\n'); log.flush()
  if i%100==0:
   progress.write(f'{i}/{len(paths)} elapsed_s={time.monotonic()-start:.1f} success={sum(r.get("success",False) for r in records)} errors={sum(not r.get("success",False) for r in records)}\n');progress.flush()
  if rss is not None and rss>process_rss_cap_bytes:
   progress.write(f'stopped after RSS cap on {rels}\n');progress.flush();break
end=time.monotonic(); after={}
for path in paths:
 if path.is_file():after[path.relative_to(repo).as_posix()]=sha(path)
(out_root/'input-hashes-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
(out_root/'input-hashes-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
changed=[p for p,h in before.items() if after.get(p)!=h]
valid=[r for r in records if r.get('success')]
by={}
for r in records:by.setdefault(r.get('stratum','unknown'),[]).append(r)
strata={}
for name,rs in by.items():
 ok=[r for r in rs if r.get('success')]
 child=[r['child_time'] for r in ok if r.get('child_time')]
 strata[name]={'files_attempted':len(rs),'success':len(ok),'errors':len(rs)-len(ok),'input_bytes':sum(r.get('input_bytes',0) for r in rs),'output_png_bytes':sum(r.get('output_bytes',0) for r in ok),'median_child_wall_s':statistics.median([x['wall_s'] for x in child]) if child else None,'range_child_wall_s':[min(x['wall_s'] for x in child),max(x['wall_s'] for x in child)] if child else None,'max_rss_bytes':max([r.get('max_rss_bytes') or 0 for r in ok],default=0),'grids':{}}
 for r in ok:
  grid=r.get('inventory_grid','')
  strata[name]['grids'][grid]=strata[name]['grids'].get(grid,0)+1
summary={'source_commit':commit,'source_worktree':str(repo),'source_worktree_was_read_only':True,'cli_binary_sha256':sha(cli),'cli_binary_path':str(cli),'operation':'one CLI render --out .png per committed .tui.pb path; no check, accept, or capture command','input_paths_total':len(paths),'attempted':len(records),'success':len(valid),'errors':len(records)-len(valid),'wall_time_s':end-start,'max_process_wall_cap_s':process_wall_cap_s,'max_pass_wall_cap_s':pass_wall_cap_s,'max_process_rss_cap_bytes':process_rss_cap_bytes,'max_observed_child_rss_bytes':max([r.get('max_rss_bytes') or 0 for r in valid],default=0),'max_observed_child_wall_s':max([r['child_time']['wall_s'] for r in valid if r.get('child_time')],default=0),'input_files_unchanged':not changed,'changed_inputs':changed,'output_png_files':len(outputs),'total_output_png_bytes':sum((out.stat().st_size for out,_ in outputs),0),'strata':strata,'error_records':[{'path':r.get('path'),'stratum':r.get('stratum'),'rc':r.get('return_code'),'status':r.get('cli_status'),'error_code':r.get('cli_error_code'),'output_error':r.get('output_error'),'stdout_json':r.get('stdout_json')} for r in records if not r.get('success')]}
(out_root/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
if changed:raise SystemExit('input bytes changed during render measurement')
