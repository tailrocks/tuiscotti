# Exact-commit full-corpus render-read follow-up

This is an external, reproducible record for one serial CLI `render --out` pass over every committed `.tui.pb` in TCB commit `534e0ff5af75b840d93038dd02ece0839cf4f71b`. The source worktree was read-only. It contains inventory metadata, the runner, per-sample records, captured input hashes, command output, and final summary. Rendered PNGs (about 382 MB) are intentionally not included here; they remain in `/private/tmp/tuiscotti-full-corpus-followup-20261108/full-tcb-534e0ff-render/png/` on the measurement host and every successful PNG's SHA-256 and size is in `raw-render-results.jsonl`.

## Input-to-commit verification

After the render run, the read-only source checkout was verified clean at the stated TCB commit. The verifier hashes every current working-tree PB as a Git blob and SHA-256, then compares it with the commit tree object, the pre/post input manifests, the per-sample render record, and its recorded input size. All 2,117 inputs matched all four identities. The JSON summary, per-path TSV, and verifier are included. To repeat this binding check, use the original clean TCB checkout and run:

```sh
python3 render-read/verify-render-input-commit.py --repo /path/to/clean/tcb-at-534e0ff --evidence render-read
```

## Replay context

The runner uses absolute paths for the retained source repo and release CLI. On the original host, replay with:

```sh
/usr/bin/python3 /private/tmp/tuiscotti-full-corpus-followup-20261108/run-full-tcb-render.py
```

The release CLI was built from the isolated Tuiscotti checkout at PR head `52cbf592c950eef5afa89816ff071bcc0d2842ce`; its SHA-256 was `4c39bc547a0444e5b41d3ac9f5ddb2aaddcb7b9dca30913d5771208b2a15712c`. The exact corpus source was TCB commit `534e0ff5af75b840d93038dd02ece0839cf4f71b` in the retained clean repo. The script fixes `MBX_GC_AUTO=false`, removes `CI`, reads all 2,117 committed `.tui.pb` paths from that Git tree and emits one CLI render per path. Each child has a 3,600-second subprocess timeout. The runner checks the measured child RSS against 1 GiB only after that child exits, and checks the 3,600-second pass deadline between child launches; these are not hard RSS or overall-pass kill limits. The observed maximums were far below those thresholds. Filesystem page cache was warm from the preceding inventory read. The host was concurrently loaded, so timings are descriptive feasibility data, not an isolated performance comparison.

The command does **not** measure live capture, encode/decode codec cost, `check`, `accept`, or pixel comparison. It is a state-sample render-read workload. No source or baseline files were written.

## Results

- 2,117 files attempted; 2,055 rendered successfully; 62 returned errors.
- Errors: 8 intentionally truncated coverage-fixture PBs (`INVALID_SAMPLE`); 54 valid samples failed with missing pinned-font glyphs: 45 U+26B7, 6 U+2387, and one each U+1F469, U+29C9, and U+26BF (`MISSING_GLYPH`). These errors span 51 protected historical-root samples and 3 selected functional samples; they were not silently dropped.
- Successful PNG outputs total 381,590,165 bytes. All 2,055 output files were present and their SHA-256 values matched the per-sample records.
- Measured pass wall time: 260.15 s. Maximum per-child wall time: 0.75 s; maximum per-child RSS: 137,478,144 bytes. Successful-child median wall by root: protected historical 0.09 s, selected functional 0.14 s, selected Jackin 0.13 s, selected buttons 0.13 s, other repo PBs 0.145 s.
- The 1,868 PBs under `pre_refactor/` are protected historical-root samples, some with live test consumers; they are not characterized as inactive archives.
- The 179 selected current roots are counted separately: 121 functional, 57 Jackin, and 1 buttons. The additional 70 repo PBs include 62 valid samples and 8 invalid fixtures.
- Input hashes before and after are byte-identical.

See `summary.json` for full strata and error records, `raw-render-results.jsonl` for each sample's input/output identity and child time/CPU/RSS, and `tcb-534e0ff-sample-inventory.tsv` for decoded fields and validity.

## Source binding verification files

```text
verify-render-input-commit.py 293270ff69beef1ac6256a2d30017ce8570eed744b0f84660c0135dda23c04cb
source-blob-verification.json 8e43d6867c94be7aefb6589a3843048448c3dac19316fb32bd34187593e6580e
source-blob-verification.tsv 2db55305167488194bc95a3ba0beece454aa5df7a45e10926775dc6172a47697
```

## Evidence file hashes (SHA-256)

```text
summary.json e0a5f6e1a3506e8ddaf5a436b1525443becc1b57bcc282b317c0c857de8ea897
raw-render-results.jsonl 537e39ee09b6fed4b32878a65be41c74d4a5db2cdbdb4a4d6e44fbd0e1b81be9
tcb-534e0ff-sample-inventory.tsv 6273facd515a5bc717e44558c337df43c6175f2370cc5374bb6a75e7992454fa
run-full-tcb-render.py ba8688fc6b49e3063af0bd8fccf2298ac57c5c76a1a6c5b5a1d496de8b577991
sample-inventory.rs b3e3b8fe84c6929bb0583f8fbc36286be18c564803d1f0be2771b91fc57f2db2
input-hashes-before.json 5997d54b9bb9d948073902027180c8401df23c91198dec881215f4c3d9bf4e04
input-hashes-after.json 5997d54b9bb9d948073902027180c8401df23c91198dec881215f4c3d9bf4e04
full-run.stdout.log 75f689793dd401de4e1d47cc98a6c642a81768a84cac7c2bc4c75c46f0e5d62a
full-host-before.txt cf098e8b44740e7f4ceeb7b347dac0bbfb46aaa0c7f74c225068abef3f60296f
progress.log b4d3c28ef16b6843c33251b448caa47961391c0d5a09babed8e575c2b1476ec6
```
