use std::collections::HashSet;
use std::path::Path;
use tuiscotti::Sample;

fn main() {
    println!("path\tbytes\tgate\tcols\trows\tcells\tnonempty_text_cells\tunique_texts\tnonascii_cells\twide_cells\tcontinuation_cells\tlinked_cells\tunique_links\tunique_styles\tunique_fg_refs\tunique_bg_refs\tunique_palette_colors\tmetadata_source\tcaptured_at_ms\trevision\tbackend_present\tobservation_note\tpng_bytes\tpng_share_ppm\tresult");
    for path in std::env::args().skip(1) {
        let p=Path::new(&path);
        let bytes=std::fs::metadata(p).map(|m|m.len()).unwrap_or(0);
        match Sample::from_file(p) {
            Err(e)=>println!("{}\t{}\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdecode_error:{}",path,bytes,e),
            Ok(sample)=>{
                let s=sample.snapshot();
                let mut texts=HashSet::new(); let mut styles=HashSet::new();
                let mut fgs=HashSet::new(); let mut bgs=HashSet::new(); let mut links=HashSet::new();
                let mut nonempty=0u64; let mut nonascii=0u64; let mut wide=0u64; let mut cont=0u64; let mut linked=0u64;
                for c in s.cells() {
                    if !c.text().is_empty(){nonempty+=1;texts.insert(c.text().to_owned());}
                    if c.text().chars().any(|ch|!ch.is_ascii()){nonascii+=1;}
                    if c.width()>1{wide+=1;}
                    if c.is_continuation(){cont+=1;}
                    if let Some(uri)=c.link_uri(){linked+=1;links.insert(uri.to_owned());}
                    let d=format!("{:?}",c);
                    let flags=["bold","dim","italic","inverse","invisible","strike","blink"]
                        .iter().map(|name|format!("{}={}",name,d.contains(&format!(", {name}: true,"))))
                        .collect::<Vec<_>>().join(",");
                    styles.insert(format!("w={};fg={:?};bg={:?};underline={:?};uc={:?};{};link={}",c.width(),c.fg(),c.bg(),c.underline(),c.underline_color(),flags,c.link_uri().is_some()));
                    fgs.insert(format!("{:?}",c.fg())); bgs.insert(format!("{:?}",c.bg()));
                }
                let palette=s.palette().iter().map(|x|format!("{:?}",x)).collect::<HashSet<_>>().len();
                let image=sample.image();
                let png_bytes=image.map(|im|{let n=im.png_base64().len(); let pad=im.png_base64().as_bytes().iter().rev().take_while(|b|**b==b'=').count(); (n/4*3).saturating_sub(pad)}).unwrap_or(0);
                let share=if bytes==0{0}else{png_bytes.saturating_mul(1_000_000)/bytes as usize};
                let m=s.metadata();
                println!("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{:?}\t{}\t{}\t{}\t{}\t{}\t{}\tok",
                    path,bytes,sample.gate().as_str(),s.cols(),s.rows(),s.cells().len(),nonempty,texts.len(),nonascii,wide,cont,linked,links.len(),styles.len(),fgs.len(),bgs.len(),palette,m.source,m.captured_at_ms,m.revision,!m.backend.is_empty(),sample.observation().note().is_some(),png_bytes,share);
            }
        }
    }
}
