#!/usr/bin/env python3
"""Run exact selected capture tests while recording source/binary bindings."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import statistics
import subprocess
import time

REPO = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/tcb-capture-sourcebound-534e0ff-20261108')
ROOT = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/capture-timing-534e0ff/source-bound-repro-20261108')
OUT = ROOT / 'warm-run-mise-trusted-20261108'
TARGET = Path('/private/tmp/tcb-sourcebound-repro-534e0ff-20261108/cargo-target')
TEST_BIN = TARGET / 'debug/deps/functional-0dd3854c7f19554a'
PATH_VALUE = '/Users/donbeave/.local/share/mise/installs/rust/1.99.1/bin:/Users/donbeave/.local/share/mise/installs/aqua-nextest-rs-nextest-cargo-nextest/latest:/Users/donbeave/.local/share/mise/installs/mr-boxington/latest/.mise-bins:/Users/donbeave/.cargo/bin:/usr/bin:/bin'
ENV = {
    'PATH': PATH_VALUE,
    'MBX_CACHE_DIR': '/private/tmp/tcb-sourcebound-repro-534e0ff-20261108/mbx-cache',
    'MBX_TARGET_ROOT': '/private/tmp/tcb-sourcebound-repro-534e0ff-20261108/mbx-target-root',
    'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_HOME': '/private/tmp/tcb-sourcebound-repro-534e0ff-20261108/cargo-home',
    'MBX_TARGET_VIEWS': '0', 'MBX_GC_AUTO': '0', 'MBX_SESSION_GC_AUTO': '0',
    'MBX_GC_MIN_FREE_SIZE': 'none',
}
FILTER = 'test(holla::holla_help_overlay) | test(showcase::showcase_page_diff) | test(tablepro::tablepro_resize_and_too_small_recovers)'
COMMAND = ['/Users/donbeave/.local/share/mise/shims/mise', 'exec', '--', 'mbx', 'nextest', 'run', '--workspace', '--locked', '--offline', '--filter-expr', FILTER, '--jobs', '1']
APP_NAMES = ('holla', 'showcase', 'tablepro')
APP_PREFIX = str(TARGET / 'debug') + '/'


def run_git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def git_status() -> str:
    return run_git('status', '--short', '--branch', '--untracked-files=all').decode()


def diff_bytes() -> bytes:
    return run_git('diff', '--binary', 'HEAD')


def baseline_manifest() -> str:
    files = sorted((REPO / 'tests/functional/baselines').rglob('*.tui.pb'))
    return ''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p}\n' for p in files)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    if run_git('rev-parse', 'HEAD').decode().strip() != '534e0ff5af75b840d93038dd02ece0839cf4f71b':
        raise SystemExit('source HEAD mismatch')
    status = git_status()
    names = run_git('diff', '--name-only', 'HEAD').decode().splitlines()
    if names != ['tests/functional/support.rs']:
        raise SystemExit(f'unexpected source changes: {names}')
    patch = diff_bytes()
    original_patch = (ROOT.parent / 'capture-instrumentation.patch').read_bytes()
    if patch != original_patch:
        raise SystemExit('instrumentation diff differs from reviewed patch')
    test_before = sha(TEST_BIN)
    instrumented_source_before = sha(REPO / 'tests/functional/support.rs')
    baseline_before = baseline_manifest()
    (OUT / 'source-status-before-run.txt').write_text(status)
    (OUT / 'full-source-diff-before-run.patch').write_bytes(patch)
    (OUT / 'baseline-manifest-before.sha256').write_text(baseline_before)
    (OUT / 'test-binary-sha256-before.txt').write_text(f'{test_before}  {TEST_BIN}\n')
    (OUT / 'instrumented-support-sha256-before.txt').write_text(f'{instrumented_source_before}  {REPO}/tests/functional/support.rs\n')
    shutil.copy2(ROOT / 'test-binary-binding.json', OUT / 'test-binary-binding.json')
    before_dirs = {p.name for p in (REPO / 'target/functional').iterdir() if p.is_dir()} if (REPO / 'target/functional').exists() else set()
    (OUT / 'command.txt').write_text(
        f'Working directory: {REPO}\n'
        f"Command argv (JSON; subprocess shell=False): {json.dumps(COMMAND)}\n"
        f'Environment file: environment.txt\n'
        'The command runs with MBX_GC_AUTO=0 and MBX_SESSION_GC_AUTO=0.\n'
    )
    (OUT / 'environment.txt').write_text('\n'.join(f'{k}={v}' for k, v in ENV.items()) + '\n')
    (OUT / 'sampling-method.txt').write_text(
        'The saved Python runner starts the exact command in command.txt with subprocess argv (no shell). '
        'It polls /bin/ps -A -o pid=,rss=,command= every 0.1 seconds and writes one TSV row per matched child app sample. '
        'Samples can miss brief processes/peaks and are not hard maxima.\n'
    )
    samples = []
    start = time.monotonic()
    with (OUT / 'run.log').open('wb') as log:
        proc = subprocess.Popen(COMMAND, cwd=REPO, env={**os.environ, **ENV}, stdout=log, stderr=subprocess.STDOUT)
        while proc.poll() is None:
            elapsed = time.monotonic() - start
            stamp = datetime.now(timezone.utc).isoformat(timespec='milliseconds')
            ps = subprocess.run(['/bin/ps', '-A', '-o', 'pid=,rss=,command='], capture_output=True, text=True)
            for line in ps.stdout.splitlines():
                parts = line.strip().split(None, 2)
                if len(parts) < 3 or APP_PREFIX not in parts[2]:
                    continue
                command = parts[2]
                app = next((name for name in APP_NAMES if f'{APP_PREFIX}{name}' in command), None)
                if app is None:
                    continue
                try:
                    samples.append((stamp, elapsed, app, int(parts[0]), int(parts[1]), command))
                except ValueError:
                    continue
            time.sleep(0.1)
        exit_code = proc.wait()
    with (OUT / 'rss-samples.tsv').open('w') as f:
        f.write('timestamp_utc\telapsed_seconds\tapp\tpid\trss_kib\tps_command\n')
        for row in samples:
            f.write('\t'.join(str(x) for x in row) + '\n')
    status_after = git_status()
    diff_after = diff_bytes()
    test_after = sha(TEST_BIN)
    source_after = sha(REPO / 'tests/functional/support.rs')
    baseline_after = baseline_manifest()
    (OUT / 'source-status-after-run.txt').write_text(status_after)
    (OUT / 'full-source-diff-after-run.patch').write_bytes(diff_after)
    (OUT / 'baseline-manifest-after.sha256').write_text(baseline_after)
    (OUT / 'test-binary-sha256-after.txt').write_text(f'{test_after}  {TEST_BIN}\n')
    (OUT / 'instrumented-support-sha256-after.txt').write_text(f'{source_after}  {REPO}/tests/functional/support.rs\n')
    new_dirs = sorted((p for p in (REPO / 'target/functional').iterdir() if p.is_dir() and p.name not in before_dirs), key=lambda p: p.name)
    for src in new_dirs:
        if (src / 'capture-timings.jsonl').exists():
            shutil.copytree(src, OUT / 'sessions' / src.name, dirs_exist_ok=True)
    all_ns = []
    summaries = []
    visual_gates = []
    for p in sorted((OUT / 'sessions').glob('*/capture-timings.jsonl')):
        rows = [json.loads(line) for line in p.read_text().splitlines()]
        ns = sorted(r['elapsed_ns'] for r in rows if r['callsite'] == 'screen' and r['status'] == 'ok')
        all_ns.extend(ns)
        actions = (p.parent / 'actions.txt').read_text().splitlines()
        passed = [line for line in actions if line.startswith('visual ') and line.endswith(' pass')]
        visual_gates.extend(passed)
        session = json.loads((p.parent / 'session.json').read_text())
        summaries.append({'session': p.parent.name, 'screen_calls': len(ns), 'binary_path': session['binary_path'], 'binary_sha256': session['binary_sha256'], 'passing_visual_gates': passed})
    all_ns.sort()
    app_rss = {}
    for app in APP_NAMES:
        rows = [r for r in samples if r[2] == app]
        if rows:
            maximum = max(rows, key=lambda r: r[4])
            app_rss[app] = {'sample_count': len(rows), 'max_observed_rss_kib': maximum[4], 'max_sample_pid': maximum[3], 'max_sample_timestamp_utc': maximum[0]}
    run_text = (OUT / 'run.log').read_text(errors='replace')
    run_id_match = re.search(r'Nextest run ID ([0-9a-f-]+)', run_text)
    run_summary = re.search(r'Summary \[.*?\] (\d+) tests run: (\d+) passed(?:, (\d+) failed)?, (\d+) skipped', run_text)
    result = {
        'exit_code': exit_code, 'run_id': run_id_match.group(1) if run_id_match else None,
        'source_commit': run_git('rev-parse', 'HEAD').decode().strip(),
        'source_status_before_run': status, 'source_status_after_run': status_after,
        'changed_paths_before_run': names, 'changed_paths_after_run': run_git('diff', '--name-only', 'HEAD').decode().splitlines(),
        'full_diff_matches_instrumentation_patch_before': patch == original_patch,
        'full_diff_unchanged_across_run': patch == diff_after,
        'instrumented_support_sha256_before': instrumented_source_before, 'instrumented_support_sha256_after': source_after,
        'test_binary_path': str(TEST_BIN), 'test_binary_sha256_before': test_before, 'test_binary_sha256_after': test_after,
        'test_binary_unchanged_across_run': test_before == test_after,
        'baseline_file_count': sum(1 for line in baseline_before.splitlines() if line),
        'baseline_manifests_unchanged': baseline_before == baseline_after,
        'passed': int(run_summary.group(2)) if run_summary else None,
        'failed': int(run_summary.group(3) or 0) if run_summary else None,
        'skipped': int(run_summary.group(4)) if run_summary else None,
        'session_count': len(summaries), 'passing_visual_gate_count': len(visual_gates),
        'screen_capture_calls': len(all_ns),
        'capture_pooled_median_us': statistics.median(all_ns)/1000 if all_ns else None,
        'capture_p95_method': 'sorted_values[floor(0.95 * (n - 1))]',
        'capture_pooled_p95_us': all_ns[int(.95*(len(all_ns)-1))]/1000 if all_ns else None,
        'capture_pooled_max_us': max(all_ns)/1000 if all_ns else None,
        'sampling_interval_seconds': .1, 'app_rss_sampled': app_rss,
        'sampling_limitation': '10Hz ps samples can miss brief child processes or peaks; observed RSS samples are not hard maxima.',
        'sessions': summaries,
    }
    (OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    (OUT / 'exit_code.txt').write_text(str(exit_code) + '\n')
    if exit_code or result['failed'] != 0 or not result['test_binary_unchanged_across_run'] or not result['baseline_manifests_unchanged'] or not result['full_diff_unchanged_across_run']:
        raise SystemExit('source-bound run validation failed; inspect summary.json and logs')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
