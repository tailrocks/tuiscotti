#!/usr/bin/env python3
"""Bind recorded render inputs to the stated commit's Git blobs."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

COMMIT = '534e0ff5af75b840d93038dd02ece0839cf4f71b'
DEFAULT_REPO = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/real-history-pr2-main/repo')
EVIDENCE = Path('/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/full-tcb-render-evidence')


def git(repo: Path, *args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(repo), *args])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--evidence', type=Path, default=EVIDENCE)
    args = parser.parse_args()
    repo = args.repo.resolve()
    evidence = args.evidence.resolve()
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    status = git(repo, 'status', '--porcelain', '--untracked-files=all').decode()
    if head != COMMIT:
        raise SystemExit(f'HEAD mismatch: {head}')
    if status:
        raise SystemExit(f'worktree not clean:\n{status}')
    object_format = git(repo, 'rev-parse', '--show-object-format').decode().strip()
    if object_format != 'sha1':
        raise SystemExit(f'unsupported Git object format: {object_format}')

    before = json.loads((evidence / 'input-hashes-before.json').read_text())
    after = json.loads((evidence / 'input-hashes-after.json').read_text())
    records = [json.loads(line) for line in (evidence / 'raw-render-results.jsonl').read_text().splitlines()]
    if before != after:
        raise SystemExit('before/after input manifests differ')
    records_by_path = {item['path']: item for item in records}
    if len(records_by_path) != len(records) or set(records_by_path) != set(before):
        raise SystemExit('raw render record paths do not exactly match input manifests')

    tree_entries = git(repo, 'ls-tree', '-rz', COMMIT)
    blobs = {}
    for entry in tree_entries.split(b'\0'):
        if not entry:
            continue
        header, path_bytes = entry.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        path = path_bytes.decode()
        if kind == 'blob' and path.endswith('.tui.pb'):
            blobs[path] = (oid, mode)
    if set(blobs) != set(before):
        raise SystemExit(f'Git tree PB inventory mismatch: tree={len(blobs)} manifests={len(before)}')

    out = evidence / 'source-blob-verification.tsv'
    count = 0
    with out.open('w') as f:
        f.write('path\tgit_blob_oid\tinput_sha256\tbytes\tstatus\n')
        for path in sorted(blobs):
            oid, mode = blobs[path]
            file = repo / path
            data = file.read_bytes()
            git_oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            sha = hashlib.sha256(data).hexdigest()
            record = records_by_path[path]
            if git_oid != oid or sha != before[path] or sha != record['input_sha256'] or len(data) != record['input_bytes']:
                raise SystemExit(f'input mismatch: {path}')
            f.write(f'{path}\t{oid}\t{sha}\t{len(data)}\tmatched-commit-and-run-record\n')
            count += 1
    result = {
        'commit': COMMIT, 'head': head, 'worktree_clean': not bool(status),
        'git_object_format': object_format, 'pb_blob_count': len(blobs),
        'run_record_count': len(records), 'all_blob_ids_match': True,
        'all_sha256_match_pre_and_post_run_manifests': True,
        'all_sha256_match_per_sample_render_records': True,
        'all_sizes_match_per_sample_render_records': True,
        'output_tsv': out.name,
    }
    (evidence / 'source-blob-verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
