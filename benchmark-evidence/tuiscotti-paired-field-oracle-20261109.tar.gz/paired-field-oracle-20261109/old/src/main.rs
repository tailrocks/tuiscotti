#[path = "../../common/worker.rs"]
mod worker;

fn main() {
    if let Err(error) = worker::run("d8d54155947f6303a41dfd6079b53c0abc16f29a") {
        eprintln!("projection worker failed: {error}");
        std::process::exit(2);
    }
}
