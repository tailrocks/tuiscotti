# Replay commands

The original comparator shell argv for the 1,868-, 161- and 20-row runs was
not retained. Their raw stdout/stderr, summaries, manifests, worker logs and
per-row JSONL results are preserved. The commands below are a complete replay
recipe reconstructed from those records; they are not represented as the
historical argv. A replay must retain its own exact command and exit-status
files.

## Fresh cache bootstrap

The recorded builds used a copied Rust toolchain and warmed Cargo registry
and Git caches under scratch roots, then built offline. They did not start from
empty Cargo/Rustup homes. A fresh replay is reproducible from the pinned
versions and lockfiles, but it is not an exact-environment replay: it needs
network access to install Rust `1.99.1` and MBX `1.29.2` into the isolated
Mise data directory, fetch crates and the pinned Tuiscotti Git dependencies
into a fresh Cargo home, and clone/fetch the public TCB commits. Keep these
cache roots separate from the normal user caches.

Before building, create fresh replay roots, set `MISE_CONFIG_FILE` to this
package's `mise.toml`, trust that exact config through `MISE_TRUSTED_CONFIG_PATHS`,
and run `mise install` with network available. Then fetch both locked Rust
dependency graphs with Cargo offline mode disabled:

```sh
export REPLAY_ROOT="$(pwd -P)/replay"
export MISE_DATA_DIR="$(pwd -P)/replay/mise-data"
export MISE_CACHE_DIR="$(pwd -P)/replay/mise-cache"
export MISE_STATE_DIR="$(pwd -P)/replay/mise-state"
export MISE_CONFIG_DIR="$(pwd -P)/replay/mise-config"
export MISE_CONFIG_FILE="$(pwd -P)/mise.toml"
export MISE_TRUSTED_CONFIG_PATHS="$(pwd -P)"
export MISE_AUTO_INSTALL=0
export CARGO_HOME="$REPLAY_ROOT/cargo-home"
export CARGO_TARGET_DIR="$REPLAY_ROOT/cargo-target"
export RUSTUP_HOME="$REPLAY_ROOT/rustup-home"
export MBX_CACHE_DIR="$REPLAY_ROOT/mbx-cache"
export MBX_TARGET_ROOT="$REPLAY_ROOT/mbx-target"
export MBX_GC_AUTO=0
mise install
CARGO_NET_OFFLINE=false mise exec -- cargo fetch --locked --manifest-path old/Cargo.toml
CARGO_NET_OFFLINE=false mise exec -- cargo fetch --locked --manifest-path new/Cargo.toml
export CARGO_NET_OFFLINE=true
```

Use the same `CARGO_HOME`, `CARGO_TARGET_DIR`, `RUSTUP_HOME`, MBX cache and
target roots for fetch and build. After fetch, set `CARGO_NET_OFFLINE=true`
and follow the worker build commands below. The pinned TCB history fetches
also require network access; they are not included in this archive.

## Build the pinned workers

Run on native macOS arm64 with Rust/Cargo `1.99.1`, MBX `1.29.2`, Python 3,
and Git. The original builds used scratch-only mise, MBX, Cargo and Rustup
roots with `MBX_GC_AUTO=0` and offline Cargo after dependencies were cached.
The following shows the crate build arguments; place targets under a fresh
scratch directory and set `CARGO_HOME`, `CARGO_TARGET_DIR`, `RUSTUP_HOME`,
`MBX_CACHE_DIR`, and `MBX_TARGET_ROOT` there before invoking `mise exec`:

```sh
export REPLAY_ROOT="$(pwd -P)/replay"
export CARGO_HOME="$REPLAY_ROOT/cargo-home"
export CARGO_TARGET_DIR="$REPLAY_ROOT/cargo-target"
export RUSTUP_HOME="$REPLAY_ROOT/rustup-home"
export MBX_CACHE_DIR="$REPLAY_ROOT/mbx-cache"
export MBX_TARGET_ROOT="$REPLAY_ROOT/mbx-target"
export MBX_GC_AUTO=0
mise exec -- mbx build --locked --release --manifest-path old/Cargo.toml
mise exec -- mbx build --locked --release --manifest-path new/Cargo.toml
```

The output executables are
`$CARGO_TARGET_DIR/release/tuiscotti-old-pair-projection` and
`$CARGO_TARGET_DIR/release/tuiscotti-new-pair-projection`. Their Cargo manifests pin
Tuiscotti at `d8d54155947f6303a41dfd6079b53c0abc16f29a` and
`92ef2d9ee082b35f68e066c5129fedbf07675a80`, respectively. Record the newly
built executable SHA-256 values; do not assume they match the original worker
hashes in `README.md`.

## Restore TCB source roots

The historical and migration manifests are relative to full checkouts of the
public TCB repository. Fetch and check out the commits by full object ID:

```sh
git clone https://github.com/tailrocks/terminal-components-baseline.git tcb
git -C tcb fetch origin 60b5fb2762d91a3549bd4ac63b1d77d534ee53d2 534e0ff5af75b840d93038dd02ece0839cf4f71b f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1
git -C tcb worktree add --detach ../tcb-60b5 60b5fb2762d91a3549bd4ac63b1d77d534ee53d2
git -C tcb worktree add --detach ../tcb-534 534e0ff5af75b840d93038dd02ece0839cf4f71b
git -C tcb worktree add --detach ../tcb-f539 f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a
git -C tcb worktree add --detach ../tcb-1d7f 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1
```

If the server no longer permits fetching a commit by object ID, fetch the
corresponding public pull-request ref, verify `git rev-parse HEAD` equals the
full SHA above, then add the detached worktree. The 1,868-root comparison
uses `tcb-60b5/tests/functional/baselines/pre_refactor` and
`tcb-534/tests/functional/baselines/pre_refactor`. The 161-pair comparison
uses the `tcb-f539` and `tcb-1d7f` worktree roots themselves.

## Run each comparison

Run these from the extracted package root with fresh, nonexistent output
paths. Set `WORKERS` to `$CARGO_TARGET_DIR/release` first. The two Git-backed runs verify manifest rows against the exact
commit trees and working bytes. The 20 archived pairs are verified against
the included frozen archive content-manifest SHA-256.

```sh
: "${CARGO_TARGET_DIR:?keep the same target path used for both builds}"
export WORKERS="$CARGO_TARGET_DIR/release"
python3 scripts/verify_archive_subset.py

python3 scripts/compare.py \
  --manifest results/paired-1868-manifest.tsv \
  --old-root tcb-60b5/tests/functional/baselines/pre_refactor \
  --new-root tcb-534/tests/functional/baselines/pre_refactor \
  --old-worker "$WORKERS/tuiscotti-old-pair-projection" \
  --new-worker "$WORKERS/tuiscotti-new-pair-projection" \
  --out-dir replay/1868 \
  --old-commit 60b5fb2762d91a3549bd4ac63b1d77d534ee53d2 \
  --new-commit 534e0ff5af75b840d93038dd02ece0839cf4f71b \
  --expected-rows 1868 --timeout-seconds 30 --max-difference-paths 1000

python3 scripts/compare.py \
  --manifest results/paired-161-manifest.tsv \
  --old-root tcb-f539 \
  --new-root tcb-1d7f \
  --old-worker "$WORKERS/tuiscotti-old-pair-projection" \
  --new-worker "$WORKERS/tuiscotti-new-pair-projection" \
  --out-dir replay/161 \
  --old-commit f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a \
  --new-commit 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1 \
  --expected-rows 161 --timeout-seconds 30 --max-difference-paths 1000

python3 scripts/compare.py \
  --manifest results/pixel-archive-inputs/paired-pixel-manifest.tsv \
  --old-root results/pixel-inputs/old \
  --new-root results/pixel-inputs/new \
  --old-worker "$WORKERS/tuiscotti-old-pair-projection" \
  --new-worker "$WORKERS/tuiscotti-new-pair-projection" \
  --out-dir replay/20-pixel \
  --archive-manifest archive-provenance/BUNDLE-CONTENTS.sha256 \
  --archive-manifest-sha256 95056582c499be14c16637692233c033e1f6c40affbd50f77ae4da7f0151f0ef \
  --archive-source-label 'archive=726afbf093bcc612e055e085cd3a787f53be6a1d6e051e8cfb476235324392b6; candidate_source=279db9c434436aaa2a4b36976a389a92ca7be3ec0dbf06ff9d95388ff8a8e3dd' \
  --expected-rows 20 --timeout-seconds 30 --max-difference-paths 1000

python3 scripts/replay_worker_controls.py \
  --old-worker "$WORKERS/tuiscotti-old-pair-projection"
```

Each comparison exits `1` when the complete projections or state digests
differ, even if every input decoded successfully. These archived comparisons
contain expected inequality, so an exit of `1` is expected; inspect
`summary.json` and each JSONL row. A successful replay also requires both
worker exit statuses to be zero, no protocol errors, no missing/unpaired rows,
and no input hash/tree mismatch. Save the command, cwd, allowlisted
environment, process exit status, stdout/stderr, and hashes of all outputs.
The comparator's archive mode checks the manifest file's SHA-256 and each
sample file's own SHA/Git-blob digest. The separate `verify_archive_subset.py`
also checks the binding table between the frozen archive content manifest and
the included 40 input files plus the independent projection. The worker-control
replay uses the included old JSON sample and archived independent projection;
it writes six disposable mutated JSON inputs under `replay/worker-controls/`.
It does not mutate a PB sample.
