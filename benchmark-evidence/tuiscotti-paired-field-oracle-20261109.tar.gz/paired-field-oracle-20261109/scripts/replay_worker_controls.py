#!/usr/bin/env python3
"""Replay the old-reader golden and six field-mutation controls from the bundle."""

import argparse
from pathlib import Path

import independent_worker_control_as_run as control


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--old-worker", type=Path, required=True)
args = parser.parse_args()
control.WORKER = args.old_worker.resolve()
control.SAMPLE = ROOT / "results/pixel-inputs/old/sample-01.tui.json"
control.GOLDEN = ROOT / "archive-provenance/holla-compact-80x24.pixels.projection.json"
control.OUT = ROOT / "replay/worker-controls"
control.main()
