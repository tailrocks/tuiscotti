#!/usr/bin/env python3
"""Exercise both pinned readers on one independently inventory-bound real pair."""

import csv
import json
from pathlib import Path
import subprocess
import sys

from scripts.compare import (
    PROTOCOL,
    expected_blob_error,
    expected_hash_error,
    outcome,
    read_frame,
    send_request,
    validate_worker_response,
    validate_projection,
)


OLD_REV = "d8d54155947f6303a41dfd6079b53c0abc16f29a"
NEW_REV = "92ef2d9ee082b35f68e066c5129fedbf07675a80"
CONTROL_ID = "sc-shell-inspector-narrow"


def main() -> None:
    if len(sys.argv) != 6:
        raise SystemExit("usage: worker_control.py MANIFEST OLD_ROOT NEW_ROOT OLD_WORKER NEW_WORKER")
    manifest, old_root, new_root, old_bin, new_bin = map(Path, sys.argv[1:])
    row = next(
        item for item in csv.DictReader(manifest.open(encoding="utf-8"), delimiter="\t")
        if item["test_id"] == CONTROL_ID
    )
    output_dir = Path("results/worker-control")
    output_dir.mkdir(parents=True, exist_ok=False)
    raw_path = output_dir / "worker-records.jsonl"
    records = []
    for label, binary, root, rel, revision in (
        ("old", old_bin, old_root, row["json_path"], OLD_REV),
        ("new", new_bin, new_root, row["pb_path"], NEW_REV),
    ):
        process = subprocess.Popen(
            [str(binary.resolve())], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, bufsize=0,
        )
        try:
            send_request(process, 0, CONTROL_ID, (root / rel).resolve())
            record = read_frame(process.stdout, 30.0)
        finally:
            process.stdin.close()
        status = process.wait(timeout=30.0)
        stderr = process.stderr.read()
        validate_worker_response(record, 0, CONTROL_ID, revision)
        if status != 0:
            raise RuntimeError(f"{label} worker exit {status}: {stderr.decode(errors='replace')}")
        if record.get("ok") is not True:
            raise RuntimeError(f"{label} worker rejected control sample: {record.get('error')}")
        sha_column = "json_sha256" if label == "old" else "pb_sha256"
        hash_error = expected_hash_error(record, row[sha_column], label)
        if hash_error:
            raise RuntimeError(hash_error)
        blob_column = "json_git_blob" if label == "old" else "pb_git_blob"
        blob_error = expected_blob_error(record, row[blob_column], label)
        if blob_error:
            raise RuntimeError(blob_error)
        sample = validate_projection(record, row["test_id"], label)
        snapshot = sample["snapshot"]
        if sample["gate"] != "state" or snapshot["cols"] != 72 or snapshot["rows"] != 24:
            raise RuntimeError(f"{label} control fields disagree with independent manifest strata")
        if len(snapshot["cells"]) != 72 * 24 or len(snapshot["palette"]) != 256:
            raise RuntimeError(f"{label} control dimensions/cell/palette projection is incomplete")
        if sample["render_contract"] is not None or sample["image"] is not None:
            raise RuntimeError(f"{label} state-only control unexpectedly has pixel data")
        records.append(record)

    with raw_path.open("x", encoding="utf-8") as target:
        for record in records:
            target.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
    comparison = outcome(0, row, "test_id", "json_path", "pb_path", records[0], records[1], 200)
    summary = {
        "protocol": PROTOCOL,
        "old_source_rev": OLD_REV,
        "new_source_rev": NEW_REV,
        "manifest_test_id": CONTROL_ID,
        "dimensions": [72, 24],
        "old_reader_ok": records[0]["ok"],
        "new_reader_ok": records[1]["ok"],
        "comparison": comparison,
        "raw_records": str(raw_path),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
