#!/usr/bin/env python3
"""Build a manifest for the distinct 161-sample f539-to-1d transition."""

import csv
import hashlib
import json
from pathlib import Path
import sys


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: make_transition_manifest.py OLD_REPO NEW_REPO OUTPUT")
    old_root, new_root, output_path = map(Path, sys.argv[1:])
    old_root = old_root.resolve()
    new_root = new_root.resolve()
    old_files = {path.relative_to(old_root).with_suffix("").as_posix(): path for path in old_root.rglob("*.tui.json")}
    new_files = {path.relative_to(new_root).with_suffix("").as_posix(): path for path in new_root.rglob("*.tui.pb")}
    if len(old_files) != 161 or len(new_files) != 161 or old_files.keys() != new_files.keys():
        raise SystemExit(
            f"expected 161 exact stem pairs, got old={len(old_files)} new={len(new_files)} "
            f"unpaired-old={len(old_files.keys() - new_files.keys())} "
            f"unpaired-new={len(new_files.keys() - old_files.keys())}"
        )
    fields = [
        "json_path", "json_sha256", "json_git_blob", "pb_path", "pb_sha256",
        "pb_git_blob", "test_id", "gate",
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("x", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for stem in sorted(old_files):
            old_path = old_files[stem]
            new_path = new_files[stem]
            old_bytes = old_path.read_bytes()
            new_bytes = new_path.read_bytes()
            old_sample = json.loads(old_bytes)
            if Path(old_sample["test_id"]).name != old_path.name.removesuffix(".tui.json"):
                raise SystemExit(f"test ID does not match old sample path: {old_path}")
            writer.writerow({
                "json_path": old_path.relative_to(old_root).as_posix(),
                "json_sha256": hashlib.sha256(old_bytes).hexdigest(),
                "json_git_blob": git_blob_sha1(old_bytes),
                "pb_path": new_path.relative_to(new_root).as_posix(),
                "pb_sha256": hashlib.sha256(new_bytes).hexdigest(),
                "pb_git_blob": git_blob_sha1(new_bytes),
                "test_id": old_sample["test_id"],
                "gate": old_sample["gate"],
            })


if __name__ == "__main__":
    main()
