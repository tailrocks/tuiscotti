#!/usr/bin/env python3
"""Stream paired sample projections from separately pinned Tuiscotti workers."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import select
import subprocess
import sys
import time
from typing import Any, BinaryIO, Optional


PROTOCOL = "tuiscotti.paired-fields.v1"
MAX_FRAME_BYTES = 512 * 1024 * 1024


class CompareError(RuntimeError):
    pass


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--old-root", type=Path, required=True)
    parser.add_argument("--new-root", type=Path, required=True)
    parser.add_argument("--old-worker", type=Path, required=True)
    parser.add_argument("--new-worker", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--old-path-column", default="json_path")
    parser.add_argument("--new-path-column", default="pb_path")
    parser.add_argument("--test-id-column", default="test_id")
    parser.add_argument("--old-sha-column", default="json_sha256")
    parser.add_argument("--new-sha-column", default="pb_sha256")
    parser.add_argument("--old-git-blob-column", default="json_git_blob")
    parser.add_argument("--new-git-blob-column", default="pb_git_blob")
    parser.add_argument("--old-commit")
    parser.add_argument("--new-commit")
    parser.add_argument("--archive-manifest", type=Path)
    parser.add_argument("--archive-manifest-sha256")
    parser.add_argument("--archive-source-label")
    parser.add_argument("--expected-rows", type=int, required=True)
    parser.add_argument("--timeout-seconds", type=float, default=30.0)
    parser.add_argument("--max-difference-paths", type=int, default=1000)
    return parser.parse_args()


def read_manifest(
    path: Path,
    old_column: str,
    new_column: str,
    old_sha_column: str,
    new_sha_column: str,
    old_git_blob_column: str,
    new_git_blob_column: str,
    test_id_column: str,
) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if not reader.fieldnames or old_column not in reader.fieldnames or new_column not in reader.fieldnames:
            raise CompareError(
                f"manifest must contain {old_column!r} and {new_column!r} columns"
            )
        rows = list(reader)

    seen_old: set[str] = set()
    seen_new: set[str] = set()
    for index, row in enumerate(rows):
        old_path = row.get(old_column, "").strip()
        new_path = row.get(new_column, "").strip()
        if not old_path and not new_path:
            raise CompareError(f"manifest row {index + 2} has neither source path")
        if not old_path or not new_path:
            raise CompareError(f"manifest row {index + 2} is not a complete pair")
        if Path(old_path).with_suffix("").as_posix() != Path(new_path).with_suffix("").as_posix():
            raise CompareError(f"manifest row {index + 2} has mismatched sample stems")
        if not row.get(test_id_column, "").strip():
            raise CompareError(f"manifest row {index + 2} has no test ID")
        if old_path and old_path in seen_old:
            raise CompareError(f"duplicate old source path in manifest: {old_path}")
        if new_path and new_path in seen_new:
            raise CompareError(f"duplicate new source path in manifest: {new_path}")
        if old_path:
            seen_old.add(old_path)
        if new_path:
            seen_new.add(new_path)
        for path_column, sha_column, blob_column in (
            (old_column, old_sha_column, old_git_blob_column),
            (new_column, new_sha_column, new_git_blob_column),
        ):
            if row.get(path_column, "").strip() and not re.fullmatch(
                r"[0-9a-f]{64}", row.get(sha_column, "").strip()
            ):
                raise CompareError(f"manifest row {index + 2} has no valid {sha_column}")
            if row.get(path_column, "").strip() and not re.fullmatch(
                r"[0-9a-f]{40}", row.get(blob_column, "").strip()
            ):
                raise CompareError(f"manifest row {index + 2} has no valid {blob_column}")
    return rows


def read_frame(pipe: BinaryIO, timeout: float) -> dict[str, Any]:
    header = read_exact(pipe, 8, timeout)
    if header is None:
        raise CompareError("projection worker ended before returning its next frame")
    if len(header) != 8:
        raise CompareError("projection worker returned a truncated frame header")
    length = int.from_bytes(header, "big")
    if length > MAX_FRAME_BYTES:
        raise CompareError(f"projection frame length {length} exceeds cap {MAX_FRAME_BYTES}")
    payload = read_exact(pipe, length, timeout)
    if payload is None or len(payload) != length:
        raise CompareError("projection worker returned a truncated frame")
    try:
        value = json.loads(payload)
    except json.JSONDecodeError as error:
        raise CompareError(f"projection frame is not valid JSON: {error}") from error
    if not isinstance(value, dict):
        raise CompareError("projection frame root must be an object")
    return value


def read_exact(pipe: BinaryIO, size: int, timeout: float) -> Optional[bytes]:
    deadline = time.monotonic() + timeout
    chunks = bytearray()
    while len(chunks) < size:
        try:
            ready, _, _ = select.select([pipe], [], [], max(0.0, deadline - time.monotonic()))
        except (OSError, ValueError):
            # In-memory streams used by the parser tests cannot block.
            ready = [pipe]
        if not ready:
            raise CompareError(f"projection worker timed out after {timeout} seconds")
        chunk = pipe.read(size - len(chunks))
        if not chunk:
            return None if not chunks else bytes(chunks)
        chunks.extend(chunk)
    return bytes(chunks)


def send_request(
    process: subprocess.Popen[bytes],
    index: int,
    pair_key: str,
    sample_path: Path,
) -> None:
    if process.stdin is None:
        raise CompareError("projection worker stdin is unavailable")
    request = {
        "pair_index": str(index),
        "relative_path": pair_key,
        "sample_path": str(sample_path),
    }
    process.stdin.write(json.dumps(request, separators=(",", ":")).encode() + b"\n")
    process.stdin.flush()


def validate_worker_response(
    response: dict[str, Any], index: int, pair_key: str, expected_rev: str
) -> None:
    if response.get("protocol") != PROTOCOL:
        raise CompareError(f"worker returned unexpected protocol: {response.get('protocol')!r}")
    if response.get("tuiscotti_source_rev") != expected_rev:
        raise CompareError(
            f"worker source binding mismatch: expected {expected_rev}, "
            f"got {response.get('tuiscotti_source_rev')!r}"
        )
    if response.get("pair_index") != str(index):
        raise CompareError(
            f"worker frame sequence mismatch: expected index {index}, "
            f"got {response.get('pair_index')!r}"
        )
    if response.get("relative_path") != pair_key:
        raise CompareError(
            f"worker pair-key mismatch: expected {pair_key!r}, "
            f"got {response.get('relative_path')!r}"
        )


def mismatch_paths(old: Any, new: Any, prefix: str = "") -> list[str]:
    return compare_paths(old, new, prefix, 10**9)[1]


def compare_paths(old: Any, new: Any, prefix: str, limit: int) -> tuple[int, list[str]]:
    if type(old) is not type(new):
        return 1, [prefix or "/"] if limit > 0 else []
    if isinstance(old, dict):
        count = 0
        diffs: list[str] = []
        for key in sorted(old.keys() | new.keys()):
            child = f"{prefix}/{escape_pointer(str(key))}"
            if key not in old or key not in new:
                count += 1
                if len(diffs) < limit:
                    diffs.append(child)
            else:
                child_count, child_diffs = compare_paths(old[key], new[key], child, limit - len(diffs))
                count += child_count
                diffs.extend(child_diffs)
        return count, diffs
    if isinstance(old, list):
        if len(old) != len(new):
            return 1, [prefix or "/"] if limit > 0 else []
        count = 0
        diffs = []
        for index, (left, right) in enumerate(zip(old, new)):
            child_count, child_diffs = compare_paths(left, right, f"{prefix}/{index}", limit - len(diffs))
            count += child_count
            diffs.extend(child_diffs)
        return count, diffs
    return (0, []) if old == new else (1, [prefix or "/"] if limit > 0 else [])


def escape_pointer(value: str) -> str:
    return value.replace("~", "~0").replace("/", "~1")


def expected_hash_error(response: dict[str, Any], expected: str, label: str) -> Optional[str]:
    if expected and response.get("original_file_sha256") != expected:
        return (
            f"{label} input hash mismatch: expected {expected}, "
            f"got {response.get('original_file_sha256')!r}"
        )
    return None


def expected_blob_error(response: dict[str, Any], expected: str, label: str) -> Optional[str]:
    if response.get("original_file_git_blob_sha1") != expected:
        return (
            f"{label} Git blob mismatch: expected {expected}, "
            f"got {response.get('original_file_git_blob_sha1')!r}"
        )
    return None


def git_inventory(root: Path, commit: str, suffix: str) -> tuple[Path, str, dict[str, str]]:
    if not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise CompareError(f"source commit must be a full lowercase Git SHA-1: {commit!r}")
    top_result = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "--show-toplevel"],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    repo = Path(top_result.stdout.strip()).resolve()
    resolved = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "--verify", f"{commit}^{{commit}}"],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    ).stdout.strip()
    if resolved != commit:
        raise CompareError(f"resolved source commit {resolved} differs from requested {commit}")
    tree = subprocess.run(
        ["git", "-C", str(repo), "ls-tree", "-r", "-z", "--full-tree", commit],
        check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    ).stdout
    files: dict[str, str] = {}
    for entry in tree.split(b"\0"):
        if not entry:
            continue
        metadata, raw_path = entry.split(b"\t", 1)
        mode, object_type, oid = metadata.decode("ascii").split(" ")
        path = raw_path.decode("utf-8")
        if object_type == "blob" and path.endswith(suffix):
            files[path] = oid
    prefix = root.resolve().relative_to(repo).as_posix()
    return repo, "" if prefix == "." else prefix, files


def verify_git_pairs(
    rows: list[dict[str, str]],
    old_root: Path,
    new_root: Path,
    old_commit: str,
    new_commit: str,
    old_path_column: str,
    new_path_column: str,
    old_blob_column: str,
    new_blob_column: str,
) -> None:
    old_repo, old_prefix, old_tree = git_inventory(old_root, old_commit, ".tui.json")
    new_repo, new_prefix, new_tree = git_inventory(new_root, new_commit, ".tui.pb")
    if old_repo == new_repo and old_commit == new_commit:
        raise CompareError("old and new samples must bind to distinct source commits")
    old_expected: set[str] = set()
    new_expected: set[str] = set()
    old_worktree: list[str] = []
    new_worktree: list[str] = []
    for row in rows:
        old_path = f"{old_prefix}/{row[old_path_column]}".strip("/")
        new_path = f"{new_prefix}/{row[new_path_column]}".strip("/")
        old_expected.add(old_path)
        new_expected.add(new_path)
        if old_tree.get(old_path) != row[old_blob_column]:
            raise CompareError(f"old sample Git blob does not match {old_commit}:{old_path}")
        if new_tree.get(new_path) != row[new_blob_column]:
            raise CompareError(f"new sample Git blob does not match {new_commit}:{new_path}")
        old_worktree.append(old_path)
        new_worktree.append(new_path)
    old_actual = {
        path for path in old_tree
        if (not old_prefix or path.startswith(old_prefix + "/")) and path.endswith(".tui.json")
    }
    new_actual = {
        path for path in new_tree
        if (not new_prefix or path.startswith(new_prefix + "/")) and path.endswith(".tui.pb")
    }
    if old_actual != old_expected or new_actual != new_expected:
        raise CompareError(
            f"Git trees are not exhausted by manifest (old {len(old_expected)}/{len(old_actual)}, "
            f"new {len(new_expected)}/{len(new_actual)})"
        )
    for label, repo, paths, expected in (
        ("old", old_repo, old_worktree, [row[old_blob_column] for row in rows]),
        ("new", new_repo, new_worktree, [row[new_blob_column] for row in rows]),
    ):
        hashes: list[str] = []
        for offset in range(0, len(paths), 200):
            hashes.extend(subprocess.run(
                ["git", "-C", str(repo), "hash-object", "--", *paths[offset:offset + 200]],
                check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            ).stdout.splitlines())
        if hashes != expected:
            raise CompareError(f"{label} worktree sample bytes do not match its pinned Git tree")


def validate_image(sample: dict[str, Any], label: str) -> None:
    image = sample.get("image")
    if image is None:
        return
    if not isinstance(image, dict):
        raise CompareError(f"{label} image projection is not an object")
    required = ("png_sha256_matches", "rgba_sha256_matches", "dimensions_match")
    if any(image.get(field) is not True for field in required):
        raise CompareError(f"{label} image validation flags are not all true")


def require_keys(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise CompareError(f"{label} fields differ from the projection contract")
    return value


def validate_projection(record: dict[str, Any], expected_test_id: str, label: str) -> dict[str, Any]:
    sample = record.get("sample")
    sample = require_keys(
        sample,
        {"schema", "test_id", "gate", "snapshot", "render_contract", "image", "observation"},
        f"{label} sample",
    )
    if sample.get("schema") != "tuiscotti.sample.v1":
        raise CompareError(f"{label} sample schema is missing or unexpected")
    if sample.get("test_id") != expected_test_id:
        raise CompareError(f"{label} test ID differs from manifest")
    digest = record.get("state_digest")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise CompareError(f"{label} state digest is missing or malformed")
    snapshot = require_keys(
        sample["snapshot"],
        {
            "schema", "cols", "rows", "scope", "viewport_origin", "cells", "palette",
            "default_foreground", "default_background", "default_cursor", "cursor", "title", "metadata",
        },
        f"{label} snapshot",
    )
    if not isinstance(snapshot["cells"], list) or not isinstance(snapshot["palette"], list):
        raise CompareError(f"{label} cells/palette are not arrays")
    if len(snapshot["palette"]) != 256:
        raise CompareError(f"{label} palette does not contain 256 entries")
    require_keys(
        snapshot["cursor"],
        {"col", "row", "in_capture", "visible", "shape", "color", "blink"},
        f"{label} cursor",
    )
    require_keys(
        snapshot["metadata"],
        {"captured_at_ms", "revision", "backend", "session", "source"},
        f"{label} metadata",
    )
    cell_keys = {
        "text", "width", "fg", "bg", "bold", "dim", "italic", "inverse", "invisible",
        "strike", "blink", "underline", "underline_color", "link_uri", "link_id",
    }
    for index, cell in enumerate(snapshot["cells"]):
        require_keys(cell, cell_keys, f"{label} cell {index}")
    for color in snapshot["palette"] + [
        snapshot["default_foreground"], snapshot["default_background"], snapshot["default_cursor"],
        snapshot["cursor"]["color"],
    ]:
        if not isinstance(color, list) or len(color) != 3 or any(type(channel) is not int for channel in color):
            raise CompareError(f"{label} RGB projection is malformed")
    for field in ("fg", "bg", "underline_color"):
        for cell in snapshot["cells"]:
            raw_color = cell[field]
            if not isinstance(raw_color, dict):
                raise CompareError(f"{label} cell color is malformed")
            kind = raw_color.get("kind")
            value = require_keys(
                raw_color,
                {"kind"} if kind == "default" else {"kind", "value"},
                f"{label} cell color",
            )
            if kind not in ("default", "indexed", "rgb"):
                raise CompareError(f"{label} cell color kind is unknown")
            if kind == "indexed" and (type(value["value"]) is not int or not 0 <= value["value"] <= 255):
                raise CompareError(f"{label} indexed color is malformed")
            if kind == "rgb" and (
                not isinstance(value["value"], list)
                or len(value["value"]) != 3
                or any(type(channel) is not int for channel in value["value"])
            ):
                raise CompareError(f"{label} RGB cell color is malformed")
    require_keys(sample["observation"], {"note"}, f"{label} observation")
    if sample["render_contract"] is not None:
        contract = require_keys(
            sample["render_contract"],
            {
                "profile", "contract_version", "renderer_version", "raster_policy", "fonts",
                "cell_width_bits", "cell_height_bits", "font_size_bits", "baseline_bits", "scale_bits",
                "title_bar", "palette_digest", "cursor_phase", "blink", "platform_key",
            },
            f"{label} render contract",
        )
        for font in contract["fonts"]:
            require_keys(font, {"digest", "face_index", "bold", "italic", "fallback_position"}, f"{label} font")
    if sample["image"] is not None:
        require_keys(
            sample["image"],
            {
                "format", "width", "height", "png_sha256", "rgba_sha256", "png_base64", "rgba_base64",
                "png_sha256_computed", "rgba_sha256_computed", "decoded_width", "decoded_height",
                "png_sha256_matches", "rgba_sha256_matches", "dimensions_match",
            },
            f"{label} image",
        )
    validate_image(sample, label)
    return sample


def outcome(
    index: int,
    row: dict[str, str],
    test_id_column: str,
    old_path_column: str,
    new_path_column: str,
    old_record: Optional[dict[str, Any]],
    new_record: Optional[dict[str, Any]],
    max_difference_paths: int,
) -> dict[str, Any]:
    expected_test_id = row.get(test_id_column, "")
    result: dict[str, Any] = {
        "pair_index": index,
        "expected_test_id": expected_test_id,
        "old_path": row.get(old_path_column) or None,
        "new_path": row.get(new_path_column) or None,
    }

    if old_record is None:
        result.update({"status": "new-only", "full_fields_equal": False})
        return result
    if new_record is None:
        result.update({"status": "old-only", "full_fields_equal": False})
        return result

    result["old_file_sha256"] = old_record.get("original_file_sha256")
    result["new_file_sha256"] = new_record.get("original_file_sha256")
    result["old_ok"] = old_record.get("ok") is True
    result["new_ok"] = new_record.get("ok") is True
    if not result["old_ok"] or not result["new_ok"]:
        result.update({
            "status": "decode-error",
            "old_error": old_record.get("error"),
            "new_error": new_record.get("error"),
            "full_fields_equal": False,
        })
        return result

    old_sample = validate_projection(old_record, expected_test_id, "old")
    new_sample = validate_projection(new_record, expected_test_id, "new")
    diff_count, diffs = compare_paths(old_sample, new_sample, "", max_difference_paths)
    result.update({
        "status": "paired",
        "full_fields_equal": diff_count == 0,
        "difference_count": diff_count,
        "difference_paths_truncated": diff_count > len(diffs),
        "state_digest_equal": old_record.get("state_digest") == new_record.get("state_digest"),
        "old_state_digest": old_record.get("state_digest"),
        "new_state_digest": new_record.get("state_digest"),
        "old_test_id": old_sample.get("test_id"),
        "new_test_id": new_sample.get("test_id"),
        "difference_paths": diffs,
    })
    return result


def main() -> int:
    args = arguments()
    if args.expected_rows <= 0 or args.timeout_seconds <= 0 or args.max_difference_paths < 0:
        raise CompareError("expected rows and timeout must be positive; diff limit cannot be negative")
    scratch_root = Path(__file__).resolve().parent.parent
    out_dir = args.out_dir.resolve()
    try:
        out_dir.relative_to(scratch_root)
    except ValueError as error:
        raise CompareError(f"output directory must remain under {scratch_root}") from error

    rows = read_manifest(
        args.manifest,
        args.old_path_column,
        args.new_path_column,
        args.old_sha_column,
        args.new_sha_column,
        args.old_git_blob_column,
        args.new_git_blob_column,
        args.test_id_column,
    )
    if len(rows) != args.expected_rows:
        raise CompareError(f"manifest has {len(rows)} rows; expected {args.expected_rows}")
    args.old_root = args.old_root.resolve()
    args.new_root = args.new_root.resolve()
    args.old_worker = args.old_worker.resolve()
    args.new_worker = args.new_worker.resolve()
    if args.archive_manifest is not None:
        if args.old_commit or args.new_commit or not args.archive_source_label:
            raise CompareError("archive mode requires a source label and excludes Git commit arguments")
        archive_manifest_sha = hashlib.sha256(args.archive_manifest.read_bytes()).hexdigest()
        if archive_manifest_sha != args.archive_manifest_sha256:
            raise CompareError(
                f"archive manifest SHA-256 mismatch: expected {args.archive_manifest_sha256}, "
                f"got {archive_manifest_sha}"
            )
        source_binding = {
            "kind": "archive-bundle-manifest",
            "archive_manifest": str(args.archive_manifest.resolve()),
            "archive_manifest_sha256": archive_manifest_sha,
            "source_label": args.archive_source_label,
        }
    else:
        if not args.old_commit or not args.new_commit or args.archive_manifest_sha256:
            raise CompareError("Git mode requires both source commits and excludes archive arguments")
        verify_git_pairs(
            rows,
            args.old_root,
            args.new_root,
            args.old_commit,
            args.new_commit,
            args.old_path_column,
            args.new_path_column,
            args.old_git_blob_column,
            args.new_git_blob_column,
        )
        source_binding = {
            "kind": "git-trees",
            "old_commit": args.old_commit,
            "new_commit": args.new_commit,
        }
    manifest_old = {row[args.old_path_column].strip() for row in rows}
    manifest_new = {row[args.new_path_column].strip() for row in rows}
    actual_old = {path.relative_to(args.old_root).as_posix() for path in args.old_root.rglob("*.tui.json")}
    actual_new = {path.relative_to(args.new_root).as_posix() for path in args.new_root.rglob("*.tui.pb")}
    if actual_old != manifest_old or actual_new != manifest_new:
        raise CompareError(
            f"manifest does not exhaust roots (old missing/extra={len(actual_old - manifest_old)}/{len(manifest_old - actual_old)}, "
            f"new missing/extra={len(actual_new - manifest_new)}/{len(manifest_new - actual_new)})"
        )
    out_dir.mkdir(parents=True, exist_ok=False)

    old_stderr_path = out_dir / "old-worker.stderr.log"
    new_stderr_path = out_dir / "new-worker.stderr.log"
    result_path = out_dir / "paired-results.jsonl"
    summary_path = out_dir / "summary.json"
    counts = {
        "paired": 0,
        "old-only": 0,
        "new-only": 0,
        "decode-error": 0,
        "input-hash-mismatch": 0,
    }
    equal_count = 0
    digest_equal_count = 0
    protocol_errors: list[str] = []
    old_rev = "d8d54155947f6303a41dfd6079b53c0abc16f29a"
    new_rev = "92ef2d9ee082b35f68e066c5129fedbf07675a80"

    with old_stderr_path.open("xb") as old_stderr, new_stderr_path.open("xb") as new_stderr:
        old_worker = subprocess.Popen(
            [str(args.old_worker)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=old_stderr, bufsize=0, cwd=scratch_root,
        )
        new_worker = subprocess.Popen(
            [str(args.new_worker)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=new_stderr, bufsize=0, cwd=scratch_root,
        )
        try:
            with result_path.open("x", encoding="utf-8") as results:
                for index, row in enumerate(rows):
                    old_rel = row.get(args.old_path_column, "").strip()
                    new_rel = row.get(args.new_path_column, "").strip()
                    pair_key = row.get(args.test_id_column, "").strip() or old_rel or new_rel
                    old_record = None
                    new_record = None
                    hash_errors: list[str] = []

                    if old_rel:
                        old_path = (args.old_root / old_rel).resolve()
                        try:
                            old_path.relative_to(args.old_root)
                        except ValueError as error:
                            raise CompareError(f"old input escaped its root: {old_rel}") from error
                        send_request(old_worker, index, pair_key, old_path)
                        old_record = read_frame(old_worker.stdout, args.timeout_seconds)
                        validate_worker_response(old_record, index, pair_key, old_rev)
                        error = expected_hash_error(
                            old_record, row.get(args.old_sha_column, ""), "old"
                        )
                        if error:
                            hash_errors.append(error)
                        error = expected_blob_error(
                            old_record, row.get(args.old_git_blob_column, ""), "old"
                        )
                        if error:
                            hash_errors.append(error)
                    if new_rel:
                        new_path = (args.new_root / new_rel).resolve()
                        try:
                            new_path.relative_to(args.new_root)
                        except ValueError as error:
                            raise CompareError(f"new input escaped its root: {new_rel}") from error
                        send_request(new_worker, index, pair_key, new_path)
                        new_record = read_frame(new_worker.stdout, args.timeout_seconds)
                        validate_worker_response(new_record, index, pair_key, new_rev)
                        error = expected_hash_error(
                            new_record, row.get(args.new_sha_column, ""), "new"
                        )
                        if error:
                            hash_errors.append(error)
                        error = expected_blob_error(
                            new_record, row.get(args.new_git_blob_column, ""), "new"
                        )
                        if error:
                            hash_errors.append(error)

                    record = outcome(
                        index, row, args.test_id_column, args.old_path_column,
                        args.new_path_column, old_record, new_record,
                        args.max_difference_paths,
                    )
                    if hash_errors:
                        record["status"] = "input-hash-mismatch"
                        record["full_fields_equal"] = False
                        record["expected_hash_errors"] = hash_errors
                    counts[record["status"]] += 1
                    equal_count += int(record.get("full_fields_equal") is True)
                    digest_equal_count += int(record.get("state_digest_equal") is True)
                    results.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
                    results.flush()
        except Exception as error:
            protocol_errors.append(str(error))
            old_worker.kill()
            new_worker.kill()
            raise
        finally:
            for worker in (old_worker, new_worker):
                if worker.stdin is not None:
                    worker.stdin.close()
            statuses = []
            for label, worker in (("old", old_worker), ("new", new_worker)):
                try:
                    statuses.append(worker.wait(timeout=args.timeout_seconds))
                except subprocess.TimeoutExpired:
                    worker.kill()
                    statuses.append(worker.wait())
                    protocol_errors.append(f"{label} projection worker did not exit before deadline")
                if worker.stdout is not None and worker.stdout.read(1):
                    protocol_errors.append(f"{label} projection worker emitted data beyond requested frames")
            old_status, new_status = statuses

    summary = {
        "schema": "tuiscotti.paired-field-comparison.v1",
        "old_tuiscotti_rev": old_rev,
        "new_tuiscotti_rev": new_rev,
        "old_source_commit": args.old_commit,
        "new_source_commit": args.new_commit,
        "source_binding": source_binding,
        "manifest": str(args.manifest.resolve()),
        "pair_rows": len(rows),
        "counts": counts,
        "full_fields_equal": equal_count,
        "state_digest_equal": digest_equal_count,
        "old_worker_exit": old_status,
        "new_worker_exit": new_status,
        "protocol_errors": protocol_errors,
    }
    with summary_path.open("x", encoding="utf-8") as summary_file:
        json.dump(summary, summary_file, indent=2, sort_keys=True)
        summary_file.write("\n")

    print(json.dumps(summary, sort_keys=True))
    all_equal = (
        counts["paired"] == len(rows)
        and counts["input-hash-mismatch"] == 0
        and counts["decode-error"] == 0
        and counts["old-only"] == 0
        and counts["new-only"] == 0
        and equal_count == len(rows)
        and digest_equal_count == len(rows)
    )
    return 0 if not protocol_errors and old_status == 0 and new_status == 0 and all_equal else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except CompareError as error:
        print(f"paired comparison error: {error}", file=sys.stderr)
        raise SystemExit(2)
