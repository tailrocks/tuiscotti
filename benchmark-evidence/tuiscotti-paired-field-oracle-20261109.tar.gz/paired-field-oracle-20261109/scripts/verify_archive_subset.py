#!/usr/bin/env python3
"""Verify included archived pair bytes against the frozen content manifest."""

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_MANIFEST = ROOT / "archive-provenance/BUNDLE-CONTENTS.sha256"
SUBSET = ROOT / "archive-provenance/subset-binding.tsv"
EXPECTED_MANIFEST_SHA256 = "95056582c499be14c16637692233c033e1f6c40affbd50f77ae4da7f0151f0ef"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    actual_manifest_sha = sha256(ARCHIVE_MANIFEST)
    if actual_manifest_sha != EXPECTED_MANIFEST_SHA256:
        raise SystemExit(f"unexpected frozen manifest SHA-256: {actual_manifest_sha}")
    archive_entries = {}
    for line in ARCHIVE_MANIFEST.read_text().splitlines():
        digest, path = line.split("  ", 1)
        archive_entries[path] = digest

    seen_archive_paths = set()
    with SUBSET.open(newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    if len(rows) != 41:
        raise SystemExit(f"expected 41 bound files, found {len(rows)}")
    for row in rows:
        archived_path = row["archive_path"]
        if archived_path in seen_archive_paths:
            raise SystemExit(f"duplicate archive path: {archived_path}")
        seen_archive_paths.add(archived_path)
        expected = archive_entries.get(archived_path)
        if expected is None or expected != row["archive_sha256"]:
            raise SystemExit(f"content manifest binding mismatch: {archived_path}")
        package_path = ROOT / row["package_path"]
        actual = sha256(package_path)
        if actual != row["package_sha256"] or actual != expected:
            raise SystemExit(f"package byte mismatch: {row['package_path']}")
    print(f"verified {len(rows)} archived input/projection membership hashes")


if __name__ == "__main__":
    main()
