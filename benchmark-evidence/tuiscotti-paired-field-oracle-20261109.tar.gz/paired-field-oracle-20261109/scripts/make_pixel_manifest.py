#!/usr/bin/env python3
"""Make byte-exact scratch copies of the frozen 20-row level-22 corpus."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def git_blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: make_pixel_manifest.py ARCHIVE_ROOT CANDIDATES_TSV OUTPUT_DIR")
    archive, candidates_path, output_dir = map(Path, sys.argv[1:])
    archive = archive.resolve()
    candidates_path = candidates_path.resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    old_root = output_dir / "old"
    new_root = output_dir / "new"
    old_root.mkdir()
    new_root.mkdir()

    with candidates_path.open(encoding="utf-8", newline="") as stream:
        candidates = list(csv.DictReader(stream, delimiter="\t"))
    if len(candidates) != 20:
        raise SystemExit(f"expected 20 frozen candidates, got {len(candidates)}")

    fields = [
        "json_path", "json_sha256", "json_git_blob", "pb_path", "pb_sha256",
        "pb_git_blob", "test_id", "gate",
    ]
    manifest = output_dir / "paired-pixel-manifest.tsv"
    with manifest.open("x", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for index, row in enumerate(candidates):
            candidate_path = Path(row["candidate_path"]).resolve()
            candidate_path.relative_to(archive)
            pb_bytes = candidate_path.read_bytes()
            if hashlib.sha256(pb_bytes).hexdigest() != row["candidate_sha256"]:
                raise SystemExit(f"candidate hash mismatch: {candidate_path}")
            name = candidate_path.name.removesuffix(".protobuf.zstd.22")
            old_source = archive / "captures/old/samples" / f"{name}.json"
            old_bytes = old_source.read_bytes()
            old_sample = json.loads(old_bytes)
            if old_sample["test_id"] != row["test_id"] or old_sample["gate"] != row["gate"]:
                raise SystemExit(f"old capture ID/gate mismatch: {old_source}")
            stem = f"sample-{index + 1:02d}"
            old_rel = f"{stem}.tui.json"
            new_rel = f"{stem}.tui.pb"
            subprocess.run(["/bin/cp", "-c", str(old_source), str(old_root / old_rel)], check=True)
            subprocess.run(["/bin/cp", "-c", str(candidate_path), str(new_root / new_rel)], check=True)
            writer.writerow({
                "json_path": old_rel,
                "json_sha256": hashlib.sha256(old_bytes).hexdigest(),
                "json_git_blob": git_blob_sha1(old_bytes),
                "pb_path": new_rel,
                "pb_sha256": hashlib.sha256(pb_bytes).hexdigest(),
                "pb_git_blob": git_blob_sha1(pb_bytes),
                "test_id": row["test_id"],
                "gate": row["gate"],
            })
    print(json.dumps({
        "pairs": len(candidates),
        "state_and_pixels": sum(row["gate"] == "state-and-pixels" for row in candidates),
        "state": sum(row["gate"] == "state" for row in candidates),
        "old_root": str(old_root),
        "new_root": str(new_root),
        "manifest": str(manifest),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
