#!/usr/bin/env python3
"""Compare a pinned reader to archived independent projection and mutations."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = Path(
    "/private/tmp/tuiscotti-codec-benchmark-archive-verify-20261105/"
    "tuiscotti-codec-benchmark-archive-20261105/captures/old/samples"
)
WORKER = ROOT / "cargo-target/release/tuiscotti-old-pair-projection"
SAMPLE = ARCHIVE / "holla-compact-80x24.pixels.json"
GOLDEN = ARCHIVE / "holla-compact-80x24.pixels.projection.json"
OUT = ROOT / "results/worker-controls-20261109"
PAIR_KEY = "bench/holla-compact-80x24/pixels-macos-aarch64"
SOURCE_REV = "d8d54155947f6303a41dfd6079b53c0abc16f29a"


def rgb(value: list[int]) -> str:
    return "#" + "".join(f"{part:02x}" for part in value)


def color(value: dict[str, object]) -> str:
    kind = value["kind"]
    if kind == "default":
        return "default"
    if kind == "rgb":
        return rgb(value["value"])
    if kind == "indexed":
        return f"indexed:{value['value']}"
    raise AssertionError(f"unexpected color kind {kind!r}")


def normalize_snapshot(snapshot: dict[str, object]) -> dict[str, object]:
    normalized = json.loads(json.dumps(snapshot))
    normalized.pop("metadata")
    normalized["viewport_origin"] = int(normalized["viewport_origin"])
    normalized["palette"] = [rgb(item) for item in normalized["palette"]]
    for key in ("default_foreground", "default_background", "default_cursor"):
        normalized[key] = rgb(normalized[key])
    for cell in normalized["cells"]:
        cell["fg"] = color(cell["fg"])
        cell["bg"] = color(cell["bg"])
        cell["underline_color"] = color(cell["underline_color"])
    normalized["cursor"]["color"] = rgb(normalized["cursor"]["color"])
    return normalized


def f32(value: float) -> str:
    return struct.pack(">f", value).hex()


def f64(value: float) -> str:
    return struct.pack(">d", value).hex()


def normalize_golden_contract(contract: dict[str, object]) -> dict[str, object]:
    normalized = dict(contract)
    for old, new in (
        ("baseline", "baseline_bits"),
        ("cell_height", "cell_height_bits"),
        ("cell_width", "cell_width_bits"),
        ("font_size", "font_size_bits"),
    ):
        normalized[new] = f32(normalized.pop(old))
    normalized["scale_bits"] = f64(normalized.pop("scale"))
    normalized["fonts"] = [
        {**font, "fallback_position": str(font["fallback_position"])}
        for font in normalized["fonts"]
    ]
    return normalized


def invoke(path: Path, index: int) -> dict[str, object]:
    process = subprocess.Popen(
        [str(WORKER)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    request = {
        "pair_index": str(index),
        "relative_path": PAIR_KEY,
        "sample_path": str(path.resolve()),
    }
    assert process.stdin and process.stdout and process.stderr
    process.stdin.write(json.dumps(request, separators=(",", ":")).encode() + b"\n")
    process.stdin.close()
    header = process.stdout.read(8)
    if len(header) != 8:
        raise RuntimeError("worker returned no complete frame header")
    payload = process.stdout.read(int.from_bytes(header, "big"))
    record = json.loads(payload)
    stderr = process.stderr.read().decode(errors="replace")
    status = process.wait(timeout=20)
    if status != 0 or record.get("ok") is not True:
        raise RuntimeError(f"worker failed (status {status}): {stderr}: {record}")
    if record["tuiscotti_source_rev"] != SOURCE_REV or record["relative_path"] != PAIR_KEY:
        raise RuntimeError("worker source/pair binding mismatch")
    return record


def assert_mutation(label: str, mutate, path: str, expected) -> dict[str, object]:
    value = json.loads(SAMPLE.read_text())
    mutate(value)
    destination = OUT / f"mutated-{label}.json"
    destination.write_text(json.dumps(value, separators=(",", ":")) + "\n")
    output = invoke(destination, 1)
    actual = output["sample"]
    cursor = actual
    for component in path.strip("/").split("/"):
        cursor = cursor[int(component)] if isinstance(cursor, list) else cursor[component]
    if cursor != expected:
        raise AssertionError(f"{label}: expected {expected!r}, got {cursor!r}")
    return {
        "name": label,
        "path": path,
        "observed": cursor,
        "input_sha256": output["original_file_sha256"],
        "state_digest": output["state_digest"],
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    raw = json.loads(SAMPLE.read_text())
    golden = json.loads(GOLDEN.read_text())
    record = invoke(SAMPLE, 0)
    sample = record["sample"]
    if sample["gate"] != golden["gate"]:
        raise AssertionError("gate mismatch against archived projection")
    if normalize_snapshot(sample["snapshot"]) != golden["snapshot"]:
        raise AssertionError("snapshot mismatch against archived projection")
    if sample["render_contract"] != normalize_golden_contract(golden["render_contract"]):
        raise AssertionError("render contract mismatch against archived projection")
    image = sample["image"]
    if image["rgba_sha256"] != golden["rgba_sha256"] or not all(
        image[key] is True for key in ("dimensions_match", "png_sha256_matches", "rgba_sha256_matches")
    ):
        raise AssertionError("worker PNG/RGBA validation disagrees with archived projection")
    if record["original_file_sha256"] != hashlib.sha256(SAMPLE.read_bytes()).hexdigest():
        raise AssertionError("input SHA does not bind worker-read bytes")

    mutations = [
        assert_mutation("cell-text", lambda d: d["snapshot"]["cells"][0].update(text="x"), "/snapshot/cells/0/text", "x"),
        assert_mutation("cell-style", lambda d: d["snapshot"]["cells"][0].update(bold=True), "/snapshot/cells/0/bold", True),
        assert_mutation("palette", lambda d: d["snapshot"]["palette"].__setitem__(0, "#010203"), "/snapshot/palette/0", [1, 2, 3]),
        assert_mutation("cursor", lambda d: d["snapshot"]["cursor"].update(visible=False), "/snapshot/cursor/visible", False),
        assert_mutation("contract", lambda d: d["render_contract"].update(font_size=17.0), "/render_contract/font_size_bits", f32(17.0)),
        assert_mutation("metadata", lambda d: d["snapshot"]["metadata"].update(session="mutation-session"), "/snapshot/metadata/session", "mutation-session"),
    ]
    summary = {
        "control": "old-reader against archived independent pixel projection",
        "source_rev": SOURCE_REV,
        "fixture": str(SAMPLE),
        "golden_projection": str(GOLDEN),
        "snapshot_exact_after_schema_normalization": True,
        "render_contract_exact_after_float_bit_normalization": True,
        "rgba_sha256_matches_archived_projection": True,
        "png_rgba_dimensions_hash_checks_all_true": True,
        "mutations": mutations,
        "mutation_scope": "old JSON reader only; no PB bytes were edited or encoded",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
