#!/usr/bin/env python3
"""Bind the audited 1,868 source pairs to their retained Git trees."""

import csv
import hashlib
from pathlib import Path
import sys


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit("usage: make_manifest.py INVENTORY OLD_ROOT NEW_ROOT OUTPUT")
    inventory_path, old_root, new_root, output_path = map(Path, sys.argv[1:])
    old_root = old_root.resolve()
    new_root = new_root.resolve()
    with inventory_path.open(encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source, delimiter="\t"))
    if len(rows) != 1868:
        raise SystemExit(f"expected 1,868 audited pairs, got {len(rows)}")

    fields = [
        "json_path", "json_sha256", "json_git_blob", "pb_path", "pb_sha256",
        "pb_git_blob", "test_id", "gate",
    ]
    prefix = "tests/functional/baselines/pre_refactor/"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("x", encoding="utf-8", newline="") as target:
        writer = csv.DictWriter(target, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in rows:
            json_path = row["json_path"]
            pb_path = row["pb_path"]
            if not json_path.startswith(prefix) or not pb_path.startswith(prefix):
                raise SystemExit(f"unexpected pair root: {json_path} / {pb_path}")
            pb_file = new_root / pb_path[len(prefix):]
            if not pb_file.is_file():
                raise SystemExit(f"missing PB from merged source tree: {pb_file}")
            pb_sha256 = hashlib.sha256(pb_file.read_bytes()).hexdigest()
            writer.writerow({
                "json_path": json_path[len(prefix):],
                "json_sha256": row["json_sha256"],
                "json_git_blob": row["json_git_blob"],
                "pb_path": pb_path[len(prefix):],
                "pb_sha256": pb_sha256,
                "pb_git_blob": row["pb_git_blob"],
                "test_id": row["test_id"],
                "gate": row["gate"],
            })


if __name__ == "__main__":
    main()
