# Paired historical sample reader evidence

This package preserves macOS arm64 comparisons between the old JSON sample
reader and the Protobuf reader, using each pinned Tuiscotti revision in a
separate worker process. The workers read original input bytes and emit typed
field projections; the comparison harness does not translate, encode, accept,
or rewrite a sample. State digests are reported separately from complete
field equality.

## Results

| Cohort | Source pair | Pairs | State digests equal | Full projections equal | Result |
|---|---|---:|---:|---:|---|
| Historical protected roots | TCB `60b5fb2762d91a3549bd4ac63b1d77d534ee53d2` JSON to `534e0ff5af75b840d93038dd02ece0839cf4f71b` PB, `pre_refactor/` | 1,868 | 1,817 | 0 | All decoded and passed byte/tree binding. The 1,817 digest-equal rows differed only in capture metadata. Fifty-one rows had state-digest and nonmetadata field differences; the per-row path list is capped at 1,000 for 28 rows, with exact difference counts retained. |
| Migration transition | TCB `f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a` JSON to `1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1` PB | 161 | 161 | 0 | All decoded and passed byte/tree binding. Differences were limited to `captured_at_ms` (161 rows) and `revision` (158 rows). |
| Frozen archived benchmark pairs | Original benchmark bundle | 20: 10 state, 10 state-and-pixels | 20 | 0 | All decoded; all 10 images passed PNG/RGBA/hash/dimension checks. Differences were limited to capture metadata. |

The 51 historical state differences are observations between separately
captured JSON and PB samples; they do not establish a codec regression. They
may represent changed capture state. The 1,868 `pre_refactor` samples are
protected historical roots, and some have live test consumers. They are not
an inactive archive cohort. The migration comparison is a separate transition
and is not merged into the 1,868 historical-root count.

The 20-row pixel corpus is byte-exact from the frozen benchmark archive:
archive SHA-256 `726afbf093bcc612e055e085cd3a787f53be6a1d6e051e8cfb476235324392b6`,
content-manifest SHA-256
`95056582c499be14c16637692233c033e1f6c40affbd50f77ae4da7f0151f0ef`, old
producer TCB revision `60b5fb2762d91a3549bd4ac63b1d77d534ee53d2`, and candidate
source-tree SHA-256
`279db9c434436aaa2a4b36976a389a92ca7be3ec0dbf06ff9d95388ff8a8e3dd`. The
original JSON/PB inputs, the candidate manifest and one archived independent
projection are included. The bundle content manifest is retained as source
provenance. A separate `subset-binding.tsv` binds each included input and the
projection fixture to the matching entries in that manifest. The comparator
checks the manifest file's SHA-256 and the sample file hashes, but does not
itself check membership in the manifest. The candidate samples are not newly
generated at TCB commit `534e0ff`.

## Worker control

The old JSON worker was compared against the archive's independent typed
projection for a pixel sample. Snapshot fields excluding metadata and
render-contract fields matched after explicit normalization of hex/RGB values,
integer representation and float bit patterns; the archived RGBA SHA-256
matched, and PNG/RGBA/dimension checks all passed. Six disposable JSON
mutations (cell text, cell style,
palette entry, cursor visibility, render-contract font size and metadata
session) were each reflected at the expected projection path. The raw mutated
fixtures and exact command are retained under `results/worker-controls/`.

Those mutation controls exercise the old JSON reader only. No PB bytes were
edited or encoded, so this package does not claim new-reader mutation testing
or independent behavioral proof for every projected PB field. The 20 real PB
samples do exercise the new reader and its PNG validation, while the 1,868 and
161 historical comparisons exercise state-only PB reads.

## Provenance and limits

The workers pin Tuiscotti source revisions `d8d54155947f6303a41dfd6079b53c0abc16f29a`
(old) and `92ef2d9ee082b35f68e066c5129fedbf07675a80` (new). Built release
worker SHA-256 values were:

- Old JSON worker: `1e902359d0bc2036d3e64f0d93dd3c75189e67f0b6d5d4275a592096cf507221`.
- New PB worker: `698e0b0ed5ce1e8e4b05c5c4336468b0125be8653896d39a16de51e7fa089d0e`.

The recorded native host was macOS arm64 with Rust/Cargo `1.99.1` and MBX
`1.29.2`; the isolated build used `MBX_GC_AUTO=0`, scratch cache/target roots,
and offline Cargo. `results/preflight-tools.txt` records the MBX settings and
tool versions. SHA-256 manifests cover this package's code, locks, inputs and
results. The full TCB Git repositories and compiled workers are not included:
the 1,868 and 161 input roots are bound to the public TCB commits and Git blob
IDs in their manifests. The 20-row raw inputs are included.

The recorded build reused copied toolchain files and warmed scratch caches.
Fresh replay from empty Cargo/Rustup homes requires network access to install
the pinned tools and fetch locked dependencies; it is reproducible from the
source revisions and lockfiles but is not an exact-environment replay.

The recorded build reused copied toolchain files and warmed scratch caches.
Fresh replay from empty Cargo/Rustup homes requires network access to install
the pinned tools and fetch locked dependencies; it is reproducible from the
source revisions and lockfiles but is not an exact-environment replay.

The raw paired result JSONL files preserve every row and exact difference
count. Difference paths are capped at 1,000 per row and carry a truncation
flag. The worker processes exited successfully. Each comparison's expected
top-level result is nonzero because full-field equality is false; the original
shell exit status was not separately retained. `commands/REPLAY.md` gives an
explicit replay command and captures its exit status.

The separate baseline inventory still records 73 missing sidecars and 74
receipt gaps; this package neither re-audits nor resolves those gaps. It also
does not complete the original compression benchmark: no per-stratum codec
matrix, full-corpus repeated encode/decode wall/CPU/RSS measurement, or
same-logical-update multi-commit Git sequence is supplied here. The real Git
history measurements remain whole-commit storage observations, not an
equivalent JSON-versus-PB update sequence. Render-read and selected capture
measurements are documented separately. No Linux or cross-platform result is
claimed.

## Contents

- `common/`, `old/`, `new/`: typed read-only workers and pinned dependency
  lockfiles.
- `scripts/`, `tests/`: comparator, source-root manifest tools, the exact old
  worker control source, and a portable replay wrapper for its golden and
  mutation checks.
- `results/`: exact input manifests, full paired JSONL rows, summaries, raw
  stdout/stderr, one real worker control and six mutated JSON controls.
- `environment/`: recorded tool versions, environment allowlist, and the exact
  isolated build helper/profile used for the run.
- `results/pixel-inputs/`: the 20 original archived JSON/PB input files.
- `archive-provenance/`: source candidate manifest, archived content manifest,
  independent projection fixture, and input-to-archive hash binding table.
- `SHA256SUMS`: checksums of the extracted package files.

See `commands/REPLAY.md` for the exact source roots, environment allowlist,
build/replay commands, and output policy.
