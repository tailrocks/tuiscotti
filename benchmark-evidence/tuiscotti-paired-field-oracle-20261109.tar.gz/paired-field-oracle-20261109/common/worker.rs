use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::path::Path;

use base64::Engine as _;
use image::ImageFormat as DecoderFormat;
use serde::Deserialize;
use serde_json::{Value, json};
use sha1::Sha1;
use sha2::{Digest, Sha256};
use tui_test::profile::Rgb;
use tui_test::terminal::cell::Attrs;
use tui_test::{
    SNAPSHOT_SCHEMA_VERSION, SnapshotColor, SnapshotCursorShape, SnapshotScope, SnapshotSource,
    SnapshotUnderline,
};
use tuiscotti::{
    CursorPhase, Gate, ImageFormat, MAX_SAMPLE_FILE_BYTES, RenderContract, SAMPLE_SCHEMA, Sample,
    SampleImage,
};

const PROTOCOL: &str = "tuiscotti.paired-fields.v1";

#[derive(Deserialize)]
struct Request {
    pair_index: String,
    relative_path: String,
    sample_path: String,
}

pub fn run(expected_tuiscotti_rev: &'static str) -> Result<(), Box<dyn std::error::Error>> {
    let stdin = io::stdin();
    let stdout = io::stdout();
    let mut out = stdout.lock();

    for line in BufReader::new(stdin.lock()).lines() {
        let response = match line {
            Ok(line) => match serde_json::from_str::<Request>(&line) {
                Ok(request) => project_request(request, expected_tuiscotti_rev),
                Err(error) => json!({
                    "protocol": PROTOCOL,
                    "ok": false,
                    "error_kind": "request-json",
                    "error": error.to_string(),
                }),
            },
            Err(error) => json!({
                "protocol": PROTOCOL,
                "ok": false,
                "error_kind": "request-io",
                "error": error.to_string(),
            }),
        };
        write_frame(&mut out, &response)?;
    }

    Ok(())
}

fn project_request(request: Request, expected_tuiscotti_rev: &str) -> Value {
    let bytes = match read_bounded(Path::new(&request.sample_path)) {
        Ok(bytes) => bytes,
        Err(error) => {
            return error_record(
                &request,
                expected_tuiscotti_rev,
                "sample-file",
                error.to_string(),
                None,
                None,
            );
        }
    };
    let file_hash = sha256_bytes(&bytes);
    let git_blob_hash = git_blob_sha1(&bytes);

    let sample = match Sample::from_bytes(&bytes) {
        Ok(sample) => sample,
        Err(error) => {
            return error_record(
                &request,
                expected_tuiscotti_rev,
                "sample-decode",
                error.to_string(),
                Some(file_hash),
                Some(git_blob_hash),
            );
        }
    };

    let state_digest = match sample.state_digest() {
        Ok(digest) => digest,
        Err(error) => {
            return error_record(
                &request,
                expected_tuiscotti_rev,
                "state-digest",
                error.to_string(),
                Some(file_hash),
                Some(git_blob_hash),
            );
        }
    };

    let projected = match project_sample(&sample) {
        Ok(projected) => projected,
        Err(error) => {
            return error_record(
                &request,
                expected_tuiscotti_rev,
                "image-integrity",
                error,
                Some(file_hash),
                Some(git_blob_hash),
            );
        }
    };
    json!({
        "protocol": PROTOCOL,
        "ok": true,
        "tuiscotti_source_rev": expected_tuiscotti_rev,
        "pair_index": request.pair_index,
        "relative_path": request.relative_path,
        "original_file_sha256": file_hash,
        "original_file_git_blob_sha1": git_blob_hash,
        "sample": projected,
        "state_digest": state_digest,
    })
}

fn error_record(
    request: &Request,
    expected_tuiscotti_rev: &str,
    kind: &str,
    error: String,
    file_hash: Option<String>,
    git_blob_hash: Option<String>,
) -> Value {
    json!({
        "protocol": PROTOCOL,
        "ok": false,
        "tuiscotti_source_rev": expected_tuiscotti_rev,
        "pair_index": request.pair_index,
        "relative_path": request.relative_path,
        "original_file_sha256": file_hash,
        "original_file_git_blob_sha1": git_blob_hash,
        "error_kind": kind,
        "error": error,
    })
}

fn project_sample(sample: &Sample) -> Result<Value, String> {
    let snapshot = sample.snapshot();
    let metadata = snapshot.metadata();
    let cursor = snapshot.cursor();
    let cells = snapshot
        .cells()
        .iter()
        .map(|cell| {
            json!({
                "text": cell.text(),
                "width": cell.width(),
                "fg": color(cell.fg()),
                "bg": color(cell.bg()),
                "bold": cell.has(Attrs::BOLD),
                "dim": cell.has(Attrs::DIM),
                "italic": cell.has(Attrs::ITALIC),
                "inverse": cell.has(Attrs::INVERSE),
                "invisible": cell.has(Attrs::INVISIBLE),
                "strike": cell.has(Attrs::STRIKE),
                "blink": cell.has(Attrs::BLINK),
                "underline": underline(cell.underline()),
                "underline_color": color(cell.underline_color()),
                "link_uri": cell.link_uri(),
                "link_id": cell.link_id(),
            })
        })
        .collect::<Vec<_>>();
    let palette = snapshot.palette().iter().copied().map(rgb).collect::<Vec<_>>();

    let projected = json!({
        "schema": SAMPLE_SCHEMA,
        "test_id": sample.test_id(),
        "gate": gate(sample.gate()),
        "snapshot": {
            "schema": SNAPSHOT_SCHEMA_VERSION,
            "cols": snapshot.cols(),
            "rows": snapshot.rows(),
            "scope": scope(snapshot.scope()),
            "viewport_origin": snapshot.viewport_origin().to_string(),
            "cells": cells,
            "palette": palette,
            "default_foreground": rgb(snapshot.default_foreground()),
            "default_background": rgb(snapshot.default_background()),
            "default_cursor": rgb(snapshot.default_cursor()),
            "cursor": {
                "col": cursor.col(),
                "row": cursor.row(),
                "in_capture": cursor.in_capture(),
                "visible": cursor.visible(),
                "shape": cursor_shape(cursor.shape()),
                "color": rgb(cursor.color()),
                "blink": cursor.blink(),
            },
            "title": snapshot.title(),
            "metadata": {
                "captured_at_ms": metadata.captured_at_ms.to_string(),
                "revision": metadata.revision.to_string(),
                "backend": metadata.backend.as_str(),
                "session": metadata.session.as_str(),
                "source": snapshot_source(metadata.source),
            },
        },
        "render_contract": sample.render_contract().map(render_contract),
        "image": sample.image().map(image).transpose()?,
        "observation": {
            "note": sample.observation().note(),
        },
    });
    Ok(projected)
}

fn render_contract(contract: &RenderContract) -> Value {
    let fonts = contract
        .fonts()
        .iter()
        .map(|font| {
            json!({
                "digest": font.digest(),
                "face_index": font.face_index(),
                "bold": font.bold(),
                "italic": font.italic(),
                "fallback_position": font.fallback_position().to_string(),
            })
        })
        .collect::<Vec<_>>();

    json!({
        "profile": contract.profile(),
        "contract_version": contract.contract_version(),
        "renderer_version": contract.renderer_version(),
        "raster_policy": contract.raster_policy(),
        "fonts": fonts,
        "cell_width_bits": format!("{:08x}", contract.cell_width().to_bits()),
        "cell_height_bits": format!("{:08x}", contract.cell_height().to_bits()),
        "font_size_bits": format!("{:08x}", contract.font_size().to_bits()),
        "baseline_bits": format!("{:08x}", contract.baseline().to_bits()),
        "scale_bits": format!("{:016x}", contract.scale().to_bits()),
        "title_bar": contract.title_bar(),
        "palette_digest": contract.palette_digest(),
        "cursor_phase": cursor_phase(contract.cursor_phase()),
        "blink": contract.blink(),
        "platform_key": contract.platform_key(),
    })
}

fn image(image: &SampleImage) -> Result<Value, String> {
    let png = base64::engine::general_purpose::STANDARD
        .decode(image.png_base64())
        .map_err(|error| format!("PNG base64 decode failed: {error}"))?;
    let png_sha256 = sha256_bytes(&png);
    let decoded = image::load_from_memory_with_format(&png, DecoderFormat::Png)
        .map_err(|error| format!("PNG decode failed: {error}"))?;
    let rgba = decoded.to_rgba8();
    let width = rgba.width();
    let height = rgba.height();
    let rgba_bytes = rgba.into_raw();
    let rgba_sha256 = sha256_bytes(&rgba_bytes);
    if png_sha256 != image.png_sha256() {
        return Err(format!(
            "stored PNG SHA-256 {} differs from computed {png_sha256}",
            image.png_sha256()
        ));
    }
    if rgba_sha256 != image.rgba_sha256() {
        return Err(format!(
            "stored RGBA SHA-256 {} differs from computed {rgba_sha256}",
            image.rgba_sha256()
        ));
    }
    if width != image.width() || height != image.height() {
        return Err(format!(
            "stored dimensions {}x{} differ from decoded {width}x{height}",
            image.width(),
            image.height()
        ));
    }

    Ok(json!({
        "format": image_format(image.format()),
        "width": image.width(),
        "height": image.height(),
        "png_sha256": image.png_sha256(),
        "rgba_sha256": image.rgba_sha256(),
        "png_base64": image.png_base64(),
        "rgba_base64": base64::engine::general_purpose::STANDARD.encode(&rgba_bytes),
        "png_sha256_computed": png_sha256,
        "rgba_sha256_computed": rgba_sha256,
        "decoded_width": width,
        "decoded_height": height,
        "png_sha256_matches": true,
        "rgba_sha256_matches": true,
        "dimensions_match": true,
    }))
}

fn color(value: SnapshotColor) -> Value {
    match value {
        SnapshotColor::Default => json!({ "kind": "default" }),
        SnapshotColor::Indexed(value) => json!({ "kind": "indexed", "value": value }),
        SnapshotColor::Rgb(r, g, b) => json!({ "kind": "rgb", "value": [r, g, b] }),
    }
}

fn rgb(value: Rgb) -> Value {
    json!([value.r, value.g, value.b])
}

fn gate(value: Gate) -> &'static str {
    match value {
        Gate::State => "state",
        Gate::StateAndPixels => "state-and-pixels",
    }
}

fn scope(value: SnapshotScope) -> &'static str {
    match value {
        SnapshotScope::Viewport => "viewport",
        SnapshotScope::ActiveScreen => "active_screen",
        SnapshotScope::FullHistory => "full_history",
    }
}

fn snapshot_source(value: SnapshotSource) -> &'static str {
    match value {
        SnapshotSource::Live => "live",
        SnapshotSource::Offline => "offline",
    }
}

fn cursor_shape(value: SnapshotCursorShape) -> &'static str {
    match value {
        SnapshotCursorShape::Block => "block",
        SnapshotCursorShape::Underline => "underline",
        SnapshotCursorShape::Bar => "bar",
    }
}

fn underline(value: SnapshotUnderline) -> &'static str {
    value.name()
}

fn cursor_phase(value: CursorPhase) -> &'static str {
    match value {
        CursorPhase::Shown => "shown",
        CursorPhase::Hidden => "hidden",
    }
}

fn image_format(value: ImageFormat) -> &'static str {
    match value {
        ImageFormat::Png => "png",
    }
}

fn read_bounded(path: &Path) -> io::Result<Vec<u8>> {
    let mut file = File::open(path)?;
    let mut bytes = Vec::new();
    Read::take(&mut file, MAX_SAMPLE_FILE_BYTES + 1).read_to_end(&mut bytes)?;
    if bytes.len() as u64 > MAX_SAMPLE_FILE_BYTES {
        return Err(io::Error::other(format!(
            "sample exceeds bounded input limit of {MAX_SAMPLE_FILE_BYTES} bytes"
        )));
    }
    Ok(bytes)
}

fn sha256_bytes(bytes: &[u8]) -> String {
    hex(&Sha256::digest(bytes))
}

fn git_blob_sha1(bytes: &[u8]) -> String {
    let mut hasher = Sha1::new();
    hasher.update(format!("blob {}\0", bytes.len()).as_bytes());
    hasher.update(bytes);
    hex(&hasher.finalize())
}

fn hex(bytes: &[u8]) -> String {
    use std::fmt::Write as _;
    let mut output = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        let _ = write!(&mut output, "{byte:02x}");
    }
    output
}

fn write_frame(out: &mut impl Write, value: &Value) -> io::Result<()> {
    let payload = serde_json::to_vec(value).map_err(io::Error::other)?;
    let length = u64::try_from(payload.len())
        .map_err(|_| io::Error::other("projection frame exceeds u64 length"))?;
    out.write_all(&length.to_be_bytes())?;
    out.write_all(&payload)?;
    out.flush()
}
