#!/bin/sh
set -eu
ROOT=/Users/donbeave/Projects/tailrocks/tuiscotti-benchmark-closure-20261108/paired-oracle-20261108
exec /usr/bin/env -i \
  HOME=/Users/donbeave \
  PATH=/usr/bin:/bin \
  TMPDIR=/private/tmp/tcb-pair-oracle-20261109 \
  MISE_DATA_DIR="$ROOT/mise-data" \
  MISE_CACHE_DIR="$ROOT/mise-cache" \
  MISE_STATE_DIR="$ROOT/mise-state-trusted" \
  MISE_CONFIG_DIR="$ROOT/mise-config" \
  MISE_CONFIG_FILE="$ROOT/mise.toml" \
  MISE_AUTO_INSTALL=0 \
  MISE_TRUSTED_CONFIG_PATHS="$ROOT" \
  CARGO_HOME="$ROOT/cargo-home" \
  CARGO_TARGET_DIR="$ROOT/cargo-target" \
  CARGO_NET_OFFLINE=true \
  RUSTUP_HOME="$ROOT/rustup-home" \
  MBX_CACHE_DIR="$ROOT/mbx-cache" \
  MBX_TARGET_ROOT="$ROOT/mbx-target" \
  MBX_GC_AUTO=0 \
  GIT_CONFIG_NOSYSTEM=1 \
  GIT_CONFIG_GLOBAL=/dev/null \
  GIT_TERMINAL_PROMPT=0 \
  "$ROOT/mise-bin/mise" exec -- "$@"
