import copy
import io
import json
import struct
import unittest

from scripts.compare import CompareError, compare_paths, mismatch_paths, read_frame, validate_projection


class FrameTests(unittest.TestCase):
    def test_length_framed_projection_roundtrip_preserves_large_integers_and_options(self):
        projection = {
            "schema": "tuiscotti.paired-fields.v1",
            "snapshot": {
                "viewport_origin": "18446744073709551615",
                "metadata": {"revision": "9007199254740993"},
                "cursor": {"blink": False},
            },
            "render_contract": None,
            "image": {
                "png_sha256": "a" * 64,
                "rgba_sha256": "b" * 64,
                "png_base64": "AA==",
                "rgba_base64": "AQIDBA==",
            },
            "observation": {"note": None},
        }
        payload = json.dumps(projection, separators=(",", ":")).encode()
        frame = struct.pack(">Q", len(payload)) + payload
        self.assertEqual(read_frame(io.BytesIO(frame), 1.0), projection)

    def test_rejects_truncated_length_header(self):
        with self.assertRaisesRegex(CompareError, "truncated frame header"):
            read_frame(io.BytesIO(b"\x00\x00"), 1.0)

    def test_rejects_truncated_payload(self):
        with self.assertRaisesRegex(CompareError, "truncated frame"):
            read_frame(io.BytesIO(struct.pack(">Q", 4) + b"{}"), 1.0)

    def test_caps_difference_diagnostics_without_hiding_difference_count(self):
        count, paths = compare_paths({"a": [0, 0, 0]}, {"a": [1, 2, 3]}, "", 1)
        self.assertEqual(count, 3)
        self.assertEqual(paths, ["/a/0"])


class FieldMutationTests(unittest.TestCase):
    def setUp(self):
        self.sample = {
            "schema": "tuiscotti.sample.v1",
            "test_id": "functional/example",
            "gate": "state-and-pixels",
            "snapshot": {
                "schema": 1,
                "cols": 1,
                "rows": 1,
                "scope": "viewport",
                "viewport_origin": "9007199254740993",
                "cells": [{
                    "text": "x",
                    "width": 1,
                    "fg": {"kind": "default"},
                    "bg": {"kind": "rgb", "value": [1, 2, 3]},
                    "bold": False,
                    "dim": False,
                    "italic": False,
                    "inverse": False,
                    "invisible": False,
                    "strike": False,
                    "blink": False,
                    "underline": "none",
                    "underline_color": {"kind": "default"},
                    "link_uri": None,
                    "link_id": None,
                }],
                "palette": [[0, 0, 0]] * 256,
                "default_foreground": [255, 255, 255],
                "default_background": [0, 0, 0],
                "default_cursor": [255, 255, 255],
                "cursor": {
                    "col": 0,
                    "row": 0,
                    "in_capture": True,
                    "visible": True,
                    "shape": "block",
                    "color": [255, 255, 255],
                    "blink": None,
                },
                "title": None,
                "metadata": {
                    "captured_at_ms": "9007199254740993",
                    "revision": "18446744073709551615",
                    "backend": "alacritty",
                    "session": "fixture",
                    "source": "live",
                },
            },
            "render_contract": {
                "profile": "test",
                "contract_version": 1,
                "renderer_version": "test",
                "raster_policy": "test",
                "fonts": [{
                    "digest": "c" * 64,
                    "face_index": 0,
                    "bold": False,
                    "italic": False,
                    "fallback_position": "0",
                }],
                "cell_width_bits": "3f800000",
                "cell_height_bits": "3f800000",
                "font_size_bits": "3f800000",
                "baseline_bits": "3f800000",
                "scale_bits": "3ff0000000000000",
                "title_bar": False,
                "palette_digest": "d" * 64,
                "cursor_phase": "shown",
                "blink": None,
                "platform_key": "test",
            },
            "image": {
                "format": "png",
                "width": 1,
                "height": 1,
                "png_sha256": "a" * 64,
                "rgba_sha256": "b" * 64,
                "png_base64": "AA==",
                "rgba_base64": "AQIDBA==",
                "png_sha256_computed": "a" * 64,
                "rgba_sha256_computed": "b" * 64,
                "decoded_width": 1,
                "decoded_height": 1,
                "png_sha256_matches": True,
                "rgba_sha256_matches": True,
                "dimensions_match": True,
            },
            "observation": {"note": None},
        }

    def assert_mutation_detected(self, path, mutate):
        changed = copy.deepcopy(self.sample)
        mutate(changed)
        self.assertEqual(mismatch_paths(self.sample, changed), [path])

    def test_optional_fields_preserve_none_false_and_empty_string(self):
        changed = copy.deepcopy(self.sample)
        changed["snapshot"]["cursor"]["blink"] = False
        changed["snapshot"]["cells"][0]["link_uri"] = ""
        changed["observation"]["note"] = ""
        self.assertEqual(
            mismatch_paths(self.sample, changed),
            [
                "/observation/note",
                "/snapshot/cells/0/link_uri",
                "/snapshot/cursor/blink",
            ],
        )

    def test_float_bit_patterns_detect_negative_zero(self):
        self.assert_mutation_detected(
            "/render_contract/cell_width_bits",
            lambda value: value["render_contract"].__setitem__("cell_width_bits", "80000000"),
        )

    def test_image_metadata_and_both_byte_streams_are_compared(self):
        mutations = [
            ("/image/png_sha256", "d" * 64),
            ("/image/rgba_sha256", "e" * 64),
            ("/image/png_base64", "Ag=="),
            ("/image/rgba_base64", "BQYHCA=="),
            ("/image/decoded_width", 2),
        ]
        for path, value in mutations:
            with self.subTest(path=path):
                self.assert_mutation_detected(
                    path,
                    lambda sample, p=path, v=value: set_path(sample, p, v),
                )

    def test_snapshot_observation_metadata_is_compared_separately_from_digest(self):
        self.assert_mutation_detected(
            "/snapshot/metadata/session",
            lambda sample: sample["snapshot"]["metadata"].__setitem__("session", "other"),
        )

    def test_projection_requires_schema_id_digest_and_complete_top_level_fields(self):
        record = {"sample": self.sample, "state_digest": "a" * 64}
        self.assertIs(validate_projection(record, "functional/example", "old"), self.sample)
        with self.assertRaisesRegex(CompareError, "test ID"):
            validate_projection(record, "functional/other", "old")
        with self.assertRaisesRegex(CompareError, "state digest"):
            validate_projection({"sample": self.sample, "state_digest": "bad"}, "functional/example", "old")
        malformed = copy.deepcopy(record)
        malformed["sample"].pop("observation")
        with self.assertRaisesRegex(CompareError, "fields differ"):
            validate_projection(malformed, "functional/example", "old")


def set_path(value, path, replacement):
    parts = path.strip("/").split("/")
    parent = value
    for part in parts[:-1]:
        parent = parent[part]
    parent[parts[-1]] = replacement


if __name__ == "__main__":
    unittest.main()
