#[path = "../../common/worker.rs"]
mod worker;

fn main() {
    if let Err(error) = worker::run("92ef2d9ee082b35f68e066c5129fedbf07675a80") {
        eprintln!("projection worker failed: {error}");
        std::process::exit(2);
    }
}
