#![allow(missing_docs)]

use std::{env, fs, path::Path};

use image::ImageFormat;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use tui_test::{TerminalSnapshot, render_snapshot_png};
use tuiscotti::render_profile::{PROFILE_NAME, resolve_profile};

fn sha256(bytes: &[u8]) -> String {
    Sha256::digest(bytes).iter().map(|byte| format!("{byte:02x}")).collect()
}

fn read_snapshot(snapshot_path: &str, old_json_path: &str) -> Result<(TerminalSnapshot, Value), Box<dyn std::error::Error>> {
    let snapshot_bytes = fs::read(snapshot_path)?;
    let old_bytes = fs::read(old_json_path)?;
    let snapshot_value: Value = serde_json::from_slice(&snapshot_bytes)?;
    let old_value: Value = serde_json::from_slice(&old_bytes)?;
    if old_value.get("snapshot") != Some(&snapshot_value) {
        return Err(format!("snapshot fixture differs from its paired old JSON: {snapshot_path}").into());
    }
    let snapshot: TerminalSnapshot = serde_json::from_value(snapshot_value.clone())?;
    let info = json!({
        "snapshot_path": snapshot_path,
        "snapshot_sha256": sha256(&snapshot_bytes),
        "old_json_path": old_json_path,
        "old_json_sha256": sha256(&old_bytes),
        "test_id": old_value.get("test_id"),
        "gate_in_source_json": old_value.get("gate"),
        "snapshot_input_matches_old_json": true,
    });
    Ok((snapshot, info))
}

fn render(snapshot: &TerminalSnapshot, out: &Path) -> Result<(Vec<u8>, Vec<u8>, u32, u32, String), Box<dyn std::error::Error>> {
    let profile = resolve_profile(PROFILE_NAME)?;
    let rendered = render_snapshot_png(snapshot, &profile.render_options())?;
    let png = rendered.png().to_vec();
    fs::write(out, &png)?;
    let rgba = image::load_from_memory_with_format(&png, ImageFormat::Png)?.to_rgba8().into_raw();
    let contract = format!("{:#?}", rendered.contract());
    Ok((png, rgba, rendered.width(), rendered.height(), contract))
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 9 {
        return Err("usage: real-pixel-render-pair <left-revision> <left-snapshot> <left-old-json> <left-png> <right-revision> <right-snapshot> <right-old-json> <right-png>".into());
    }
    let left_revision = &args[1];
    let left_snapshot_path = &args[2];
    let left_old_json_path = &args[3];
    let left_png_path = &args[4];
    let right_revision = &args[5];
    let right_snapshot_path = &args[6];
    let right_old_json_path = &args[7];
    let right_png_path = args.get(8).ok_or("missing right PNG output path")?;
    let (left_snapshot, left_info) = read_snapshot(left_snapshot_path, left_old_json_path)?;
    let (right_snapshot, right_info) = read_snapshot(right_snapshot_path, right_old_json_path)?;
    let (left_png, left_rgba, left_width, left_height, left_contract) = render(&left_snapshot, Path::new(left_png_path))?;
    let (right_png, right_rgba, right_width, right_height, right_contract) = render(&right_snapshot, Path::new(right_png_path))?;
    if (left_width, left_height) != (right_width, right_height) || left_rgba.len() != right_rgba.len() {
        return Err("rendered image dimensions differ".into());
    }
    let mut changed_pixels = 0u64;
    let mut absolute_channel_delta = 0u64;
    for (a, b) in left_rgba.chunks_exact(4).zip(right_rgba.chunks_exact(4)) {
        let mut changed = false;
        for (x, y) in a.iter().zip(b) {
            if x != y { changed = true; }
            absolute_channel_delta += u64::from(x.abs_diff(*y));
        }
        if changed { changed_pixels += 1; }
    }
    let profile = resolve_profile(PROFILE_NAME)?;
    let result = json!({
        "classification": "reconstructed deterministic rendering of captured historical snapshots; not a historical pixel-gate capture",
        "renderer_profile": profile.name(),
        "renderer_contract": "tuiscotti-pinned-v1; see embedded contract in renderer source",
        "left": {"source_revision": left_revision, "input": left_info, "width": left_width, "height": left_height, "render_contract_debug": left_contract, "png_path": left_png_path, "png_bytes": left_png.len(), "png_sha256": sha256(&left_png), "rgba_bytes": left_rgba.len(), "rgba_sha256": sha256(&left_rgba)},
        "right": {"source_revision": right_revision, "input": right_info, "width": right_width, "height": right_height, "render_contract_debug": right_contract, "png_path": right_png_path, "png_bytes": right_png.len(), "png_sha256": sha256(&right_png), "rgba_bytes": right_rgba.len(), "rgba_sha256": sha256(&right_rgba)},
        "diff": {"changed_pixels": changed_pixels, "total_pixels": u64::from(left_width) * u64::from(left_height), "absolute_rgba_channel_delta": absolute_channel_delta}
    });
    println!("{}", serde_json::to_string_pretty(&result)?);
    Ok(())
}
