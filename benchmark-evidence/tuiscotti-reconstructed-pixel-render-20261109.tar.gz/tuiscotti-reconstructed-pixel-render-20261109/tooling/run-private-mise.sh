#!/bin/sh
set -eu
SCR=/private/tmp/tuiscotti-real-pixel-renders-20261109
TOOLS=/private/tmp/tuiscotti-history-execution-20261109
export HOME="$SCR/env/home" TMPDIR="$SCR/env/tmp" XDG_CONFIG_HOME="$SCR/env/xdg-config" XDG_CACHE_HOME="$SCR/env/xdg-cache" XDG_STATE_HOME="$SCR/env/xdg-state" XDG_DATA_HOME="$SCR/env/xdg-data"
export PATH="$TOOLS/cache-v2/mise-data/installs/mr-boxington/1.29.2/.mise-bins:$TOOLS/cache-v2/cargo-home/bin:/usr/bin:/bin"
export MISE_OFFLINE=1 MISE_DATA_DIR="$TOOLS/cache-v2/mise-data" MISE_CACHE_DIR="$SCR/mise-cache" MISE_STATE_DIR="$SCR/mise-state" MISE_CONFIG_DIR="$SCR/mise-config" MISE_CONFIG_FILE="$SCR/env/mise-wrapper.toml" MISE_AUTO_INSTALL=0 MISE_TRUSTED_CONFIG_PATHS="$SCR"
export CARGO_HOME="$TOOLS/cache-v2/cargo-home" CARGO_TARGET_DIR="$SCR/target-mbx/cargo" CARGO_NET_OFFLINE=true RUSTUP_HOME="$TOOLS/cache-v2/rustup-home"
export MBX_CACHE_DIR="$SCR/mbx-cache" MBX_TARGET_ROOT="$SCR/mbx-target-root" MBX_GC_AUTO=0
exec "$TOOLS/env/bin/mise" "$@"
