# Reconstructed historical pixel render supplement

This supplement records a deterministic offline render comparison of the two real Tuiscotti snapshots identified below. The source captures and old JSON are retained in the published base archive; this package deliberately references that archive by path and SHA-256 instead of copying its legacy sample files.

- Base archive: `benchmark-evidence/tuiscotti-selected-history-evidence-20261109.tar.gz`
- Base archive SHA-256: `a5b0e432f55d39fc2d74a7be6826826bcfa8d7ae23f2752516b10e825f1a6305`
- Renderer source: Tuiscotti commit `6d01628170de8bed3f00f52713f3a510b782e41e`, verified against the source used for both runs.
- Toolchain: mise-managed Rust 1.99.1 and `mbx` 1.29.2. `tooling/mise-wrapper.toml`, `tooling/mise-doctor.log`, and `tooling/wrapper-paths.log` record wrapper evidence; `output/run.log` and `output/repeat.log` retain command and completion logs.
- Input hashes, source revisions, archive-relative capture paths, output hashes, and the comparison totals are in `input-map.json`.

The comparison is 158,537 changed pixels out of 960,000, with summed absolute RGBA channel delta 27,148,953. Repeating the render produced byte-identical PNGs and matching comparison JSON.

## Limits

These are newly reconstructed PNG renders from historical captured snapshots. They are not historical stored pixel-gate captures, and no pixel-gate sample was created or accepted. The captured source JSON records the `state` gate. The two snapshots represent a real cell/style update (1,902 of 4,800 cells); their 256-entry palette table is unchanged. This evidence does not establish a palette-table update or close the historical pixel-gate coverage gap.

To reproduce, extract the base archive, check its SHA-256, check out the renderer source commit above, and invoke the example using the pinned profile and the archive-relative inputs mapped in `input-map.json`. The captured tool logs show the actual isolated `mise exec -- mbx +1.99.1 run ... --locked --offline` invocation and repeat.
