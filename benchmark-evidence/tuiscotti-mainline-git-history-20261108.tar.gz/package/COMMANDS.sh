#!/bin/sh
# Reproduce two actual TCB mainline transitions. Use a fresh scratch root.
set -eu
REMOTE=https://github.com/tailrocks/terminal-components-baseline.git
ROOT=/path/to/scratch/tcb-history
R=$ROOT/sequential/repo
mkdir -p "$R"
git init --initial-branch=main "$R"
git -C "$R" remote add origin "$REMOTE"

# Start at the exact JSON-history parent.
git -C "$R" fetch --no-tags origin f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a
git -C "$R" checkout --detach FETCH_HEAD
git -C "$R" repack -Adf --window=10 --depth=50
git -C "$R" count-objects -v

# Measure the actual merged Protobuf migration commit against that parent.
git -C "$R" fetch --no-tags origin 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1
git -C "$R" checkout --detach FETCH_HEAD
git -C "$R" repack -Adf --window=10 --depth=50
git -C "$R" count-objects -v
find "$R/.git/objects/pack" -name '*.pack' -exec stat -f '%z %N' {} \;
printf '%s\n^%s\n' 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1 f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a | \
  git -C "$R" pack-objects --stdout --revs --thin --window=10 --depth=50 > "$ROOT/f539-to-1d.thin.pack"

# Measure the actual merged PR2 main commit against the migration commit.
git -C "$R" fetch --no-tags origin 534e0ff5af75b840d93038dd02ece0839cf4f71b
git -C "$R" checkout --detach FETCH_HEAD
git -C "$R" repack -Adf --window=10 --depth=50
git -C "$R" count-objects -v
find "$R/.git/objects/pack" -name '*.pack' -exec stat -f '%z %N' {} \;
printf '%s\n^%s\n' 534e0ff5af75b840d93038dd02ece0839cf4f71b 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1 | \
  git -C "$R" pack-objects --stdout --revs --thin --window=10 --depth=50 > "$ROOT/1d-to-534.thin.pack"

# Verify exact commit identities and mainline parentage.
git -C "$R" show -s --format='%H %P %cI %s' f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a
git -C "$R" show -s --format='%H %P %cI %s' 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1
git -C "$R" show -s --format='%H %P %cI %s' 534e0ff5af75b840d93038dd02ece0839cf4f71b

# Inspect active baseline, archived sample, and receipt blob identities/sizes.
for c in f539d9a61b1fe1e9fab13f4e976c872b09b8fb9a 1d7f63dbb13ecb2bf3e3295e7a296dc2080a62b1 534e0ff5af75b840d93038dd02ece0839cf4f71b; do
  for p in tests/functional/baselines/functional apps/jackin/tests/functional/baselines/functional tests/functional/baselines/showcase/buttons tests/functional/baselines/pre_refactor docs/testing/acceptance-receipts; do
    git -C "$R" ls-tree -r -l "$c" -- "$p"
  done
done
