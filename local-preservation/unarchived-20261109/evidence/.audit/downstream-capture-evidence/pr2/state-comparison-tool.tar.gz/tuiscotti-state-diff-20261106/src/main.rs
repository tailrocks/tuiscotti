use std::{error::Error, path::PathBuf};
use serde_json::Value;
use tuiscotti::sample::Sample;

fn row_text(cells: &[Value], cols: usize, row: usize) -> String {
    let start = row * cols;
    cells.get(start..start + cols).unwrap_or(&[]).iter()
        .filter_map(|cell| cell.get("text").and_then(Value::as_str))
        .filter(|text| !text.is_empty())
        .collect::<String>()
        .trim_end()
        .to_string()
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut args = std::env::args_os().skip(1);
    let keys = ["cols", "rows", "scope", "viewport_origin", "palette", "default_foreground", "default_background", "default_cursor", "cursor", "title"];
    let cell_keys = ["text", "width", "fg", "bg", "bold", "dim", "italic", "inverse", "invisible", "strike", "blink", "underline", "underline_color", "link_uri", "link_id"];
    loop {
        let Some(old_path) = args.next() else { break };
        let new_path = args.next().ok_or("expected old/new path pairs")?;
        let old_path = PathBuf::from(old_path);
        let new_path = PathBuf::from(new_path);
        let old_sample: Value = serde_json::from_slice(&std::fs::read(&old_path)?)?;
        let old = old_sample.get("snapshot").ok_or("old JSON sample missing snapshot")?;
        let new_sample = Sample::from_file(&new_path)?;
        let new = serde_json::to_value(new_sample.snapshot())?;
        let mut changed = Vec::new();
        for key in keys {
            if old.get(key) != new.get(key) { changed.push(key); }
        }
        let old_cells = old["cells"].as_array().ok_or("old cells not array")?;
        let new_cells = new["cells"].as_array().ok_or("new cells not array")?;
        let mut changed_cells = 0usize;
        let mut field_counts = vec![0usize; cell_keys.len()];
        for i in 0..old_cells.len().max(new_cells.len()) {
            let a = old_cells.get(i);
            let b = new_cells.get(i);
            if a != b {
                changed_cells += 1;
                for (j, key) in cell_keys.iter().enumerate() {
                    if a.and_then(|v| v.get(*key)) != b.and_then(|v| v.get(*key)) { field_counts[j] += 1; }
                }
            }
        }
        let old_cols = old["cols"].as_u64().unwrap_or(1).max(1) as usize;
        let new_cols = new["cols"].as_u64().unwrap_or(1).max(1) as usize;
        let rows = old["rows"].as_u64().unwrap_or(0).max(new["rows"].as_u64().unwrap_or(0)) as usize;
        let mut text_rows = Vec::new();
        for row in 0..rows {
            let a = row_text(old_cells, old_cols, row);
            let b = row_text(new_cells, new_cols, row);
            if a != b { text_rows.push((row, a, b)); }
        }
        let changed_cell_fields: Vec<_> = cell_keys.iter().zip(field_counts).filter_map(|(k,n)| (n>0).then_some(format!("{k}:{n}"))).collect();
        println!("{} -> {} | old={} gate={} {}x{}; new={} gate={:?} {}x{} | changed_snapshot_fields={:?}; changed_cells={}; cell_field_counts={:?}; text_rows_changed={}",
            old_path.file_name().unwrap().to_string_lossy(), new_path.file_name().unwrap().to_string_lossy(),
            old_sample["test_id"], old_sample["gate"], old["cols"], old["rows"],
            new_sample.test_id(), new_sample.gate(), new["cols"], new["rows"], changed,
            changed_cells, changed_cell_fields, text_rows.len());
        for (row, a, b) in text_rows.iter().take(4) {
            println!("  row {row}: old={:?}\n         new={:?}", a, b);
        }
    }
    Ok(())
}
