#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p logs
for run in 1 2 3 4 5; do
    status=0
    env DYLD_INSERT_LIBRARIES="$PWD/hook.dylib" "$PWD/tuiscotti-allocator-probe" >"logs/run-$run.stdout" 2>"logs/run-$run.stderr" || status=$?
    printf '%s\n' "$status" >"logs/run-$run.exit"
    if [ "$status" -ne 0 ]; then printf 'run %s failed: %s\n' "$run" "$status" >&2; exit "$status"; fi
done
