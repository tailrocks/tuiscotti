#include <stdlib.h>
#include <stddef.h>
#include <stdatomic.h>
#include <stdint.h>
#include <dlfcn.h>
static _Atomic size_t target, matches, denied;
static _Atomic int armed;
static void *site;
void probe_arm(size_t n) { atomic_store(&target,n); atomic_store(&matches,0); atomic_store(&denied,0); site=NULL; atomic_store(&armed,1); }
void probe_stop(void) { atomic_store(&armed,0); }
size_t probe_matches(void) { return atomic_load(&matches); }
size_t probe_denied(void) { return atomic_load(&denied); }
const char *probe_site(void) { Dl_info info; return site && dladdr(site,&info) && info.dli_sname ? info.dli_sname : "unknown"; }
static void *probe_malloc(size_t n) {
    if (atomic_load(&armed) && n == atomic_load(&target)) {
        size_t prior=atomic_fetch_add(&matches,1);
        if (prior==0) { site=__builtin_return_address(0); atomic_fetch_add(&denied,1); return NULL; }
    }
    return malloc(n);
}
__attribute__((used)) static struct { const void *replacement; const void *replacee; } interpose __attribute__((section("__DATA,__interpose"))) = { (const void *)probe_malloc, (const void *)malloc };
