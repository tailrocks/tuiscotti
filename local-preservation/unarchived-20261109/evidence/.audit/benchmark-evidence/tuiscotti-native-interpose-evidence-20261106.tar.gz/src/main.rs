use std::error::Error;
use std::ffi::{c_char,c_void,CStr};
use tuiscotti::sample::{Sample,SampleError};
#[allow(dead_code)] mod fixtures;
unsafe extern "C" { fn dlsym(handle:*mut c_void, name:*const c_char)->*mut c_void; }
unsafe fn symbol(name:&CStr)->*mut c_void { let ptr = unsafe { dlsym((-2_isize) as *mut c_void,name.as_ptr()) }; assert!(!ptr.is_null(), "missing hook symbol {name:?}"); ptr }
fn main()->Result<(),Box<dyn Error>> {
    let arm = unsafe { std::mem::transmute::<*mut c_void,unsafe extern "C" fn(usize)>(symbol(c"probe_arm")) };
    let stop = unsafe { std::mem::transmute::<*mut c_void,unsafe extern "C" fn()>(symbol(c"probe_stop")) };
    let matches = unsafe { std::mem::transmute::<*mut c_void,unsafe extern "C" fn()->usize>(symbol(c"probe_matches")) };
    let denied = unsafe { std::mem::transmute::<*mut c_void,unsafe extern "C" fn()->usize>(symbol(c"probe_denied")) };
    let site = unsafe { std::mem::transmute::<*mut c_void,unsafe extern "C" fn()->*const c_char>(symbol(c"probe_site")) };
    let context=zstd_safe::DCtx::try_create().ok_or("control context failed")?;
    let target=context.sizeof(); drop(context);
    let bytes=fixtures::valid_container();
    let control=Sample::from_bytes(&bytes)?; assert_eq!(control.test_id(),fixtures::TEST_ID);
    unsafe { arm(target) };
    let result=Sample::from_bytes(&bytes);
    unsafe { stop() };
    let count=unsafe{matches()}; let failures=unsafe{denied()};
    let name=unsafe{CStr::from_ptr(site())}.to_string_lossy();
    let err=result.expect_err("native context allocation should fail");
    assert_eq!(count,1); assert_eq!(failures,1); assert_eq!(name, "ZSTD_customMalloc");
    assert!(matches!(&err,SampleError::CodecAllocation{site:"Zstandard decoder context"}),"{err:?}");
    assert_eq!(tuiscotti::approve::sample_code(&err),"RESOURCE_LIMIT");
    let after=Sample::from_bytes(&bytes)?; assert_eq!(after.test_id(),fixtures::TEST_ID);
    println!("target_bytes={target} matched={count} denied={failures} caller={name} error={err:?} code={} source={} controls=pass",tuiscotti::approve::sample_code(&err),err.source().map_or("none".to_string(),|x|x.to_string()));
    Ok(())
}
