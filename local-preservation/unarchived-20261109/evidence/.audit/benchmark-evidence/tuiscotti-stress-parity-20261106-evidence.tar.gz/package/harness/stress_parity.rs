//! Emit a fixed rich Unicode sample and its separately rendered image.

use std::env;
use std::fs;
use std::path::Path;

use ratatui::buffer::Buffer;
use ratatui::layout::Rect;
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use sha2::{Digest, Sha256};
use tui_test::profile::Rgb;
use tui_test::terminal::cell::Attrs;
use tui_test::{SnapshotCursorShape, SnapshotMetadata, SnapshotSource};
use tuiscotti::render_profile::{PROFILE_NAME, resolve_profile};
use tuiscotti::sample::{Observation, Sample};
use tuiscotti::view::{ViewCursor, ViewSettings, snapshot_from_buffer};

fn hex(bytes: &[u8]) -> String {
    Sha256::digest(bytes).iter().map(|byte| format!("{byte:02x}")).collect()
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let out = env::args().nth(1).ok_or("output directory required")?;
    let out = Path::new(&out);
    fs::create_dir_all(out)?;

    let mut buffer = Buffer::empty(Rect::new(0, 0, 16, 3));
    buffer.set_line(0, 0, &Line::from(vec![
        Span::styled("e\u{301}", Style::default().fg(Color::Rgb(245, 245, 245)).bg(Color::Rgb(20, 30, 50)).underline_color(Color::Rgb(250, 80, 160)).add_modifier(Modifier::BOLD | Modifier::UNDERLINED)),
        Span::styled("界", Style::default().fg(Color::Indexed(196)).bg(Color::Indexed(17)).add_modifier(Modifier::ITALIC)),
        Span::styled("漢", Style::default().fg(Color::Rgb(255, 180, 20)).bg(Color::Rgb(30, 60, 90)).add_modifier(Modifier::DIM | Modifier::REVERSED)),
        Span::styled("★", Style::default().fg(Color::Indexed(220)).add_modifier(Modifier::BOLD)),
        Span::styled("", Style::default().fg(Color::Rgb(50, 220, 170)).add_modifier(Modifier::ITALIC)),
    ]), 16);
    buffer.set_line(0, 1, &Line::from(vec![
        Span::styled("Ω", Style::default().fg(Color::Indexed(45)).bg(Color::Rgb(10, 10, 40))),
        Span::styled("e\u{301}", Style::default().fg(Color::Indexed(201)).add_modifier(Modifier::UNDERLINED | Modifier::CROSSED_OUT)),
        Span::styled("界", Style::default().fg(Color::Rgb(240, 100, 30)).bg(Color::Indexed(24))),
        Span::styled("漢", Style::default().fg(Color::Indexed(82)).add_modifier(Modifier::BOLD | Modifier::ITALIC)),
        Span::styled("", Style::default().fg(Color::Indexed(214)).add_modifier(Modifier::SLOW_BLINK)),
    ]), 16);

    let settings = ViewSettings::builtin().with_cursor(ViewCursor::new(
        10, 2, true, SnapshotCursorShape::Bar, Rgb::new(18, 52, 86),
    ));
    let mut snapshot = snapshot_from_buffer(&buffer, &settings)?;
    let mut metadata = SnapshotMetadata::default();
    metadata.source = SnapshotSource::Offline;
    snapshot = tui_test::TerminalSnapshot::try_new(tui_test::SnapshotParts {
        cols: snapshot.cols(), rows: snapshot.rows(), scope: snapshot.scope(),
        viewport_origin: snapshot.viewport_origin(), cells: snapshot.cells().to_vec(),
        palette: *snapshot.palette(), default_foreground: snapshot.default_foreground(),
        default_background: snapshot.default_background(), default_cursor: snapshot.default_cursor(),
        cursor: snapshot.cursor().clone(), title: None, metadata,
    })?;

    for (index, cell) in snapshot.cells().iter().enumerate() {
        println!("cell={index};text={:?};width={};fg={:?};bg={:?};underline={:?};underline_color={:?};bold={};dim={};italic={};inverse={};strike={};blink={}",
            cell.text(), cell.width(), cell.fg(), cell.bg(), cell.underline(), cell.underline_color(),
            cell.has(Attrs::BOLD), cell.has(Attrs::DIM), cell.has(Attrs::ITALIC), cell.has(Attrs::INVERSE), cell.has(Attrs::STRIKE), cell.has(Attrs::BLINK));
    }
    let cursor = snapshot.cursor();
    println!("cursor=col:{},row:{},in_capture:{},visible:{},shape:{},rgb:{:?},blink:{:?}", cursor.col(), cursor.row(), cursor.in_capture(), cursor.visible(), cursor.shape().name(), cursor.color(), cursor.blink());

    let sample = Sample::state("parity/stress", snapshot, Observation::empty())?;
    let sample_bytes = sample.to_bytes()?;
    fs::write(out.join("sample.tui.pb"), &sample_bytes)?;
    let png_path = out.join("render.png");
    let _render = tuiscotti::render_sample(&sample_bytes, &png_path)?;
    let png = fs::read(&png_path)?;
    let decoded = image::load_from_memory_with_format(&png, image::ImageFormat::Png)?.to_rgba8();
    let (width, height) = decoded.dimensions();
    let rgba = decoded.into_raw();
    fs::write(out.join("render.rgba"), &rgba)?;

    let profile = resolve_profile(PROFILE_NAME)?;
    println!("target={}-{};sample_gate=state;test_id=parity/stress", env::consts::OS, env::consts::ARCH);
    println!("metadata=source:Offline,captured_at_ms:0,revision:0,backend:empty,session:empty");
    println!("profile={};raster_policy={};cell=10x20;font_size=16;baseline=15;scale=1", profile.name(), tuiscotti::render_profile::Profile::raster_policy());
    for face in profile.faces() { println!("font={}:len:{},sha256:{}", face.role(), face.byte_len(), face.bytes_sha256()); }
    println!("sample_bytes={};sha256:{}", sample_bytes.len(), hex(&sample_bytes));
    println!("png={width}x{height};bytes={};sha256:{}", png.len(), hex(&png));
    println!("rgba_bytes={};sha256:{}", rgba.len(), hex(&rgba));
    Ok(())
}
