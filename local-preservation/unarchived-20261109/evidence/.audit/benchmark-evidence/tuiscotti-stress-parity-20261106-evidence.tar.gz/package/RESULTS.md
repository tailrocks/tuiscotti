# Rich Unicode/font parity: macOS arm64 and Linux x86_64 emulation

Status: supplemental cross-target emulation result. The Linux process ran as x86_64 under Docker emulation on an Apple ARM64 host. It does not constitute native Linux evidence; native Linux x86_64 remains NOT VERIFIED.

## Source identity and isolation

- Source `/private/tmp/tuiscotti-goal-current-20261106`, manifest SHA-256 `2d1e3c0cdb34294c13573f18165158d0e55aa89f20fa822ee7eaa84cff454765`.
- Verified from the snapshot root with `cd /private/tmp/tuiscotti-goal-current-20261106 && shasum -a 256 -c SHA256SUMS`; all 684 entries passed.
- Fresh disposable copies at `mac-arm64/` and `linux-x86_64-emulated/` both independently passed all 684 source entries before the harness was added. No main workspace or downstream source was edited.
- Identical harness hash in both copies: `57302a644c872ed1c33d60737f6e28776d6f51887411834c843338e5c5ec8fe4`.

## Fixture and covered fields

`crates/tuiscotti/examples/stress_parity.rs` constructs the same `Buffer` (16 columns x 3 rows) on each target, with default blank cells and these two styled lines:

- Row 0: combining `e\u{301}` (width 1), `界` (width 2), `漢` (width 2), `★` (width 1), Nerd Font `U+F120` (width 1).
- Row 1: `Ω`, combining `e\u{301}`, `界`, `漢`, Nerd Font `U+F120`, each with distinct or reused styles.
- It covers RGB and indexed foreground/background, explicit underline color, bold, italic, dim, inverse, strike, underline, and slow blink. The buffer conversion produced 48 cells; the four wide glyphs yielded four continuation records total (one per wide glyph, with width 0 and empty text). A colored, visible bar cursor is at `(10, 2)`, in capture.
- Snapshot metadata is fixed: Offline, `captured_at_ms=0`, revision 0, empty backend/session, no title. Observation is empty. Sample gate is `state`, test ID `parity/stress`; therefore it has no platform-specific render-contract field.
- The separately rendered profile is `tuiscotti-pinned-v1` / `pinned-v1`, 10x20 px cell, font 16 px, baseline 15 px, scale 1.0. The state `.tui.pb` contains no PNG or render contract. Each run decodes its exact sample bytes via `render_sample`, writes PNG, then decodes RGBA.
- The profile reports 16 ordered style/fallback slots; these are configured entries, not 16 distinct fonts or proof that each slot was selected during rendering. Per-glyph face selection was not instrumented. The underlying bundled face files and their reported lengths/digests match on both targets: primary regular 2,573,248 bytes SHA-256 `f2a5ea6cfab397445ffab00c0370927b66d61e560a05db5db271b42006381c1a`; symbol regular 2,814,292 bytes `9b55ade625f2d3f2a273ed16d9db2d924ad6236222920f9fd1324941cdc3c712`; CJK regular 678,988 bytes `777bee41f0c6076c00ad919384359a6e396b8822cf9056041fca8fcf2759d897`; primary bold 2,577,016 bytes `bfcf9a917276ffc058867d87cbc8a5b2f1ab0f4b710e9170dc02763ccb80bd4b`; primary italic 2,575,368 bytes `31efd6ead98746f5b0afa1ee6dba60267ad48db36428360bee327bec10621f97`; primary bold-italic 2,578,280 bytes `9dba502e00e35209f6ed2a151c7376c051657b067cdebbc6e52d06cb9002cf31`. The same symbol/CJK files occupy their style fallback slots, in the same order. The fixture exercises the bold-plus-italic attribute combination on the CJK cell `漢`. It does not prove that the primary bold-italic font face was selected; per-glyph face selection was not instrumented.
- The vendored-profile renderer successfully rendered combining text, CJK wide characters, symbol and private-use icon glyphs. `界` and `漢` render successfully with the pinned profile, whose fallback list includes the vendored Noto CJK face; however, the renderer did not expose which face it selected for each glyph, so actual per-glyph fallback selection is not proven. A deliberate initial `🦀` stress attempt failed closed with `PinnedFont(MissingGlyph { character: '🦀', bold: false, italic: false })`; the final fixture uses renderable CJK fallback glyphs. No glyph replacement or output normalization is used in the final comparison.

## Tool provenance and commands

Native macOS: Darwin Apple Silicon arm64, mise 2026.11.1; MBX 1.29.2; Cargo 1.99.1; rustc 1.99.1 (`58cf8f9c35b355199727627d07ae34a4e2846d67`, LLVM 23.1.1). `mbx doctor` passed with 0 failures and 2 filesystem-atime warnings; active Cargo command was `/Users/donbeave/.local/share/mise/command-wrappers/bin/cargo`.

```sh
mise exec -- mbx --version
mise exec -- mbx doctor
mise exec -- sh -lc 'command -v cargo; cargo --version; rustc -vV | sed -n "1,6p"'
mise exec -- cargo run -p tuiscotti --example stress_parity --locked --offline -- /private/tmp/tuiscotti-stress-parity-20261106/mac-output
```

Linux: cached Docker image `rust:1.99.1`, image ID `sha256:4c4c8ec55be09785e6d6ac45ea9853525a73c15db74009100ac08952e773dfb8` (ARM64), invoked with `--platform linux/amd64`. Supplied mise 2026.11.1 linux-x64 binary SHA-256 `7129dbab31d698f9028db9374f7ba7987232b0426f837dcbce437130a61415f9`. Project locked MBX/Rust 1.29.2 / 1.99.1 installed via `mise install --locked`; `mbx doctor` had 0 failures and noted no fallback cargo shim. `mise exec -- sh -c 'command -v cargo'` returned `/tmp/mise-data/command-wrappers/bin/cargo`; Cargo build used `mise exec -- cargo`, no direct Cargo bypass.

```sh
docker run --rm --platform linux/amd64 \
  -v /private/tmp/tuiscotti-stress-parity-20261106/linux-x86_64-emulated:/repo \
  -v /private/tmp/tuiscotti-linux-mise-evidence/mise-v2026.11.1-linux-x64:/misebin/mise:ro \
  -v /Users/donbeave/.cargo:/cargo:ro \
  -v /private/tmp/tuiscotti-stress-parity-20261106/linux-output:/out \
  -e MISE_DATA_DIR=/tmp/mise-data -e MISE_CONFIG_DIR=/tmp/mise-config \
  -e MISE_CACHE_DIR=/tmp/mise-cache -e MISE_STATE_DIR=/tmp/mise-state \
  -e RUSTUP_HOME=/tmp/rustup -e CARGO_HOME=/tmp/cargo-home \
  -e CARGO_TARGET_DIR=/tmp/tuiscotti-target-linux rust:1.99.1 bash -lc \
  'set -eu; mkdir -p /tmp/cargo-home /out; ln -sfn /cargo/registry /tmp/cargo-home/registry; chmod -R u+w /repo; cd /repo; /misebin/mise install --locked; /misebin/mise exec -- mbx doctor; /misebin/mise exec -- sh -c "command -v cargo; cargo --version; rustc -vV | sed -n \"1,6p\""; /misebin/mise exec -- cargo run -p tuiscotti --example stress_parity --locked --offline -- /out'
```

## Artifact comparison

`cmp` passed on each pair directly (no normalization). These artifact comparisons are exact. The Linux process output was truncated in the tool transcript; `logs/linux-run-result.log` is an authored summary of captured target/profile output and verified artifact hashes, not a raw Linux stdout log. The exact raw Linux run log is unavailable. The full Linux command and tool provenance are retained here, along with the raw native macOS run log.



| Artifact | Size | SHA-256 |
|---|---:|---|
| state sample `.tui.pb` | 854 B | `052267ee31d5139db7021f30d346cd3377779bb181e2d78a28f7aef5ac6e6b4b` |
| separately rendered PNG | 3,970 B | `c25ecc95e02e648867afe8b0f7f82457a598bc7a76985500b9bc3ea56245632e` |
| decoded RGBA | 38,400 B | `ff38bee1542742ef1c18afd2a22f55de60cbbb3466105fa2c2191bf64321ab43` |

PNG is 160x60, 8-bit RGBA, non-interlaced. The exact sample bytes are identical, so both render operations receive identical input bytes. The only target-specific output metadata is external target identity (`macos-aarch64` versus `linux-x86_64`); the state sample has no platform key. Native Linux remains NOT VERIFIED.
