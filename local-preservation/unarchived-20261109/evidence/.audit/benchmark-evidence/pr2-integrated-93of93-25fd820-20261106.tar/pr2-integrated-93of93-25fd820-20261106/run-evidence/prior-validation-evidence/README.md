# TCB PR #2 isolated validation handoff

Validation was run in a disposable clone at `/private/tmp/tcb-pr2-validation-613dbf6-20261106`, HEAD `613dbf6759cfbcedf4992bc0356c98ebbed76643`, macOS arm64. The local Tuiscotti dependency was temporarily patched to the SHA-verified PR26 source snapshot `/private/tmp/tuiscotti-pr26-final-source-59704ed`; `SHA256SUMS` verified from that snapshot's cwd. The temporary patch and lockfile were restored before handoff.

The normal `FrozenStore::check` path was used with `TUISCOTTI_CAPTURE_ONLY` and `TUISCOTTI_CAPTURE_ROOT` unset. Fresh candidates were retained only under `run-evidence/` and disposable fixture roots. No baseline was accepted. The production baseline tree is byte-for-byte identical before/after: see `production-baselines-before.tsv` and `production-baselines-after.tsv` (1,978 files each).

## Partition results

- Holla: 9/11 pass; two State mismatches in its time label (`validation-holla/nextest.log`). The independently corrected `holla_second_gate_wrong_phrase_stays_then_reconfirm_executes` test passed in the partition.
- Showcase: 59/59 pass (`validation-showcase/nextest.log`).
- Tablepro: 11/11 pass (`validation-tablepro/nextest.log`).
- Jackin: original run 9/10; one test used Space to skip a splash that advertises Enter and only handles Enter/Esc (`validation-jackin/nextest.log`). The one-line correction is retained in this clone at `tests/functional/jackin.rs:357`; with a separately captured candidate fixture, that exact test passed with its normal assertions (`jackin-fresh-fixture-validation/nextest.log`).
- Lifecycle: the initial production-root run stopped 0/2 at Missing baselines (`validation-lifecycle/nextest.log`). I then captured those two IDs with strict checks against an empty external root and validated both exact tests 1/1 with bypass unset against a separate fixture copy (`lifecycle-capture/` and `lifecycle-candidate-validation/`).

## Fresh Jackin candidate

A strict check of the corrected producer emitted `jackin-candidate-capture/jackin-first-use-90363-1793928927786953000-0/check-artifacts/functional/jackin_first_use_empty/0a54895877aff08f93bb828f4d73fa12129abeb7db153889a9245336067b63fa/sample.tui.pb`. SHA256 is `0a54895877aff08f93bb828f4d73fa12129abeb7db153889a9245336067b63fa`; it is copied to the isolated fixture at `jackin-fresh-fixture/functional/jackin_first_use_empty.tui.pb`. The subsequent normal assertion run passed 1/1 with bypass unset. This remains an unapproved raw candidate, outside all active roots. Capture attempt log exit 100 is the expected `Missing` baseline failure; the emitted sample remains available for review.

The test correction changes only the skip input from `space` to `enter`, matching `src/bin/jackin/app.rs:423`, which handles Enter/Esc and consumes other keys. It preserves all state assertions. No active or frozen baseline was changed.

## Holla freshness investigation

The changing cell is the freshness label of the `Data` action on row 21, column 99. It comes from `catalog.rs:44–65`: `freshness(w, source)` calculates `age_ms = (w.tick - source.done_at) * TICK_MS`; `Freshness::label` in `domain/action.rs:141–150` formats seconds. The `World::tick` path advances this value under reduced motion, so crossing an integer-second boundary explains partition output 4 versus fixture 3. The full partition's intermediate checkpoint 003 was 3 and final sample was 4; one replay per test passed at 3. Archived evidence is under `holla-age-diagnosis/` with replay logs under `holla-first-use-replay/` and `holla-help-replay/`.

I checked the supported paused-clock control in a second disposable prototype at `/private/tmp/tcb-pr2-paused-prototype-613dbf6-20261106`. `World::tick` returns before incrementing `w.tick` or dispatching source completion when `clock.running` is false. `--motion paused` starts with that clock stopped, but app startup temporarily runs the requested `--frame` ticks before restoring it. In `first-use`, paused source completion ticks are 3, 6, 9, 12, 16, and 40, so `--motion paused --frame 40` reaches all completions before freezing the freshness age.

For each of the two visual tests I ran that paused prototype twice, preserving the existing reduced-mode raw fixtures. Every strict comparison reported exactly one changed cell at row 21, column 99 (`2` paused versus `3` reduced); all non-age cells matched. Test flow and semantic assertions before the visual check passed. The four runs' raw sample hashes differ because sample records include capture provenance (`captured_at_ms` and session); their compared terminal cells are stable. Logs and artifacts are archived under `holla-paused-prototype/logs/` and `artifacts/`.

I also captured one paused-mode candidate per test with strict checks against an empty disposable root, then ran each exact test twice against a separate paused-candidate fixture root with bypass unset. All four normal assertion runs passed. The candidates are `holla-paused-prototype/fixtures/functional/holla_first_use_idle.tui.pb` (SHA256 `c6de488bdaaaef073aaeefda7043f333c7c9fd5983a0ba66732aa9dec224c4cb`) and `holla-paused-prototype/fixtures/functional/holla_help.tui.pb` (SHA256 `e87c92923ae67a8fd797faa8732881692b234e5a20b240d90280a640024221b8`). The narrow source proposal is `holla-paused-prototype/paused-tests.patch`; it changes only the two static test launches to `--motion paused --frame 40` through a dedicated helper. These candidates are separate from the reduced-mode raw fixtures and remain unapproved. This setup is deterministic for the tested first-use paths and preserves their interaction assertions; adopting it would intentionally change the sample age from 3 to 2 seconds.

The tracked source hashes are `src/bin/holla/domain/catalog.rs` `90cbfacf51eedf5f72148e5ccd19cc566b4c8874f9833fb13938b8fd6188c475`, `src/bin/holla/domain/action.rs` `22668403b972c70f54d1935333ae030ae154565c3d1fff03d8ff1309eb3ab7c9`, `src/bin/holla/sim/world.rs` `50f9bec23d7a8a40c7b05905cdc9aa1c879620a6dd50173b404e9b524992e668`, and `src/clock.rs` `948acb4d4cdfe24210c9fd4dfd7e5861099df18f8c8a206ca946ee90a4f5fce7`. No production or approved baseline changes were made.

## Fresh lifecycle candidates

Two strict checks against an empty root emitted `functional/showcase_help_80x24` (SHA256 `f50239d398c9ec94594e459191367680977453dd02064c0753aef61be13c27f2`) and `functional/showcase_popover_resize` (SHA256 `9f29e0a316cce8300b64c01de062e858967b7b994d2c96568a9b48645e3245b8`). The raw candidates are isolated under `lifecycle-candidate-fixtures/functional/`; hashes are in `lifecycle-capture/candidates.sha256`. Both exact producer tests passed in normal comparison mode against these candidate fixtures with capture bypass unset. No active root was changed and these candidates remain unapproved.

## Remaining review

The earlier five unmatched IDs remain unresolved and are not treated as removals or approvals. This clone's focused lifecycle run independently showed two absent lifecycle IDs. Reviewer must retain the established five-ID dispositions and decide any candidate approvals separately. See original prep evidence outside this clone for the five-ID review ledger.
