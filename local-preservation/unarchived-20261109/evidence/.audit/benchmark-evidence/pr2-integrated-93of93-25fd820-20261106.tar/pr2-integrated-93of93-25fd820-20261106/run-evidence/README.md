# PR2 isolated binary-baseline validation

Validation clone: `/private/tmp/tcb-pr2-final-validation-25fd820-20261106`, detached at prep commit `25fd82089ba589d444cc75adfabc7adcae614646`. It includes the reviewed Enter-key correction and the two paused Holla test launches. No commit or push was made in this clone.

The temporary Cargo patch points the `tuiscotti` dependency to `/private/tmp/tuiscotti-pr26-final-source-59704ed/crates/tuiscotti`. From that source snapshot's own root, all 685 `SHA256SUMS` entries verified; the sum file SHA256 is `7fbd49d4f9920ecf52ecfd880449e649c665035c086ac53bc0105d71b0ed8840`. The verification log is `setup/pr26-sha256-check.log`. Pinned environment: macOS 27.2 arm64, mise 2026.11.1, mbx 1.29.1, Rust 1.99.1, nextest 0.9.148. `mbx doctor` reported 0 failures and two filesystem atime warnings.

A temporary `TUISCOTTI_BASELINE_ROOT` test-harness override directs checks to `run-evidence/unapproved-fixtures`; assertions and comparator logic remain unchanged. `TUISCOTTI_CAPTURE_ONLY` and `TUISCOTTI_CAPTURE_ROOT` were unset for all validation runs. No `accept` command was used. The production baseline tree was byte-identical before and after: 1,978 files; digests are in `production-baselines-before.tsv` and `production-baselines-after.tsv`.

## Composite fixture set

The fixture root has 104 unique `.tui.pb` IDs. The original 104 bytes are retained at `prior-104-raw-candidates/functional`; `composite-fixture-provenance.tsv` records the prior hash, selected source, and current hash for every ID. Five IDs already existed in the original set, so the reviewed samples replaced only their corresponding same-ID files:

- `functional/holla_first_use_idle` and `functional/holla_help`: the independently reviewed paused-mode captures.
- `functional/showcase_help_80x24` and `functional/showcase_popover_resize`: separately captured lifecycle samples.
- `functional/jackin_first_use_empty`: separately captured sample after the Enter-key correction.

All five old bytes remain in the prior-104 tree and their original candidate hashes remain in `prior-validation-evidence/fixture-candidates.tsv`. The final samples are unapproved fixtures isolated from the active baseline root.

`visual-id-coverage.tsv` reconciles the 104 fixture IDs to IDs observed in producer artifacts: 104/104 IDs covered, zero absent or unused; across repeated runs, all 120 recorded visual-check events passed.

The five older superseded IDs remain unresolved: `jackin_launch_failure`, `jackin_manager_stop_dialog`, `jackin_settings_leave`, `showcase_keyboard_activation`, and `tablepro_query_error_recovery`. Their original dispositions and required review actions are preserved in `prior-prep-evidence/five-unmatched-id-review.tsv`. This validation makes no deletion, rename, or approval decision for them.

## Producer runs

All producer partitions used bounded `timeout 230 mbx nextest` with `--locked --offline`, normal frozen checks, and the isolated fixture root. Exact per-test names and statuses are in `producer-test-results.tsv`; each full command and log are in its partition directory.

| Partition | Result | Evidence |
| --- | ---: | --- |
| Holla | 11/11 pass | `partition-holla/` |
| Showcase | 59/59 pass | `partition-showcase/` |
| Tablepro | 11/11 pass | `partition-tablepro/` |
| Jackin, after the narrow wrap fix | 10/10 pass | `partition-jackin-fixed/` |
| Lifecycle | 2/2 pass | `partition-lifecycle/` |

The initial full Jackin partition is preserved at `partition-jackin/`: 9/10 passed. `jackin_cockpit_launch_failure_acknowledges` failed because it asserted before the modal finished drawing the complete cause, and the terminal wrapped `network jackin-net not found` across two rows. The isolated rerun without source changes passed once. The local review patch `jackin-linewrap-fix.patch` waits until the complete whitespace-normalized phrase appears in the retry detail, preserving the exact words and all other checks. Whitespace normalization alone does not join the earlier wrapped text across modal border characters. That focused test passed 3/3 subsequent normal runs (`jackin-wrap-fix/repeats/`), then the entire Jackin partition passed 10/10. The initial failure artifacts remain under the new clone's `target/functional/`.

The final five partitions therefore passed 93/93 tests. No State or pixel mismatch occurred. The only observed difference across candidate generations was the already-reviewed Holla age cell: paused mode displays 2 seconds instead of the earlier reduced-mode 3 seconds; both paused captures are isolated same-ID replacements. Detailed earlier comparisons and captures are retained in `prior-validation-evidence/holla-paused-prototype/`.

## Local-only changes and provenance

The prep commit already contains the Enter-key and paused-Holla fixes. This validation clone additionally has a local-only whitespace-aware Jackin wait patch, the temporary baseline-root override, `.cargo/config.toml` pointing to the verified snapshot, and the regenerated `Cargo.lock`. `setup/Cargo.lock.original` is the prep commit lockfile. The source diffs are saved separately as `jackin-linewrap-fix.patch` and `baseline-root-override.patch`; no change was applied to `tests/functional/baselines`.

Hashes for the local test/support files and Holla freshness implementation are recorded in `source-sha256.tsv`. The PR26 snapshot's 685-file manifest provides exact per-file upstream source provenance. Nonvisual suites were outside this validation scope.

The saved command files are human-readable summaries, not executable environment receipts. The validation harness contains no capture bypass, and the actions logs record the visual checks as passes.
