# TCB PR #2 integrated 93/93 evidence

Separate local evidence archive. No candidate is approved or accepted, and no source or PR head was changed. The original final-validation `run-evidence/README.md`, relevant source-relative paths, fixture sets, logs/receipts, patches, provenance tables, and available raw candidate artifacts/reports are preserved here. `SHA256SUMS` covers every archive file except itself, including nested manifests.

## Source and status

Validation source was TCB prep commit `25fd82089ba589d444cc75adfabc7adcae614646`. The actual final prep commit is `2f85ff9` (reported by the coordinator); the local review patch `jackin-linewrap-fix.patch` remains separate and uncommitted. The verified Tuiscotti source is `/private/tmp/tuiscotti-pr26-final-source-59704ed`; its 685-entry `SHA256SUMS` is included at `tuiscotti-source/SHA256SUMS`, and setup verification log/receipt is preserved. No mutable old index was used.

The archive includes 104 unapproved composite fixture `.tui.pb` files and all 104 original prior candidate bytes. `composite-fixture-provenance.tsv` maps old and selected sources/hashes. There are five same-ID replacements (two Holla, two lifecycle, one Jackin). Available raw source capture containers and their HTML reports/results are preserved from prior validation evidence; where those raw capture records were not retained in the source evidence, only the recorded fixture bytes and hash mapping are present. No bulky `target/functional` terminal trace tree is included.

## Validation outcome and caveats

Final partitions passed 93/93 normal assertion tests: Holla 11/11, Showcase 59/59, Tablepro 11/11, fixed Jackin 10/10, Lifecycle 2/2. The initial Jackin partition was 9/10; a retry passed, then the focused wrap fix passed 3/3 repeats and the full fixed Jackin partition passed. The five earlier partition logs and receipts plus initial/retry evidence are included. All visual checks used isolated fixture roots, with capture bypass unset. Production baseline digest maps before and after are included; 1,978 files were unchanged.

Semantic timing caveat: paused Holla shows the freshness label as 2 seconds rather than the earlier reduced-mode 3 seconds. This is the only noted candidate-generation difference. The five superseded old IDs remain unresolved and require review; no removal, rename, or approval is inferred. Nonvisual suites were outside this validation scope.
