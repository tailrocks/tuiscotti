# Native macOS arm64 vs Linux x86-64 determinism route

Status: **NOT VERIFIED** for native Linux x86-64. This directory records a
native macOS arm64 run and provides the exact second-host procedure. The
current environment is Darwin arm64; it does not have a native Linux x86-64
host. Cross compilation, Rosetta, QEMU, containers, or other emulation do not
count as that evidence.

## What this exercises

`native_route.rs` is an integration-test harness against the actual public
`Sample::state`, `Sample::with_pixels`, and `Sample::to_bytes` APIs. It captures
one fixed Ratatui buffer, writes the real versioned compressed Protobuf
container for a state-gate sample, renders the same snapshot with the pinned
profile, and writes the pixel sample, PNG, decoded RGBA, and a small manifest.
The PNG and RGBA are extracted from the rendered sample, so these are the
bytes the pixel gate would actually carry.

Expected cross-host identities are:

| Artifact | Compare | Why |
| --- | --- | --- |
| `state.tui.pb` | Exact bytes | Same fixed state ID, snapshot, and observation; no platform field in the state-gate sample. This checks the actual Protobuf container and Zstandard output. |
| `pixels.png` | Exact bytes | Same fixed snapshot, pinned renderer/profile, and vendored font bytes. |
| `pixels.rgba` | Exact bytes | Decoded pixel identity used by `state-and-pixels` comparison. |
| `pixels.tui.pb` | Do not require equality | The required test ID and render contract encode the host. On macOS arm64 the ID ends `pixels-macos-aarch64`; on Linux x86-64 it must end `pixels-linux-x86_64`. The contract platform key also differs. |

The `state-and-pixels` gate requires its final test-ID component to pair with
the recorded render platform. Do not edit either ID to make the whole pixel
sample files look identical. Compare PNG and decoded RGBA separately.

## Reproduction

This is an uncommitted disposable snapshot and has no `.git` directory.
`git rev-parse HEAD` is not a valid identity check here. Use the same exact
workspace copy on both hosts, including `crates/tuiscotti-cli/tests/native_route.rs`
and this evidence directory. The checked `source-files.sha256` covers every
file in the source tree outside `.git`, `target`, and `.audit`. Its digest is
`source-manifest.sha256`; `run-native.sh` verifies every entry before recording
host/tool metadata and running the harness. Do not regenerate tool pins or
update dependencies during the comparison.

When applying the harness to a newer/final source tree, regenerate this
manifest from that tree before either host run:

```sh
mkdir -p .audit/native-route-evidence
find . -type f ! -path './.git/*' ! -path './.audit/*' ! -path './target/*' \
  -print | LC_ALL=C sort | while IFS= read -r source_file; do
    shasum -a 256 "$source_file"
  done > .audit/native-route-evidence/source-files.sha256
shasum -a 256 .audit/native-route-evidence/source-files.sha256 \
  > .audit/native-route-evidence/source-manifest.sha256
```

Transfer the whole disposable workspace to the other native host. From its
root, run `sh .audit/native-route-evidence/run-native.sh macos-arm64` on macOS
arm64 or `sh .audit/native-route-evidence/run-native.sh linux-x86_64` on Linux
x86-64. Ensure that host has the tool versions selected by this copy's
`mise.toml` and `mise.lock` installed before running the script. It does not
run `mise install` or edit the tool lock. The script rejects a mismatched host
tag, verifies the source manifest, and retains raw host, tool, `mbx doctor`,
and nextest logs alongside the outputs. `mbx doctor` must report the mise Cargo
wrapper active.

The raw host records should identify `Darwin arm64` and `Linux x86_64`.
`run-native.sh` passes an absolute output directory because `nextest` runs the
test binary with the CLI crate directory as its working directory.

Transfer only the second host's evidence directory to the first host, preserving
the `macos-arm64` and `linux-x86_64` names. Then compare from the repository
root:

```sh
diff -u .audit/native-route-evidence/macos-arm64/manifest.txt .audit/native-route-evidence/linux-x86_64/manifest.txt
cmp .audit/native-route-evidence/macos-arm64/state.tui.pb .audit/native-route-evidence/linux-x86_64/state.tui.pb
cmp .audit/native-route-evidence/macos-arm64/pixels.png .audit/native-route-evidence/linux-x86_64/pixels.png
cmp .audit/native-route-evidence/macos-arm64/pixels.rgba .audit/native-route-evidence/linux-x86_64/pixels.rgba
shasum -a 256 .audit/native-route-evidence/{macos-arm64,linux-x86_64}/*
```

`manifest.txt` contains intentionally host-specific fields, so a whole-file
`diff` is expected to report those lines. Check the invariant fields manually:
`state_id`, state size, PNG/RGBA sizes, PNG SHA-256, and RGBA SHA-256. Require
all three `cmp` commands to succeed. Verify that the Linux manifest reports
`pixel_id=native-parity/pixels-linux-x86_64` and
`contract_platform_key=linux-x86_64`.

If an invariant differs, preserve both host directories, compare checksums and
toolchain reports, then inspect decompressed container payloads before
attributing the mismatch. The raw state containers should first be byte equal;
this harness intentionally does not treat same decoded semantics as sufficient
for that persisted-state identity check.

## Current macOS arm64 evidence

Generated in this disposable copy on Darwin arm64 with mise 2026.11.1,
mr-boxington 1.29.2, Rust/Cargo 1.99.1. Command:

```sh
sh .audit/native-route-evidence/run-native.sh macos-arm64
```

Result: one focused nextest test passed. Raw host/tool/doctor/test logs and a
source-file manifest digest are retained beside the artifacts. The saved
artifact manifest reports
`pixel_id=native-parity/pixels-macos-aarch64`, platform key `macos-aarch64`,
state container 706 bytes, pixel sample 2514 bytes, PNG 962 bytes, and decoded
RGBA 28800 bytes. The recorded PNG digest is
`c06416f3b29c0980ea569c99c798128d77f413e603b1b988aa56c2d6b30fa978`; RGBA
digest is `a0b56f7da98636d0ad6ed64f045fd83f9acdec972754900046cb534a464e7d7c`.
These are macOS-side reference values only, not cross-platform proof.
The source manifest digest for this run is
`a56928f00a564842e26dd43604743183a5ca0813bb654583c80c661b9c4b6a40`. It binds
the supplied 2026-11-06 snapshot plus this harness, not a later integrated
codec revision. In particular, when validating the final source, regenerate
the manifest and rerun both native hosts; these existing macOS bytes cannot
be paired with Linux output from the final revision.

## Existing coverage and remaining gap

Existing `compressed_binary/full_roundtrip.rs` checks public serialization,
PNG bytes, and decoded RGBA round trips within one process. `compressed_oracle`
checks fixed semantic state digests and comparison behavior. Neither executes
the same renderer fixture on a native Linux x86-64 host. No `.audit` parity
artifact existed in the supplied snapshot. The Linux run and the actual
cross-host comparisons remain unverified until the procedure above is run on
native Linux x86-64.
