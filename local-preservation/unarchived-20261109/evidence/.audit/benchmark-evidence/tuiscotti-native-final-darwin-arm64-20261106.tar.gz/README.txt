Fresh final-source native Darwin arm64 determinism evidence

The source/ directory is the disposable workspace used for the run. Its root
SHA256SUMS verifies the supplied final snapshot; source/.audit/native-route-
evidence/source-files.sha256 and source-manifest.sha256 bind the exact source
plus the native_route integration harness. The host output is in
source/.audit/native-route-evidence/macos-arm64/.

Run command from source/ root:
  sh .audit/native-route-evidence/run-native.sh macos-arm64

For Linux comparison, transfer this whole bundle to native Linux x86_64, verify
source/SHA256SUMS and the source manifest there, then run the corresponding
linux-x86_64 tag. Do not use emulation. Exact expected shared outputs from this
Darwin run are recorded in macos-arm64/manifest.txt and its checksums.
