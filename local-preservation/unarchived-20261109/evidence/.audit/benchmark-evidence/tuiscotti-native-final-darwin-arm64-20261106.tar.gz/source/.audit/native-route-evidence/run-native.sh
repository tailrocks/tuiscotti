#!/bin/sh

set -eu

host_tag=${1:?usage: sh .audit/native-route-evidence/run-native.sh macos-arm64|linux-x86_64}
system=$(uname -s)
machine=$(uname -m)
case "$system:$machine" in
    Darwin:arm64) actual_tag=macos-arm64 ;;
    Linux:x86_64) actual_tag=linux-x86_64 ;;
    *) printf 'unsupported native host: %s %s\n' "$system" "$machine" >&2; exit 2 ;;
esac
if [ "$host_tag" != "$actual_tag" ]; then
    printf 'host tag %s does not match native host %s\n' "$host_tag" "$actual_tag" >&2
    exit 2
fi

repo_root=$(pwd -P)
evidence_root="$repo_root/.audit/native-route-evidence"
host_root="$evidence_root/$host_tag"
mkdir -p "$host_root"

shasum -a 256 -c "$evidence_root/source-manifest.sha256" > "$host_root/source-manifest-check.log"
shasum -a 256 -c "$evidence_root/source-files.sha256" >> "$host_root/source-manifest-check.log"

{
    uname -a
    uname -sm
    uname -m
    if [ "$system" = Darwin ]; then sw_vers; fi
} > "$host_root/host.txt"

{
    mise --version
    mise exec -- mbx --version
    mise exec -- rustc -vV
    mise exec -- cargo -V
    mise exec -- mbx nextest --version
} > "$host_root/tools.txt" 2>&1
mise exec -- mbx doctor > "$host_root/mbx-doctor.log" 2>&1

printf 'source_manifest_sha256=%s\nhost_tag=%s\n' \
    "$(awk '{print $1}' "$evidence_root/source-manifest.sha256")" "$host_tag" \
    > "$host_root/provenance.txt"
cat "$host_root/tools.txt" >> "$host_root/provenance.txt"

TUISCOTTI_NATIVE_ROUTE_OUT="$host_root" \
    mise exec -- mbx nextest run -p tuiscotti-cli --test native_route --locked --offline -- --nocapture \
    > "$host_root/nextest-run.log" 2>&1
cat "$host_root/nextest-run.log"
