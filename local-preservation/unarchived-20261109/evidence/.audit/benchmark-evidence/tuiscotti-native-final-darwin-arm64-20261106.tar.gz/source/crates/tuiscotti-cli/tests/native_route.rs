//! Native host parity fixture. Run on each native host with
//! `TUISCOTTI_NATIVE_ROUTE_OUT=.audit/native-route-evidence/<host>`.

use std::fs;
use std::path::PathBuf;

use base64::Engine as _;
use tuiscotti::sample::{Observation, Sample};

#[test]
fn emit_native_parity_artifacts() {
    let out = PathBuf::from(
        std::env::var_os("TUISCOTTI_NATIVE_ROUTE_OUT")
            .expect("set TUISCOTTI_NATIVE_ROUTE_OUT to an output directory"),
    );
    fs::create_dir_all(&out).expect("output directory creates");

    let state_snapshot =
        tuiscotti::view::capture_view(12, 3, &tuiscotti::view::ViewSettings::builtin(), |frame| {
            frame.buffer_mut()[(0, 0)].set_char('X');
            frame.buffer_mut()[(2, 1)].set_char('λ');
        })
        .expect("fixed state snapshot captures");
    let state = Sample::state(
        "native-parity/state-v1",
        state_snapshot.clone(),
        Observation::noted("fixed observation"),
    )
    .expect("state sample builds");
    let state_bytes = state.to_bytes().expect("state Protobuf container encodes");
    fs::write(out.join("state.tui.pb"), &state_bytes).expect("state sample writes");

    let pixel_id = format!(
        "native-parity/pixels-{}-{}",
        std::env::consts::OS,
        std::env::consts::ARCH
    );
    let profile =
        tuiscotti::render_profile::resolve_profile(tuiscotti::render_profile::PROFILE_NAME)
            .expect("pinned profile resolves");
    let pixels = Sample::with_pixels(
        &pixel_id,
        &state_snapshot,
        Observation::noted("fixed observation"),
        profile,
    )
    .expect("pixel sample renders");
    let pixel_bytes = pixels.to_bytes().expect("pixel Protobuf container encodes");
    fs::write(out.join("pixels.tui.pb"), &pixel_bytes).expect("pixel sample writes");

    let image = pixels.image().expect("pixel sample includes image");
    let png = base64::engine::general_purpose::STANDARD
        .decode(image.png_base64())
        .expect("embedded PNG decodes from base64");
    let rgba = image::load_from_memory_with_format(&png, image::ImageFormat::Png)
        .expect("PNG decodes")
        .to_rgba8()
        .into_raw();
    fs::write(out.join("pixels.png"), &png).expect("PNG writes");
    fs::write(out.join("pixels.rgba"), &rgba).expect("RGBA writes");

    let contract = pixels.render_contract().expect("render contract exists");
    let manifest = format!(
        "os={}\narch={}\nstate_id={}\npixel_id={}\ncontract_platform_key={}\nstate_bytes={}\npixel_sample_bytes={}\npng_bytes={}\nrgba_bytes={}\npng_sha256={}\nrgba_sha256={}\n",
        std::env::consts::OS,
        std::env::consts::ARCH,
        state.test_id(),
        pixels.test_id(),
        contract.platform_key(),
        state_bytes.len(),
        pixel_bytes.len(),
        png.len(),
        rgba.len(),
        image.png_sha256(),
        image.rgba_sha256(),
    );
    fs::write(out.join("manifest.txt"), manifest).expect("manifest writes");
}
