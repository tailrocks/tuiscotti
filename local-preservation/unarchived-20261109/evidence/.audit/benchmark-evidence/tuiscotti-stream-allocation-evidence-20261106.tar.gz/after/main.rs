use std::error::Error;
use std::ffi::{c_char,c_void,CStr};
use tuiscotti::sample::{Sample,SampleError};
#[allow(dead_code)] mod fixtures;
unsafe extern "C" { fn dlsym(handle:*mut c_void, name:*const c_char)->*mut c_void; }
unsafe fn symbol(name:&CStr)->*mut c_void { let ptr = unsafe { dlsym((-2_isize) as *mut c_void,name.as_ptr()) }; assert!(!ptr.is_null()); ptr }
fn main()->Result<(),Box<dyn Error>> {
 let arm=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn(usize)>(symbol(c"probe_arm"))};
 let stop=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn()>(symbol(c"probe_stop"))};
 let count=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn()->usize>(symbol(c"probe_count"))};
 let size=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn(usize)->usize>(symbol(c"probe_size"))};
 let site=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn(usize)->*const c_char>(symbol(c"probe_site"))};
 let denied=unsafe{std::mem::transmute::<*mut c_void,unsafe extern "C" fn()->usize>(symbol(c"probe_denied"))};
 let bytes=fixtures::valid_container(); let control=Sample::from_bytes(&bytes)?; assert_eq!(control.test_id(),fixtures::TEST_ID);
 unsafe{arm(205108)}; let result=Sample::from_bytes(&bytes); unsafe{stop()};
 let n=unsafe{count()}; let indices:Vec<_>=(0..n.min(1024)).filter(|&i|unsafe{size(i)}==205108).collect(); assert_eq!(indices.len(),1); assert_eq!(unsafe{denied()},1); let caller=unsafe{CStr::from_ptr(site(indices[0]))}.to_string_lossy(); assert_eq!(caller,"ZSTD_customMalloc");
 let err=result.expect_err("workspace failure must return error"); let code=tuiscotti::approve::sample_code(&err); let after=Sample::from_bytes(&bytes)?; assert_eq!(after.test_id(),fixtures::TEST_ID);
 println!("expanded={} compressed={} target=205108 matched={} denied={} caller={} error={err:?} code={code} source={:?} controls=pass",fixtures::valid_message().len(),bytes.len(),indices.len(),unsafe{denied()},caller,err.source().map(ToString::to_string));
 assert!(matches!(&err,SampleError::ZstdResourceLimit{..}),"expected typed allocation/resource error, got {err:?}"); assert_eq!(code,"RESOURCE_LIMIT"); Ok(())
}
