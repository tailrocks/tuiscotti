#!/bin/sh
set -eu
cd "$(dirname "$0")"
for i in 1 2 3 4 5; do
  status=0
  env DYLD_INSERT_LIBRARIES="$PWD/hook.dylib" "$PWD/before/probe" >"logs/replay-old-$i.stdout" 2>"logs/replay-old-$i.stderr" || status=$?
  test "$status" = 101
  env DYLD_INSERT_LIBRARIES="$PWD/hook.dylib" "$PWD/after/probe" >"logs/replay-fixed-$i.stdout" 2>"logs/replay-fixed-$i.stderr"
done
