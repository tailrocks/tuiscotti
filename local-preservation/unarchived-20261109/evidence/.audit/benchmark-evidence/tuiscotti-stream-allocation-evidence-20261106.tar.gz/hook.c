#include <stdlib.h>
#include <stddef.h>
#include <stdatomic.h>
#include <dlfcn.h>
static _Atomic int armed; static size_t sizes[1024]; static void *sites[1024]; static _Atomic size_t count, target, denied;
void probe_arm(size_t n) { atomic_store(&count,0); atomic_store(&denied,0); atomic_store(&target,n); atomic_store(&armed,1); }
void probe_stop(void) { atomic_store(&armed,0); }
size_t probe_count(void) { return atomic_load(&count); }
size_t probe_size(size_t i) { return sizes[i]; }
size_t probe_denied(void) { return atomic_load(&denied); }
const char *probe_site(size_t i) { Dl_info info; return i<1024 && dladdr(sites[i],&info) && info.dli_sname ? info.dli_sname : "unknown"; }
static void *probe_malloc(size_t n) { if (atomic_load(&armed)) { size_t i=atomic_fetch_add(&count,1); if(i<1024) { sizes[i]=n; sites[i]=__builtin_return_address(0); } if(n==atomic_load(&target) && n!=0 && atomic_fetch_add(&denied,1)==0) return NULL; } return malloc(n); }
__attribute__((used)) static struct { const void *replacement; const void *replacee; } interpose __attribute__((section("__DATA,__interpose"))) = { (const void *)probe_malloc, (const void *)malloc };
