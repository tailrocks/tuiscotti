# Native arm64 container and wire mutation evidence

This is a bounded deterministic mutation run against the reviewed snapshot in
`/private/tmp/tuiscotti-arm64-final-review`, copied to
`/private/tmp/tuiscotti-arm64-fuzz-disposable-20261106`. The copy was made with
`ditto`; test-only code was added to that copy. The working checkout and the
review snapshot were not edited.

## Input identity and environment

- Review tree integrity: `shasum -a 256 -c SHA256SUMS` passed for every listed file.
- SHA-256 of the verified `SHA256SUMS` manifest: `471e8b11f1ef7f4fd846f67517d47d9a8d68ad00a9b9d0e0ea04136601c0e9e2`.
- Host: macOS 27.2, `aarch64-apple-darwin`, arm64 hardware (native, no emulation).
- Rust: `rustc 1.99.1 (58cf8f9c3 2026-10-13)`.
- Cargo commands ran through `mise exec -- mbx exec cargo ...`, with `--locked --offline`.
- The harness source is archived from `crates/tuiscotti/src/sample/wire/write/tests/canonical.rs` and `crates/tuiscotti/src/sample/container/boundary_probe.rs`.

## Bounded mutation harness

`arm64_audit_bounded_public_sample_mutation_fuzz` invokes the public
`Sample::from_bytes` for each generated container. It builds a valid compressed
state sample fixture with `Sample::to_bytes` and a valid protobuf fixture, then
runs exactly 2,400 deterministic cases using xorshift64 state initialized to
`0x6a09_e667_f3bc_c909`: 800 container-header mutations, 800 Zstandard payload
mutations/truncations, and 800 protobuf mutations re-framed in a valid
Zstandard container. Each input is capped at 1 MiB, the loop count is fixed,
and `catch_unwind` fails the test on any parser panic.

The harness asserts rejection for every fixed-header truncation, a one-byte
payload truncation, changed magic/container/codec/schema bytes, and a valid
container holding an empty protobuf message. Other mutations may legally remain
valid or fail; their outcome is recorded only as completion, avoiding false
claims that arbitrary mutations must be invalid.

## Zstandard differential scope

The focused test calls the private `frame_header` parser and upstream
`zstd_safe::get_frame_content_size` on the same valid frame and on malformed
inputs within their overlapping behavior: a full header with content size,
truncations shorter than six bytes, invalid magic, and the reserved descriptor
bit. Both parsers agree on acceptance/rejection there and the valid advertised
size agrees.

The overlap is intentionally narrow. The upstream content-size helper can
accept a six-byte prefix once its requested field is available; the private
validator rejects that prefix because it requires the full local-policy header.
The private parser also separately enforces required checksums, no dictionary,
window limits, and exact expanded length. Those semantics are not asserted to
match this upstream helper.

## Result and limits

Both focused tests passed on native arm64. The mutation test completed 2,400
cases in 0.31 s test time (0.71 s process wall time), with 77,135,872 bytes
maximum resident set size reported by `/usr/bin/time -l`. This includes the
already-built Rust test binary and process overhead; it is not a per-input
allocation measurement. No panic or over-1-MiB test input occurred.

This is deterministic bounded mutation evidence, not coverage-guided fuzzing,
exhaustive format verification, or a proof of all resource limits. Mutations
are shallow single-bit changes/truncations around one small valid fixture; the
run does not establish behavior for 64 MiB inputs or every valid protobuf and
Zstandard encoding. Full command output is in `run.log`; commands are in
`run-arm64-audit.sh`.

## Hashes

- `SHA256SUMS`: `471e8b11f1ef7f4fd846f67517d47d9a8d68ad00a9b9d0e0ea04136601c0e9e2`
- Fuzz-test source file after test-only addition: `26309bc0f8b5220af84760848eac200699ba82738544403d32070c8be6748abb`
- Differential-test source file after test-only addition: `a25f02d6acb5fe9e0103af653e1fc89a0c7fde7ea7a2be535dcb565c890ec42d`
