#!/bin/sh
set -eu
printf '%s\n' '=== bounded public mutation harness ==='
/usr/bin/time -l mise exec -- mbx exec cargo test -p tuiscotti --locked --offline arm64_audit_bounded_public_sample_mutation_fuzz -- --nocapture
printf '%s\n' '=== focused upstream Zstd header differential ==='
/usr/bin/time -l mise exec -- mbx exec cargo test -p tuiscotti --locked --offline private_frame_header_parser_matches_upstream_on_shared_validation_overlap -- --nocapture
