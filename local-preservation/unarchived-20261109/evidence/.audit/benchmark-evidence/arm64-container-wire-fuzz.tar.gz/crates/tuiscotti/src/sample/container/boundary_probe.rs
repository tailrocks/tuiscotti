use super::*;
use std::error::Error;

#[test]
fn real_container_decode_rejects_precharged_message_and_codec_boundaries()
-> Result<(), Box<dyn Error>> {
    let message = b"allocation boundary probe";
    let input = encode_container(message, 3).map_err(|e| format!("{e:?}"))?;
    let n = message.len() as u64;
    for (name, available) in [
        ("message", 33 * n - 1),
        ("codec", 33 * n + CODEC_ENVELOPE - 1),
    ] {
        let mut budget = DecodeBudget::new().map_err(|e| format!("{e:?}"))?;
        let filler = budget.limit() - budget.total() - available;
        let _held = budget
            .charge("injected pressure", filler)
            .map_err(|e| format!("{e:?}"))?;
        let Err(error) = decode_container(&input, &mut budget) else {
            return Err(format!("{name} unexpectedly succeeded").into());
        };
        let error: super::super::SampleError = error.into();
        assert!(matches!(
            error,
            super::super::SampleError::ResourceLimit {
                claimed: Some(_),
                ..
            }
        ));
        assert_eq!(crate::approve::sample_code(&error), "RESOURCE_LIMIT");
        eprintln!(
            "{name}: available={available}, input={}, message={n}, codec_envelope={CODEC_ENVELOPE}, error={error:?}",
            input.len()
        );
    }
    Ok(())
}

#[test]
fn zstd_allocation_error_is_a_resource_failure_and_keeps_its_source() {
    let code =
        (zstd_safe::zstd_sys::ZSTD_ErrorCode::ZSTD_error_memory_allocation as usize).wrapping_neg();
    let error: super::super::SampleError = codec_error(code).into();
    assert!(matches!(
        error,
        super::super::SampleError::ZstdResourceLimit { .. }
    ));
    assert_eq!(crate::approve::sample_code(&error), "RESOURCE_LIMIT");
    assert_eq!(
        error.source().map(ToString::to_string),
        Some(zstd_safe::get_error_name(code).to_owned())
    );

    let invalid = (zstd_safe::zstd_sys::ZSTD_ErrorCode::ZSTD_error_corruption_detected as usize)
        .wrapping_neg();
    let error: super::super::SampleError = codec_error(invalid).into();
    assert!(matches!(
        error,
        super::super::SampleError::BinaryFormat { .. }
    ));
    assert_eq!(crate::approve::sample_code(&error), "INVALID_SAMPLE");
    assert!(error.source().and_then(Error::source).is_some());
}

#[test]
fn private_frame_header_parser_matches_upstream_on_shared_validation_overlap() {
    let message = b"focused zstd header differential";
    let container = encode_container(message, 3).expect("frame encodes");
    let payload = &container[HEADER_LEN..];

    // Shared overlap: standard magic, a complete frame header, and a present
    // content-size field. Private policy additionally requires checksums,
    // forbids dictionaries, caps windows, and requires exact expanded length;
    // those are intentionally outside this upstream content-size API's scope.
    assert!(frame_header(payload, message.len() as u64).is_ok());
    assert_eq!(
        zstd_safe::get_frame_content_size(payload).expect("upstream parses content size"),
        Some(message.len() as u64)
    );

    // The upstream content-size helper can accept a short prefix once that
    // field is available, while the private validator requires all local
    // frame policy fields. Compare truncations only below their shared
    // minimum magic/descriptor prefix.
    for end in 0..6 {
        let truncated = &payload[..end];
        assert!(frame_header(truncated, message.len() as u64).is_err(), "private accepts prefix {end}");
        assert!(zstd_safe::get_frame_content_size(truncated).is_err(), "upstream accepts prefix {end}");
    }

    let mut bad_magic = payload.to_vec();
    bad_magic[0] ^= 1;
    assert!(frame_header(&bad_magic, message.len() as u64).is_err());
    assert!(zstd_safe::get_frame_content_size(&bad_magic).is_err());

    let mut reserved = payload.to_vec();
    reserved[4] |= 0x08;
    assert!(frame_header(&reserved, message.len() as u64).is_err());
    assert!(zstd_safe::get_frame_content_size(&reserved).is_err());
}
