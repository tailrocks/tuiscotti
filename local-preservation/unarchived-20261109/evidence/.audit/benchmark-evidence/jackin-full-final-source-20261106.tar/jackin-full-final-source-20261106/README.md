# Jackin full identity evidence: final Tuiscotti source

Separate preservation bundle; it does not replace the earlier Jackin capture bundle and does not approve/promote any candidate. All 55 raw `.tui.pb` candidates remain unapproved. Directory paths preserve their source-relative structure. `SHA256SUMS` covers all files here except itself.

## Provenance

- Jackin PR #1264 live head: `845d128da0b839befab4dc69f24c0e748fc25069`; tested preparatory source: `817daf1a7af1f1f84413ed79cd660e00744f2e9d`. The exact preparation patch is archived under `jackin/` with the source handoff.
- TCB pin: `a901c275055091810ae0d0ac30ec5fc09ce595d9`. Captures ran from its disposable checkout.
- Tuiscotti source: `/private/tmp/tuiscotti-pr26-final-source-59704ed`; its 685-entry `SHA256SUMS` and verification output are preserved under `tuiscotti-source/`. The manifest digest recorded in the handoff is `7fbd49d4f9920ecf52ecfd880449e649c665035c086ac53bc0105d71b0ed8840`.

## Candidate evidence and verification

`jackin/` contains handoff, candidate mapping TSV, complete capture/partition logs and exit receipts, test names/list log, and preparatory patch. `tcb/run-evidence/` contains 55 original raw candidate containers, each existing HTML report and its local raw sample asset, the producer Nextest log and candidate mapping, plus TCB capture support patch. The 55 disposable validation fixtures are retained separately under `tcb/apps/jackin/tests/functional/baselines/functional/`; no app source or build output is included. Candidate TSV hashes were checked against all 55 raw artifacts and all 55 fixture files.

All four disjoint identity partitions passed: 8 + 20 + 8 + 11 = 47 unique tests; each recorded exit receipt is 0. The earlier monolithic run hit its 230-second cap after 35 passes and is not the full-suite result. Producer capture Nextest says 52/52 passed, but its wrapper exit receipt is missing because its post-run Zsh assignment used reserved `$status`; the Nextest log is preserved and the limitation remains.

Relative asset links in all included report pages were checked after fresh archive extraction. No candidate has visual approval; downstream review and any later approval process remain outstanding.
