# Jackin binary-baseline identity validation

All work is isolated under `/private/tmp`; no PR, user branch, published pin, active baseline, or approval workflow was changed.

## Exact source revisions

- Live Jackin PR #1264 was rechecked at `845d128da0b839befab4dc69f24c0e748fc25069`.
- Validation used a new detached Jackin copy at preparatory commit `817daf1a7af1f1f84413ed79cd660e00744f2e9d`: `/private/tmp/jackin-pr1264-full-validation-817daf1-20261106`.
- The TCB validation checkout is detached at Jackin's exact source pin `a901c275055091810ae0d0ac30ec5fc09ce595d9`: `/private/tmp/tcb-jackin-full-validation-a901c275-20261106`.
- Tuiscotti source is the immutable local snapshot `/private/tmp/tuiscotti-pr26-final-source-59704ed`. Its manifest was verified from that directory: all 685 entries pass. `SHA256SUMS` SHA-256 is `7fbd49d4f9920ecf52ecfd880449e649c665035c086ac53bc0105d71b0ed8840`; verification output is outside the source at `/private/tmp/jackin-pr1264-full-validation-817daf1-20261106/pr26-source-checksums.verify.log` (SHA-256 `d863e15d0c16e77aaaff43a4718bb6b88c81d45f581264c5ba0ac8d4a38c4927`).

## Fresh captures and fixtures

The TCB pinned functional suite ran on native macOS arm64 with Rust 1.99.1, MBX 1.29.2, and Nextest 0.9.151. It produced 55 candidate artifacts from live `Sample::to_bytes()` captures. The pinned JSON inventory and Jackin identity sources each contain the same 55 IDs. Candidate hashes and byte lengths are in `jackin-identity-candidates.tsv` (SHA-256 `153c4e2d435dd1bddd61b453dee7b0fcef3122c6120eb66c2c3c56086c38a9ba`). All 55 hashes are unique. Source JSON digest maps before/after staging are identical (both SHA-256 `dc6806c880a98fe6254e99df8f87a22ad29c754b533dcbf06fa37699c6256115`).

The 55 `.tui.pb` files were copied only into the disposable TCB validation checkout for consumer tests. The pinned `.tui.json` files remain present and unchanged. These are unapproved test fixtures; no `accept` command ran. The TCB capture log ends `52 tests run: 52 passed, 0 skipped`; it is at `.../run-evidence/jackin-identity-final-source-20261106/nextest.log` (SHA-256 `f4c19e43b23fe40249d02565faf2537213f1e075058bccde968432903f8a8cb1`). Its wrapper lacked an exit receipt because a post-run assignment used Zsh's reserved `$status`; the preserved Nextest result has no failed tests.

## Full Jackin identity result

The first monolithic identity run hit the 230-second command cap after 35 tests passed; one test was SIGTERM-interrupted and 11 did not run (exit 124). To finish within bounded commands, the complete 47-test identity target was rerun with capture-only variables explicitly unset in four disjoint partitions:

| Partition | Tests | Result | Log |
|---|---:|---:|---|
| capsule + coverage | 8 | 8 passed | `partitions/capsule-coverage.log` |
| fixed | 20 | 20 passed | `partitions/fixed.log` |
| manager, account through first-use | 8 | 8 passed | `partitions/manager-early.log` |
| remaining manager | 11 | 11 passed | `partitions/manager-rest.log` |

Each exit receipt is `0`. This covers all 47 names listed in `identity-test-names.txt`. The expected panic in the color mutation test is reported as PASS. Logs and receipts live in `/private/tmp/jackin-pr1264-full-validation-817daf1-20261106/run-evidence/jackin-identity-full-final-source-20261106/partitions/`.

## Changes and limits

The tested source change is exactly preparatory commit `817daf1a7`; its patch is `jackin-preparation.patch`. Temporary `.cargo/config.toml` path patches and Cargo.lock updates exist only in the disposable validation copies. TCB's capture-only support patch is preserved separately in the TCB evidence directory. Do not promote staged files or change durable pins before review and the merged source SHA.
