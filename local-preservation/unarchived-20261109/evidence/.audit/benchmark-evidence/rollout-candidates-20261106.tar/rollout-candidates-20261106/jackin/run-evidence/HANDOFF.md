# Jackin PR #1264 binary-baseline rehearsal

Date: 2026-11-06. All edits and generated candidates are in disposable copies; nothing was committed, pushed, accepted, approved, or published.

## Live heads and pins

- Jackin PR #1264 was freshly rechecked OPEN/BLOCKED at `845d128da0b839befab4dc69f24c0e748fc25069` (`feature/openshell-native`). Consumer checkout: `/private/tmp/jackin-pr1264-migration-845d128-20261106`.
- The Jackin Cargo manifest pins TCB `a901c275055091810ae0d0ac30ec5fc09ce595d9` and Tuiscotti `d8d54155947f6303a41dfd6079b53c0abc16f29a`.
- Selected TCB source checkout: `/private/tmp/tcb-jackin-pin-a901c275-20261106`, detached at the exact TCB pin. Its `apps/jackin/tests/functional/baselines/functional` directory contains 55 `.tui.json` files and no `.tui.pb` files.

## Inventory and capture evidence

The fresh Jackin head's identity source names 55 distinct visual IDs. The exact TCB pin's Jackin functional tests name the same 55 IDs; comparing source IDs with the selected TCB JSON filenames produced no missing or extra IDs.

The TCB functional test target ran on native macOS arm64 with the pinned Rust 1.99.1, Nextest 0.9.151, and MBX 1.29.2. The Nextest log ends `52 tests run: 52 passed, 0 skipped`. The run generated one Tuiscotti `artifacts/.../sample.tui.pb` for each expected ID. Every artifact candidate digest matched the raw bytes from that same live `Sample::to_bytes()` capture. The 55-row digest and byte-count map is `jackin-identity-candidates.tsv` (SHA-256 `d8e903ac46f9ce00efa1ba1ea16a2c2b54d2744cc5da9a3f253ddfe4b7a7d388`); the complete Nextest log SHA-256 is `59c82e15a921e1fdfb1e783c6ed2bef3bff626225aaa678fb8a772f84ddf0bca`.

The candidates were copied without modification into a second detached TCB checkout at the same SHA, `/private/tmp/tcb-jackin-consumer-stage-a901c275-20261106`, solely as a consumer-test baseline. All 55 source `.tui.json` files remain there unchanged. No staged `.tui.pb` has approval status.

## Consumer patch and verification

The Jackin checkout changes only `crates/jackin-testkit/tests/identity/coverage.rs` as source code: the approved-file inventory scans `.tui.pb`; the unchanged-copy fixture reads and writes binary bytes; the former raw JSON text edit now decodes a `Sample`, changes the first cell foreground via public snapshot types, and re-encodes with `Sample::to_bytes()`. The expected one-cell `fg` mismatch assertion remains. Patch SHA-256: `a118449ad7b56aa118b5c360501fb1374fffb78899993fdbd705bec294e9cdfe`; source file SHA-256: `d09fa875e2a8b7bbcc127c3a27b060302c5445dbe67717abd88ae29db886edf1`.

A temporary `.cargo/config.toml` in the Jackin clone patches TCB and Tuiscotti to the local rehearsal copies; Cargo.lock consequently changes only in that clone. The TCB capture clone has temporary capture-only support changes and its own local Tuiscotti path patch. None of these config or lockfile changes belong in the downstream patch.

This focused identity coverage run passed 5/5 tests using the staged candidates:

```sh
MISE_CI=1 mise exec -- mbx nextest run --offline -p jackin-testkit --test identity \
  -E 'test(/coverage::/)' --no-capture
```

It covered the journey-to-ID relation, the approved-file inventory, no-file scenarios, unchanged-copy comparison, and the one-cell binary color mutation. The mutation produced exactly one changed cell at `(0,0)` with field `fg`. `cargo fmt --all -- --check` and `git diff --check` passed on the Jackin clone.

## Limits

The full identity integration target was not run. The 55 captures have not been visually reviewed or explicitly approved, and the production TCB pin still contains JSON. The rehearsal proves a complete fresh capture set can be produced from the exact selected TCB revision and consumed by the changed identity inventory/mutation tests; it does not complete the downstream rollout. Do not promote these candidates or alter the durable TCB/Tuiscotti pins until the required review and merged implementation SHA are available.
