# Downstream candidate evidence archive (2026-11-06)

This is a preservation copy for human review. It does not approve, accept, rename, or promote samples. `SHA256SUMS` covers every file in this archive except itself. Paths below each labeled tree preserve paths relative to the originating `run-evidence` directory.

## Candidate sets

| Set | Candidate files | Scope and provenance | Review status |
|---|---:|---|---|
| `main/run-evidence` | 103 | TCB main `7f385611fba0f8d4a77bb02e0a991ad660b48746`; exact Tuiscotti source `818b2ebfd94cfea669a6603b79cb96532db9b282`. 101 active IDs: 100 `CAPTURED` inventory candidates plus two raw variants for the one `AMBIGUOUS` ID; one separate out-of-scope `showcase/buttons/held` candidate makes 103 candidate containers. | Unreviewed; the two variants are ambiguous despite identical render/state except `captured_at_ms`. The `showcase/buttons/held` candidate is unexpected/out-of-scope and pending human review. PNGs and projection evidence included. |
| `pr2/run-evidence` | 104 | TCB PR #2 rehearsal at `60b5fb2762d91a3549bd4ac63b1d77d534ee53d2`; Tuiscotti source is the reviewed snapshot with SHA256SUMS digest `471e8b11f1ef7f4fd846f67517d47d9a8d68ad00a9b9d0e0ea04136601c0e9e2`. | Unreviewed. Inventory has 104 captured, 5 missing, no ambiguous or unexpected. Five unmatched old IDs/replacement mappings remain `REVIEW_REQUIRED`; see TSV. |
| `jackin/run-evidence` | 55 | Jackin PR #1264 consumer head `845d128da0b839befab4dc69f24c0e748fc25069`; TCB pin `a901c275055091810ae0d0ac30ec5fc09ce595d9`; old Tuiscotti pin `d8d54155947f6303a41dfd6079b53c0abc16f29a`. | Unreviewed, unapproved. Distinct TCB pin; do not conflate with PR #2 or main. |

The older TCB main rehearsal at `/private/tmp/tcb-main-rollout-20261106` used a different Tuiscotti source snapshot (`d31900993b533ad4758848c261b5f4c5b2eb1cee`), so its candidates are intentionally excluded from this archive and cannot substantiate exact-source results. The older PR #2 missing IDs and Jackin sets are kept distinct by separate source trees and metadata. No baseline JSON files, unrelated trace dumps, generated application files, or credential files are included.

## Verification

Files were copied byte-for-byte from the listed source trees. `SHA256SUMS` gives archive-relative SHA-256 hashes. Candidate count verification: main 103 (100 captured + 2 ambiguous variants + 1 extra/out-of-scope candidate), PR #2 104, Jackin 55. The primary candidate inventory counts only its designated directories (`main/run-evidence/candidates-reconciled/functional` plus the two raw ambiguity variants and the extra candidate; PR2 `active-candidates-reconciled-v2/functional`; Jackin `artifacts/functional`). Reports also link to raw `sample.tui.pb` assets; these are retained at their original source paths for local report review and are not additional inventory rows. All are raw `.tui.pb` bytes.

All local files referenced by included HTML reports were copied with their source-relative paths. Fresh-extraction verification found zero unresolved local report links.
