# TCB PR #2 binary-baseline rehearsal

This directory contains local-only rehearsal evidence from a fresh disposable
checkout. It does not include baseline approvals.

## Inputs

- Repository: `https://github.com/tailrocks/terminal-components-baseline.git`
- Detached HEAD: `60b5fb2762d91a3549bd4ac63b1d77d534ee53d2` (TCB PR #2, rechecked 2026-11-06; open, dirty)
- TCB main at recheck: `7f385611fba0f8d4a77bb02e0a991ad660b48746`
- Host: `Darwin arm64`
- Tuiscotti source: immutable reviewed snapshot `/private/tmp/tuiscotti-rollout-reviewed-20261106`
- Snapshot `SHA256SUMS` digest: `471e8b11f1ef7f4fd846f67517d47d9a8d68ad00a9b9d0e0ea04136601c0e9e2`; its file checksums passed before this run.
- Tools: mise 2026.11.1, Rust/Cargo 1.99.1, nextest 0.9.148, MBX 1.29.1. `mbx doctor` reported zero failures and the mise Cargo wrapper active.

The TCB capture checkout temporarily patched the pinned Tuiscotti source to the
snapshot and added capture-only mismatch handling plus a unique
`TUISCOTTI_CAPTURE_ROOT`. Those support changes and `.cargo/config.toml` have
been removed. The original `Cargo.lock` was restored from `Cargo.lock.original`.

## Capture results

Each partition used `TUISCOTTI_CAPTURE_ONLY=1`, its own evidence root, and
`timeout 230 mbx nextest run --offline --workspace --test functional --no-tests
fail -E 'test(/^<module>::/)' --no-capture` under `MISE_CI=1`.

| Partition | Outcome |
|---|---|
| showcase | 59/59 passed (117.195 s) |
| holla | 10/11 passed; `holla_second_gate_wrong_phrase_stays_then_reconfirm_executes` timed out waiting for `exact phrase finishes the docker plan`; an isolated retry failed the same way (24.964 s) |
| tablepro | 11/11 passed (103.732 s) |
| jackin | 8/10 passed; launch-failure and first-use had pre-visual semantic failures. Each exact producer test passed on a separate isolated retry (1.608 s and 12.164 s) |
| lifecycle | 2/2 passed (7.832 s) |

All partition logs, exit codes, evidence files, and retry logs remain under the
matching `active-*` directories. A successful capture-only test run is not
approval evidence.

Reconciliation used only the five roots above plus the Jackin retry root,
`check-artifacts` sample paths, and the 109 existing active functional JSON
paths as the ID inventory. It copied one distinct candidate digest for each
captured current ID. `active-candidates-reconciled-v2/inventory.tsv` reports
104 `CAPTURED`, five `MISSING`, zero `AMBIGUOUS`, and zero `UNEXPECTED` IDs.
All 104 copied samples have `TUISCPB\0` magic. Their digests match the copied
candidate SHA-256 ledger and raw artifacts.

The five missing old IDs and their fresh captured replacement candidates are
listed in `five-unmatched-id-review.tsv`. Existing dispositions mark each as
superseded and identify the same replacement IDs. This is evidence for the
migration owner; it does not authorize deletion, renaming, or approval. The
old files, disposition records, receipts, and `pre_refactor` history remain in
place.

`baseline-digests-before.txt` and `baseline-digests-after.txt` compare equal;
no file in `tests/functional/baselines` changed. No sample was accepted.

## Code and fixture checks

The isolated checkout contains the candidate changes in the working tree:

- Coverage inventory recognizes `.tui.pb` paths and requires binary files for
  active baseline rows; unrelated metadata JSON and legacy JSON do not satisfy
  coverage.
- Coverage fixtures exercise a complete binary fixture, a legacy JSON beside
  it, unrelated metadata JSON, a legacy-only missing-baseline case, and a
  binary orphan.
- The execution-ledger generator enumerates active `.tui.pb` paths by path
  identity without decoding binary payloads or including `pre_refactor` history.
- The changed-baseline harness writes a valid temporary binary sample and
  asserts a `State` mismatch including changed `cols` and `rows`.
- Functional documentation describes binary active samples and preserved JSON
  history.

`MISE_CI=1 mbx fmt --all -- --check` and
`python3 scripts/check-refactor-coverage.py --fixtures scripts/coverage-fixtures`
pass. Focused nextest for
`cases::g02_harness::harness_missing_baseline_fails` and
`cases::g02_harness::harness_changed_baseline_fails` passed 2/2 against the
immutable snapshot source. The harness compares a sorted map of relative paths
and SHA-256 values for every file under the production baseline root. The
review TSV parses as five rows and six tab-separated columns. The latest
focused run log is `focused-g02-snapshot-20261106/nextest.log` (exit code in
`focused-g02-snapshot-20261106/nextest.exit`); it passed both cases in 96.924
seconds. Full TCB functional validation is incomplete due to the Holla failure
and required baseline approvals/receipt refresh.

No branch, remote, PR head, published pin, active baseline, or frozen record was
changed. No PR, commit, or approval was created. Cross-platform capture remains
unverified outside native macOS arm64.
