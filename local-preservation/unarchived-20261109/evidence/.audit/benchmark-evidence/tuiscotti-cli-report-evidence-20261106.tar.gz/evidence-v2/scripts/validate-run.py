#!/usr/bin/env python3
"""Validate check evidence/report HTML and generate a fresh run summary."""
import argparse
import hashlib
import json
import re
import statistics
from html.parser import HTMLParser
from pathlib import Path

class ReportParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows=[]; self.row=None; self.cell=[]; self.links=[]; self.in_cell=False
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if tag=='tr': self.row=[]
        elif tag in ('td','th') and self.row is not None:
            self.cell=[]; self.in_cell=True
        elif tag=='a' and attrs.get('href'):
            self.links.append(attrs['href'])
    def handle_data(self, data):
        if self.in_cell: self.cell.append(data)
    def handle_endtag(self, tag):
        if tag in ('td','th') and self.in_cell:
            self.row.append(''.join(self.cell).strip()); self.in_cell=False
        elif tag=='tr' and self.row is not None:
            self.rows.append(self.row); self.row=None

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def timing(path):
    raw=path.read_text()
    field=lambda name: float(re.search(r'([0-9.]+) '+name,raw).group(1))
    rss=int(re.search(r'([0-9]+)  maximum resident set size',raw).group(1))
    return {'wall_seconds':field('real'),'user_cpu_seconds':field('user'),'system_cpu_seconds':field('sys'),'peak_rss_bytes':rss}

def load(path): return json.loads(path.read_text())
parser=argparse.ArgumentParser()
parser.add_argument('--run',required=True,type=Path)
parser.add_argument('--source',required=True,type=Path)
parser.add_argument('--sample',required=True,type=Path)
a=parser.parse_args(); root=a.run
check=load(root/'logs/check.stdout.json')
if check.get('status')!='missing' or check.get('test_id')!='bench/showcase-compact-80x24/pixels-macos-aarch64':
    raise SystemExit(f'unexpected CLI check response: {check}')
if (root/'logs/check.exit-code.txt').read_text().strip()!='1': raise SystemExit('missing-baseline check did not exit 1')
check_rows=list((root/'check-artifacts').rglob('result.json'))
if len(check_rows)!=1: raise SystemExit(f'expected one check result, got {len(check_rows)}')
check_result=load(check_rows[0])
if check_result.get('reason')!='missing': raise SystemExit(f'unexpected check artifact: {check_result}')
if len(list((root/'check-artifacts').rglob('actual.png')))!=1: raise SystemExit('expected one rendered actual PNG')
report_paths=[]; report_hashes=[]; report_times=[]; report_responses=[]
for index in range(1,6):
    tag=f'{index:02}'
    out=root/f'reports/pass-{tag}/index.html'
    response=load(root/f'logs/report-{tag}.stdout.json')
    if response.get('command')!='report' or response.get('status')!='pass': raise SystemExit(f'report {tag} failed: {response}')
    parser=ReportParser(); parser.feed(out.read_text())
    data_rows=[r for r in parser.rows if r and r[0]!='test']
    if len(data_rows)!=1: raise SystemExit(f'report {tag} has {len(data_rows)} data rows, expected one')
    row=data_rows[0]
    if row[0]!='bench/showcase-compact-80x24/pixels-macos-aarch64' or row[1]!='missing':
        raise SystemExit(f'report {tag} has unexpected row: {row}')
    if len(parser.links)!=1: raise SystemExit(f'report {tag} has {len(parser.links)} links, expected one')
    target=(out.parent/parser.links[0]).resolve()
    if not target.is_file() or target.name!='report.html': raise SystemExit(f'report {tag} link does not resolve: {target}')
    report_paths.append(out); report_hashes.append(sha(out)); report_times.append(timing(root/f'logs/report-{tag}.time.txt')); report_responses.append(response)
if len(set(report_hashes))!=1: raise SystemExit('report output hashes differ between runs')
source_check=json.loads((root/'logs/verified-run-inputs.json').read_text())
source_manifest= a.source/'SHA256SUMS'
summary={
 'schema':'tuiscotti-cli-report-e2e-benchmark.v2',
 'source_manifest_sha256':sha(source_manifest),
 'source_manifest_files_verified':source_check['source_files_verified'],
 'sample_sha256':sha(a.sample),
 'binary_sha256':sha(root/'bin/tuiscotti-macos-arm64'),
 'host_before':(root/'logs/host-before.txt').read_text(),
 'host_after':(root/'logs/host-after.txt').read_text(),
 'resource_caps':{'memory_bytes':1073741824,'wall_seconds_per_process':3600,'enforced_by_runner':False},
 'check':{'status':'missing (expected; disposable baseline dir empty)','exit_code':1,'evidence_file_count':len([p for p in (root/'check-artifacts').rglob('*') if p.is_file()]),'result_json_sha256':sha(check_rows[0]),'measurement':timing(root/'logs/check.time.txt')},
 'report':{'runs':5,'successful_runs':5,'entries_per_report':1,'evidence_links_per_report':1,'all_evidence_links_resolve':True,'output_bytes':report_paths[0].stat().st_size,'output_sha256':report_hashes[0],'all_output_hashes_equal':True,'timings':report_times,'wall_range_seconds':[min(r['wall_seconds'] for r in report_times),max(r['wall_seconds'] for r in report_times)],'peak_rss_range_bytes':[min(r['peak_rss_bytes'] for r in report_times),max(r['peak_rss_bytes'] for r in report_times)],'errors':0},
 'interpretation':f"Correctness and reproducibility evidence only. One report row; observed report wall range {min(r['wall_seconds'] for r in report_times):.2f}–{max(r['wall_seconds'] for r in report_times):.2f} s at coarse timer resolution. No speed claim.",
 'scope':['No accept, approval, conversion, or baseline write.','macOS arm64 only; no Linux or cross-platform claim.','MBX/Cargo/mise caches and trust metadata may be external shared writes.']
}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'check':summary['check'],'report':{k:summary['report'][k] for k in ('runs','entries_per_report','output_bytes','output_sha256','wall_range_seconds','peak_rss_range_bytes','all_evidence_links_resolve')}},indent=2))
