use std::env;
use std::fs;
use std::path::Path;

use sha2::{Digest, Sha256};
use tui_test::{SnapshotMetadata, SnapshotParts, SnapshotSource};
use tuiscotti::render_profile::{PROFILE_NAME, resolve_profile};
use tuiscotti::sample::{Observation, Sample};
use tuiscotti::view::{ViewSettings, capture_view};

fn hex(bytes: &[u8]) -> String {
    Sha256::digest(bytes).iter().map(|byte| format!("{byte:02x}")).collect()
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let out = env::args().nth(1).ok_or("output directory required")?;
    let out = Path::new(&out);
    fs::create_dir_all(out)?;
    let captured = capture_view(12, 2, &ViewSettings::builtin(), |frame| {
        let buffer = frame.buffer_mut();
        for (x, ch) in "same frame!".chars().enumerate() { buffer[(x as u16, 0)].set_char(ch); }
        for (x, ch) in "pinned TUI".chars().enumerate() { buffer[(x as u16, 1)].set_char(ch); }
    })?;
    let mut metadata = SnapshotMetadata::default();
    metadata.source = SnapshotSource::Offline;
    let snapshot = tui_test::TerminalSnapshot::try_new(SnapshotParts {
        cols: captured.cols(), rows: captured.rows(), scope: captured.scope(),
        viewport_origin: captured.viewport_origin(), cells: captured.cells().to_vec(),
        palette: *captured.palette(), default_foreground: captured.default_foreground(),
        default_background: captured.default_background(), default_cursor: captured.default_cursor(),
        cursor: captured.cursor().clone(), title: None, metadata,
    })?;
    let sample = Sample::state("parity/state", snapshot, Observation::empty())?;
    let sample_bytes = sample.to_bytes()?;
    fs::write(out.join("sample.tui.pb"), &sample_bytes)?;
    let png_path = out.join("render.png");
    let _render = tuiscotti::render_sample(&sample_bytes, &png_path)?;
    let png = fs::read(&png_path)?;
    let rgba = image::load_from_memory_with_format(&png, image::ImageFormat::Png)?.to_rgba8().into_raw();
    fs::write(out.join("render.rgba"), &rgba)?;
    let profile = resolve_profile(PROFILE_NAME)?;
    println!("target={}-{}", env::consts::OS, env::consts::ARCH);
    println!("sample_gate=state; test_id=parity/state");
    println!("metadata=source:Offline,captured_at_ms:0,revision:0,backend:empty,session:empty");
    println!("profile={}", profile.name());
    for face in profile.faces() { println!("font={}:len:{},sha256:{}", face.role(), face.byte_len(), face.bytes_sha256()); }
    println!("sample_bytes={};sha256:{}", sample_bytes.len(), hex(&sample_bytes));
    println!("png_bytes={};sha256:{}", png.len(), hex(&png));
    println!("rgba_bytes={};sha256:{}", rgba.len(), hex(&rgba));
    Ok(())
}
