# Supplemental cross-target parity (Docker emulation)

Status: byte-identical supplemental emulation evidence only. The Linux process ran x86_64 under Docker emulation on Apple ARM64; native Linux x86_64 remains NOT VERIFIED.

## Source and tools

- Immutable source: `/private/tmp/tuiscotti-goal-current-20261106`; `shasum -a 256 -c SHA256SUMS` passed all 684 listed entries. Manifest SHA-256: `2d1e3c0cdb34294c13573f18165158d0e55aa89f20fa822ee7eaa84cff454765`.
- Disposable project copies: `mac-arm64/` and `linux-x86_64-emulated/` under this directory. Both independently passed the same 684-entry source checksum before the parity harness was added. The identical harness SHA-256 in both copies is `4f2d2f6441186d59e0ecdd6910ef05923096240b131cc6911e7518f5daaf3157`.
- macOS: Darwin Apple Silicon arm64; mise 2026.11.1 (host-installed), MBX 1.29.2, Cargo 1.99.1, rustc 1.99.1 (`58cf8f9c35b355199727627d07ae34a4e2846d67`, LLVM 23.1.1). `mbx doctor`: 0 failures; atime/cache warnings and copy fallback warning. `mise exec -- sh -lc 'command -v cargo'` resolved `/Users/donbeave/.local/share/mise/command-wrappers/bin/cargo`.
- Linux container: Docker image `rust:1.99.1`, image ID `sha256:4c4c8ec55be09785e6d6ac45ea9853525a73c15db74009100ac08952e773dfb8` (ARM64 image; run with `--platform linux/amd64`, where `uname -m`/rustc host is x86_64). Supplied mise binary `2026.11.1 linux-x64`, SHA-256 `7129dbab31d698f9028db9374f7ba7987232b0426f837dcbce437130a61415f9`. `mise install --locked` installed project-pinned tools; MBX 1.29.2 and Rust/Cargo 1.99.1. `mbx doctor`: 0 failures, one warning that no fallback Cargo shim is installed (we did not use plain Cargo). `mise exec -- sh -c 'command -v cargo'` resolved `/tmp/mise-data/command-wrappers/bin/cargo`.
- Project `mise.lock` pins MBX and Rust, but does not pin mise itself. Linux used the supplied explicit mise 2026.11.1 binary. Both Cargo invocations below used `mise exec -- cargo`; no direct Cargo bypass.

## Identical fixture definition

The disposable example `crates/tuiscotti/examples/parity.rs` constructs a Ratatui `TestBackend` frame with `capture_view(12, 2, ViewSettings::builtin(), ...)`: row 0 is `same frame!` then one default blank cell; row 1 is `pinned TUI` then two default blank cells. Default cell styling/palette/cursor are retained. It reconstructs the snapshot with `SnapshotMetadata { captured_at_ms: 0, revision: 0, backend: "", session: "", source: Offline }`, no title, and no clock/provenance data. It creates `Sample::state("parity/state", ..., Observation::empty())` (gate `state`; no OS/arch suffix is required).

Sample `.tui.pb` bytes are created independently on both runs from this same source and logical input. The state sample carries neither image nor render contract. The example then separately decodes that exact serialized sample through `tuiscotti::render_sample` and renders `render.png`; the PNG is not embedded in the state sample. RGBA bytes are decoded from the resulting PNG and emitted separately. Pinned profile: `tuiscotti-pinned-v1`, 16 ordered profile face entries, identical lengths and digests on both runs. Profile metrics in source: 10x20 px cell, 16 px font, baseline 15 px, scale 1.0; vendored font bytes are compiled into each binary and profile-verified.

There are no platform-specific sample fields in this `state` fixture. The process target identity (`macos-aarch64` vs `linux-x86_64`) is an external execution fact only; no pixel contract `platform_key` exists in the state sample. No output fields were normalized or removed for comparison. The exact `.tui.pb` bytes supplied to the two independent PNG-render operations are themselves `cmp`-identical.

## Commands

Native macOS from the disposable copy:

```sh
mise exec -- mbx --version
mise exec -- mbx doctor
mise exec -- sh -lc 'command -v cargo; cargo --version; rustc -vV | sed -n "1,6p"'
mise exec -- cargo run -p tuiscotti --example parity --locked --offline -- /private/tmp/tuiscotti-parity-20261106/mac-output
```

The initial attempt failed because immutable copy modes prevented MBX target creation; only the disposable mac copy was made user-writable (`chmod -R u+w .../mac-arm64`), then the exact wrapper command above passed.

Linux Docker emulation command (same project copy/harness; `/Users/donbeave/.cargo` is mounted read-only only for the prewarmed registry):

```sh
docker run --rm --platform linux/amd64 \
  -v /private/tmp/tuiscotti-parity-20261106/linux-x86_64-emulated:/repo \
  -v /private/tmp/tuiscotti-linux-mise-evidence/mise-v2026.11.1-linux-x64:/misebin/mise:ro \
  -v /Users/donbeave/.cargo:/cargo:ro \
  -v /private/tmp/tuiscotti-parity-20261106/linux-output:/out \
  -e MISE_DATA_DIR=/tmp/mise-data -e MISE_CONFIG_DIR=/tmp/mise-config \
  -e MISE_CACHE_DIR=/tmp/mise-cache -e MISE_STATE_DIR=/tmp/mise-state \
  -e RUSTUP_HOME=/tmp/rustup -e CARGO_HOME=/tmp/cargo-home \
  -e CARGO_TARGET_DIR=/tmp/tuiscotti-target-linux \
  rust:1.99.1 sh -lc 'set -eu; mkdir -p /tmp/cargo-home /out; ln -sfn /cargo/registry /tmp/cargo-home/registry; chmod -R u+w /repo; cd /repo; /misebin/mise install --locked; /misebin/mise exec -- mbx doctor; /misebin/mise exec -- sh -c "command -v cargo; cargo --version; rustc -vV | sed -n \"1,6p\""; /misebin/mise exec -- cargo run -p tuiscotti --example parity --locked --offline -- /out'
```

## Results

All `cmp` operations passed without transformations:

| Artifact | Size | SHA-256 |
|---|---:|---|
| `sample.tui.pb` | 697 B | `a085995607b5b772c5de4b0f34af4a8a31c29a5177b85586d42e852c34d4465b` |
| separately rendered `render.png` | 3,585 B | `c1955f1223629050d8bb8ce215b3ca90d9395d10b97053934dd6a5e8f93731b4` |
| decoded `render.rgba` | 19,200 B | `33e4bd208217f379007a319c1ff6e4aa7171faf1e98d34f2367c6e7483ef0add` |

PNG reports 120x40, 8-bit RGBA, non-interlaced on both hosts. All 16 profile font entries (including fallback slots) report the same byte lengths and pinned SHA-256s. Execution metadata differs only in target identity: `macos-aarch64` vs `linux-x86_64`; that identity is not present in the binary state sample or separately rendered PNG bytes.

Artifacts are preserved in `mac-output/` and `linux-output/`. This result is a supplemental early regression signal only; it does not satisfy a native Linux runner requirement or goal-wide cross-platform verification.
