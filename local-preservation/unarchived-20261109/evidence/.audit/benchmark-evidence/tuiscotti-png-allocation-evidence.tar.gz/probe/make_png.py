import hashlib, struct, zlib
from pathlib import Path
w, h = 20, 20
rgba = bytes([17, 34, 51, 255]) * (w * h)
def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
rows = b''.join(b'\0' + rgba[y*w*4:(y+1)*w*4] for y in range(h))
png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b'')
Path(__file__).with_name('fixture.png').write_bytes(png)
print('png_sha256=' + hashlib.sha256(png).hexdigest())
print('rgba_sha256=' + hashlib.sha256(rgba).hexdigest())
