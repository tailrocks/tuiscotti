use std::alloc::{GlobalAlloc, Layout, System};
use std::error::Error;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use tuiscotti::sample::{Sample, SampleError};
use tuiscotti::check::{CheckError, FrozenStore};
#[allow(dead_code)] mod fixtures;
const TARGET: usize = 20 * 20 * 4;
struct FailOnce;
static TRACK: AtomicBool = AtomicBool::new(false);
static ARMED: AtomicBool = AtomicBool::new(false);
static MATCHES: AtomicUsize = AtomicUsize::new(0);
static DENIALS: AtomicUsize = AtomicUsize::new(0);
fn observe(size: usize, can_deny: bool) -> bool {
    if TRACK.load(Ordering::SeqCst) && size == TARGET {
        MATCHES.fetch_add(1, Ordering::SeqCst);
        if can_deny && ARMED.swap(false, Ordering::SeqCst) {
            DENIALS.fetch_add(1, Ordering::SeqCst);
            return true;
        }
    }
    false
}
unsafe impl GlobalAlloc for FailOnce {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        if observe(layout.size(), true) { return std::ptr::null_mut(); }
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        observe(layout.size(), false);
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        observe(size, false);
        unsafe { System.realloc(ptr, layout, size) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { unsafe { System.dealloc(ptr, layout) } }
}
#[global_allocator] static ALLOCATOR: FailOnce = FailOnce;
fn run<T>(f: impl FnOnce() -> T, deny: bool) -> (T, usize, usize) {
    MATCHES.store(0, Ordering::SeqCst);
    DENIALS.store(0, Ordering::SeqCst);
    ARMED.store(deny, Ordering::SeqCst);
    TRACK.store(true, Ordering::SeqCst);
    let result = f();
    TRACK.store(false, Ordering::SeqCst);
    ARMED.store(false, Ordering::SeqCst);
    (result, MATCHES.load(Ordering::SeqCst), DENIALS.load(Ordering::SeqCst))
}
fn verify_error(error: &SampleError) {
    match error {
        SampleError::Allocation { site, requested, source } => {
            assert_eq!(*site, "PNG RGBA output");
            assert_eq!(*requested, TARGET as u64);
            assert!(error.source().unwrap().is::<std::collections::TryReserveError>());
            assert!(!source.to_string().is_empty());
        }
        _ => panic!("unexpected error: {error:?}"),
    }
    assert_eq!(tuiscotti::approve::sample_code(error), "RESOURCE_LIMIT");
}
fn main() -> Result<(), Box<dyn Error>> {
    let png = include_bytes!("../fixture.png");
    let bytes = fixtures::container(&fixtures::message_with_png(png, 20, 20));
    let root = std::env::temp_dir().join(format!("tuiscotti-png-alloc-{}", std::process::id()));
    std::fs::create_dir_all(&root)?;
    let store = FrozenStore::new(&root.join("baseline"), &root.join("artifacts"))?;
    let workflow = std::env::args().nth(1).unwrap_or_else(|| "sample".to_owned());
    if workflow == "sample" {
        let (before, matches, denied) = run(|| Sample::from_bytes(&bytes), false);
        before?; assert_eq!((matches, denied), (1, 0));
        let (failed, matches, denied) = run(|| Sample::from_bytes(&bytes), true);
        let error = failed.expect_err("allocation refusal must fail");
        assert_eq!((matches, denied), (1, 1)); verify_error(&error);
        let (after, matches, denied) = run(|| Sample::from_bytes(&bytes), false);
        after?; assert_eq!((matches, denied), (1, 0));
    } else if workflow == "check" {
        let (before, matches, denied) = run(|| store.check(&bytes), false);
        before?; assert_eq!((matches, denied), (2, 0));
        let (failed, matches, denied) = run(|| store.check(&bytes), true);
        let error = failed.expect_err("allocation refusal must fail");
        assert_eq!((matches, denied), (1, 1));
        match &error { CheckError::Sample(source) => verify_error(source), _ => panic!("unexpected error: {error:?}") }
        let (after, matches, denied) = run(|| store.check(&bytes), false);
        after?; assert_eq!((matches, denied), (3, 0));
    } else { panic!("unknown workflow") }
    std::fs::remove_dir_all(root)?;
    println!("workflow={workflow} controls=success matches_before={} matches_after={} denial=1 site=PNG_RGBA_output requested={TARGET} source=TryReserveError code=RESOURCE_LIMIT png_sha256={} input_sha256={} input_bytes={}", if workflow == "sample" { 1 } else { 2 }, if workflow == "sample" { 1 } else { 3 }, fixtures::sha256(png), fixtures::sha256(&bytes), bytes.len());
    Ok(())
}
