# PNG output allocation refusal probe

This standalone executable uses a test-process-only System-delegating global allocator. It denies exactly one 1,600-byte Rust allocation at the `PNG RGBA output` reservation during decoding of a valid 20 × 20 RGBA PNG in a valid binary sample. It asserts the exact `SampleError::Allocation` site and size, the real `TryReserveError` source, and `RESOURCE_LIMIT` classification. The check workflow asserts the error is propagated as `CheckError::Sample`. The PNG and RGBA digests are valid; no ledger limits are injected and no baseline is approved.

Each process performs successful controls before and after refusal. It counts all matching `alloc`, `alloc_zeroed` and `realloc` requests while the operation runs; only `alloc` is denied. `sample` controls see exactly one matching layout. For `check`, the first successful check saves evidence; the controls see two and three matching requests respectively as evidence is revisited. The failed operation sees exactly one match and the site assertion proves where the refusal landed. The stored ten-run log is from five fresh processes per workflow on macOS 27.2 arm64, Rust 1.99.1, mbx 1.29.2. The first successful checks write only inside fresh disposable per-process temporary directories, removed on success.

This is evidence for one Rust allocation site on one host, not native allocation, Linux, every PNG allocation site, or recovery from arbitrary process-wide OOM. The allocator uses unsafe code only in this separate executable. No production source is changed.

## Reproduce

With pinned tools and Cargo dependencies cached, from this directory:

```sh
cd snapshot
shasum -a 256 -c SHA256SUMS
MISE_TRUSTED_CONFIG_PATHS="$PWD" mise exec -- cargo check --workspace --locked --offline
MISE_TRUSTED_CONFIG_PATHS="$PWD" CARGO_BIN_EXE_tuiscotti=unused mbx run --locked --offline --manifest-path ../probe/Cargo.toml -- sample
MISE_TRUSTED_CONFIG_PATHS="$PWD" CARGO_BIN_EXE_tuiscotti=unused mbx run --locked --offline --manifest-path ../probe/Cargo.toml -- check
```

Repeat the executable in separate processes to reproduce the ten-run log. `probe/SHA256SUMS` covers the harness, PNG, lockfile, and original raw runs; `snapshot/SHA256SUMS` covers the source. `probe/make_png.py` documents fixture construction; the committed fixture bytes and hashes are authoritative because zlib versions may differ. Input sample SHA-256 on the recorded host: `fbf35fc7b14e00d9e530b54104146121d864a301700ead26991b017c804b1dba` (platform-specific test ID means it can differ on another host).
