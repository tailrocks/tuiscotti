use std::alloc::{GlobalAlloc, Layout, System};
use std::error::Error;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use tuiscotti::sample::{Sample, SampleError};

#[allow(dead_code)]
mod fixtures;

struct FailOnce;
static ARMED: AtomicBool = AtomicBool::new(false);
static TARGET: AtomicUsize = AtomicUsize::new(0);
static DENIALS: AtomicUsize = AtomicUsize::new(0);

// Test-process-only allocator delegates every operation to Rust's System allocator,
// except the first armed allocation of the target layout size.
unsafe impl GlobalAlloc for FailOnce {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        if layout.size() == TARGET.load(Ordering::SeqCst)
            && ARMED.swap(false, Ordering::SeqCst)
        {
            DENIALS.fetch_add(1, Ordering::SeqCst);
            return std::ptr::null_mut();
        }
        unsafe { System.alloc(layout) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        unsafe { System.realloc(ptr, layout, size) }
    }
}
#[global_allocator]
static ALLOCATOR: FailOnce = FailOnce;

fn main() -> Result<(), Box<dyn Error>> {
    let bytes = fixtures::valid_container();
    let expanded = u64::from_le_bytes(bytes[16..24].try_into()?);
    let target = usize::try_from(expanded)?;
    let control = Sample::from_bytes(&bytes)?;
    assert_eq!(control.test_id(), fixtures::TEST_ID);
    TARGET.store(target, Ordering::SeqCst);
    ARMED.store(true, Ordering::SeqCst);
    let error = Sample::from_bytes(&bytes).expect_err("injected allocation should fail");
    ARMED.store(false, Ordering::SeqCst);
    assert_eq!(DENIALS.load(Ordering::SeqCst), 1);
    match &error {
        SampleError::Allocation { site, requested, .. } => {
            assert_eq!(*site, "decompressed message");
            assert_eq!(*requested, expanded);
        }
        other => panic!("unexpected error: {other:?}"),
    }
    assert!(error.source().is_some());
    assert_eq!(tuiscotti::approve::sample_code(&error), "RESOURCE_LIMIT");
    let after = Sample::from_bytes(&bytes)?;
    assert_eq!(after.test_id(), fixtures::TEST_ID);
    println!("post_failure_control=success");
    println!("control=success test_id={} input_bytes={} expanded_bytes={expanded}", control.test_id(), bytes.len());
    println!("injected=allocation_refused denials={} code={} error={} source={}", DENIALS.load(Ordering::SeqCst), tuiscotti::approve::sample_code(&error), error, error.source().unwrap());
    Ok(())
}
