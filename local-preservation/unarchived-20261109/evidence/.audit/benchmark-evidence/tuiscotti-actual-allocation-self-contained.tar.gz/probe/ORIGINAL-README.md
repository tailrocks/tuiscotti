# Actual allocation refusal probe

On Darwin arm64, Rust 1.99.1 (58cf8f9c3 2026-10-13), mbx 1.29.2, the five separate process runs in `runs.log` all decoded a 1,528-byte valid sample before and after injection. Expanded length was 2,550 bytes. During the intervening `Sample::from_bytes`, the allocator returned null once on the first armed 2,550-byte allocation. The public result was `SampleError::Allocation` with site `decompressed message`, requested 2550, a retained `TryReserveError` reporting allocator refusal, and `approve::sample_code` equal to `RESOURCE_LIMIT`. Both the site and denial count are asserted in the executable. The size match alone would not establish which call failed; the returned typed site and matching requested size establish the observed path.

The injector is a small custom, test-process-only `GlobalAlloc`, not an independently validated third-party fault injector. It delegates allocations, reallocations, and frees to Rust's standard `System` allocator, except that the first armed `alloc` with the selected layout size returns null, which the `GlobalAlloc` contract uses to indicate failure. It uses unsafe code solely in this separate executable; no shipping source or lint was modified. The test uses a known fixture copied byte-for-byte from the snapshot's `crates/tuiscotti-cli/tests/compressed_binary/fixtures.rs`; it compresses a real valid protobuf fixture using pinned `zstd-safe`. `snapshot-source-hashes.txt` records the snapshot manifest and relevant actual source files. The probe lock was initially copied from the snapshot lock: all packages resolved by the probe have the same name/version/source/checksum as the snapshot, apart from the new probe package; unrelated snapshot-only packages are removed by Cargo resolution. `probe-hashes.txt` identifies the probe.

Reproduce while the verified source snapshot remains at `/private/tmp/tuiscotti-continuation-snapshot`:

```sh
cd /private/tmp/tuiscotti-continuation-snapshot
shasum -a 256 -c SHA256SUMS
mkdir -p /private/tmp/tuiscotti-alloc-exp.K6yDYd
cp -R . /private/tmp/tuiscotti-alloc-exp.K6yDYd/
mise trust /private/tmp/tuiscotti-alloc-exp.K6yDYd/mise.toml
# Extract this archive at /private/tmp/tuiscotti-alloc-probe.
cd /private/tmp/tuiscotti-alloc-exp.K6yDYd
mbx doctor
CARGO_BIN_EXE_tuiscotti=unused mbx run --locked --offline --manifest-path /private/tmp/tuiscotti-alloc-probe/Cargo.toml
```

The hard-coded path in the archived manifest must identify the disposable verified snapshot copy. The environment variable satisfies an unused CLI helper in the copied fixture. Cargo dependencies and pinned tools must already be cached. Snapshot copying and trust setup are only needed if that copy does not already exist; do not overwrite any active checkout. `runs.log` records the five repeated invocations and output.

This only tests refusal of the decompressed-message reservation on the named host. It does not prove all allocation sites, native C allocator behavior, PNG failure recovery, memory ceiling, peak RSS, Linux, or 32-bit behavior. It is not an ambient OOM recovery claim. Matching a chosen request size is scoped to a single-threaded decode and the failure assertion detects selection of a different site; changes to decoder order or fixture may require choosing a new target.
