# Actual allocator refusal evidence

This bundle contains the SHA-256-verified source snapshot and a standalone test process. Original five-run output and provenance are in `probe/runs.log`, `probe/ORIGINAL-README.md`, and the original hash records. `probe/Cargo.toml` now uses a relative path to the included snapshot; the original README's absolute paths describe the original run and have been superseded for reproduction. `probe/fresh-extraction-run.log` records a successful additional run from a separate freshly extracted directory.

To reproduce from any extraction directory on a compatible host, install the pinned Rust and mise tools and cache Cargo dependencies, then run:

```sh
cd snapshot
shasum -a 256 -c SHA256SUMS
mise trust "$PWD/mise.toml"
mbx doctor
CARGO_BIN_EXE_tuiscotti=unused mbx run --locked --offline --manifest-path ../probe/Cargo.toml
```

The fixture is copied byte-for-byte from the included CLI tests. The Rust System-delegating GlobalAlloc injector lives only in the standalone process; it returns null for one armed allocation and asserts the actual failure site, source, and public RESOURCE_LIMIT mapping. It uses unsafe code only in that test executable and does not alter shipping code. The test checks a normal decode before and after injection. The expanded request was 2,550 bytes in all six observed runs.

This is evidence for one Rust allocation failure path on Darwin arm64 with Rust 1.99.1 and mbx 1.29.2, not native allocation, other sites, aggregate resource use, peak RSS, or other platforms. See the original provenance for full limits and methodology.
