# Disposable final-source CLI report benchmark

This corrected bundle preserves a verified final-source snapshot, one previously staged pixels sample, a reproducible script, one successful fresh run, fail-closed negative cases, and checksums. It does not modify the original evidence directory or the project tree.

The source snapshot `source-snapshot/` verifies all 684 entries in `SHA256SUMS`; that manifest's SHA-256 is `2d1e3c0cdb34294c13573f18165158d0e55aa89f20fa822ee7eaa84cff454765`. The copied sample SHA-256 is `a309eddd3c2f48120f8b7d6a79c97751e0b9f2ece7af0bd6f31fda9eccdd2964`.

## Measurement

The release `tuiscotti` binary was built from a disposable copy using mise-managed MBX 1.29.2 and Rust 1.99.1. One existing staged sample was checked against an empty disposable baseline directory. The expected result was `missing` with exit code 1; the CLI wrote four fresh check evidence files. No acceptance, baseline conversion, or baseline write ran.

The CLI `report` command then ran five times over that one check entry. All runs passed; each report contained exactly one parsed data row and one evidence link, and every link resolved to the generated check HTML. The five 642-byte HTML outputs have identical SHA-256 `5c495efdc4557ce5028870e79975e26281e692092e3a7417cc0fef3c0c29fa4f`.

| Operation | Runs | Wall time | CPU time | Peak RSS |
|---|---:|---:|---:|---:|
| Check | 1 | 0.27 s | user 0.01 s, system 0.00 s | 74,121,216 B |
| Report | 5 | 0.01 s each (timer resolution) | user/system 0.00 s each | 70,205,440–70,238,208 B |

Host load was 115.46/107.10/107.08 on 18 logical CPUs. The report corpus contains one row and the measured durations are at coarse timer resolution. These data establish the report workflow and output correctness; they do not support a speed claim. The task caps (1 GiB per process and 60 minutes per process) are recorded in `replays/final-20261106-v3/summary.json` and were not enforced by the runner.

## Reproduce

With the pinned mise-managed tools and dependencies available, run:

```sh
./scripts/replay-report-benchmark.sh
```

The script verifies the source manifest and sample hashes before and after copying inputs, builds in a fresh run directory, creates fresh check artifacts, runs five reports, parses and validates the actual HTML row and evidence link, then writes that run's `summary.json` and `checksums.sha256`. It refuses to reuse an existing run ID; set `TUISCOTTI_REPORT_RUN_ID` only to a new unique value.

`python3 scripts/test-negative-cases.py final-20261106-v3` proves modified source files, modified sample bytes, and output-directory reuse fail closed. The collision case confirms the existing run checksum file remains unchanged. The aggregate also tests that a false `existing_manifest_unchanged` value makes the suite fail. Injected CLI/report command failures were not exercised.

Replay outputs live under `replays/<run-id>/`. The script briefly trusts the disposable source copy's `mise.toml` and removes that entry on exit. MBX/Cargo/mise caches and mise trust metadata are external shared writes. Source and sample data, compiled binary, results, logs, and per-run manifests are included in this bundle. This is macOS arm64 evidence only; it makes no Linux or cross-platform determinism claim.
