#!/usr/bin/env python3
"""Fail closed on any source snapshot or benchmark sample mismatch."""
import argparse
import hashlib
import json
from pathlib import Path

SOURCE_MANIFEST_SHA256 = '2d1e3c0cdb34294c13573f18165158d0e55aa89f20fa822ee7eaa84cff454765'
SAMPLE_SHA256 = 'a309eddd3c2f48120f8b7d6a79c97751e0b9f2ece7af0bd6f31fda9eccdd2964'
EXPECTED_SOURCE_FILES = 684
parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--sample', required=True, type=Path)
args = parser.parse_args()
manifest = args.source / 'SHA256SUMS'
manifest_bytes = manifest.read_bytes()
manifest_hash = hashlib.sha256(manifest_bytes).hexdigest()
if manifest_hash != SOURCE_MANIFEST_SHA256:
    raise SystemExit(f'source manifest SHA-256 mismatch: {manifest_hash}')
checked = 0
for line in manifest_bytes.decode('utf-8').splitlines():
    if not line:
        continue
    digest, name = line.split('  ', 1)
    rel = Path(name.removeprefix('./'))
    if rel.is_absolute() or '..' in rel.parts:
        raise SystemExit(f'unsafe path in source manifest: {name}')
    file = args.source / rel
    if not file.is_file():
        raise SystemExit(f'missing source file: {name}')
    actual = hashlib.sha256(file.read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit(f'source SHA-256 mismatch: {name}')
    checked += 1
if checked != EXPECTED_SOURCE_FILES:
    raise SystemExit(f'source file count mismatch: {checked}')
sample_hash = hashlib.sha256(args.sample.read_bytes()).hexdigest()
if sample_hash != SAMPLE_SHA256:
    raise SystemExit(f'sample SHA-256 mismatch: {sample_hash}')
print(json.dumps({'source_manifest_sha256': manifest_hash,
                  'source_files_verified': checked,
                  'sample_sha256': sample_hash}, indent=2))
