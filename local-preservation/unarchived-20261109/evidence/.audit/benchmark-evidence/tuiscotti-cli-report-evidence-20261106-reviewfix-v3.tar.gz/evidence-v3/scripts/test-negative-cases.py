#!/usr/bin/env python3
"""Prove input verification and run-directory collision handling fail closed."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
RUN_ID=sys.argv[1]
RUN=ROOT/'replays'/RUN_ID
SOURCE=ROOT/'source-snapshot'
SAMPLE=ROOT/'inputs/showcase-compact-80x24.pixels.tui.pb'
VERIFY=ROOT/'scripts/verify-inputs.py'
REPLAY=ROOT/'scripts/replay-report-benchmark.sh'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def checks_passed(items):
    return all(c.get('failed_closed') is True and c.get('existing_manifest_unchanged', True) is True for c in items)
checks=[]
with tempfile.TemporaryDirectory(prefix='bad-source-') as tmp:
    temp=Path(tmp); copied=temp/'source'; shutil.copytree(SOURCE,copied)
    first=next(line.split('  ',1)[1] for line in (copied/'SHA256SUMS').read_text().splitlines() if line)
    source_file=copied/first.removeprefix('./')
    source_file.chmod(source_file.stat().st_mode | 0o200)
    data=bytearray(source_file.read_bytes()); data[0]^=1; source_file.write_bytes(data)
    p=subprocess.run([sys.executable,str(VERIFY),'--source',str(copied),'--sample',str(SAMPLE)],capture_output=True,text=True)
    checks.append({'case':'modified source file','expected_nonzero':True,'exit_code':p.returncode,'failed_closed':p.returncode!=0 and 'source SHA-256 mismatch' in p.stderr})
with tempfile.TemporaryDirectory(prefix='bad-sample-') as tmp:
    bad=Path(tmp)/'sample.tui.pb'; data=bytearray(SAMPLE.read_bytes()); data[-1]^=1; bad.write_bytes(data)
    p=subprocess.run([sys.executable,str(VERIFY),'--source',str(SOURCE),'--sample',str(bad)],capture_output=True,text=True)
    checks.append({'case':'modified sample bytes','expected_nonzero':True,'exit_code':p.returncode,'failed_closed':p.returncode!=0 and 'sample SHA-256 mismatch' in p.stderr})
manifest=RUN/'checksums.sha256'; before=sha(manifest)
env=os.environ.copy(); env['TUISCOTTI_REPORT_RUN_ID']=RUN_ID
p=subprocess.run([str(REPLAY)],env=env,capture_output=True,text=True)
after=sha(manifest)
checks.append({'case':'reused output directory','expected_nonzero':True,'exit_code':p.returncode,'failed_closed':p.returncode!=0,'existing_manifest_unchanged':before==after})
false_manifest_probe=[{'failed_closed':True,'existing_manifest_unchanged':False}]
false_manifest_rejected=not checks_passed(false_manifest_probe)
checks.append({'case':'aggregate rejects false unchanged-manifest condition','expected_aggregate_failure':True,'aggregate_failed':false_manifest_rejected,'failed_closed':false_manifest_rejected})
result={'schema':'report-replay-negative-cases.v2','checks':checks,'all_passed':checks_passed(checks),'aggregate_false_condition_rejected':false_manifest_rejected}
out=ROOT/'negative-tests.json'; out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if not result['all_passed']: raise SystemExit(1)
