#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd -P)
RUN_ID=${TUISCOTTI_REPORT_RUN_ID:-$(date -u '+%Y%m%dT%H%M%SZ')}
OUT="$ROOT/replays/$RUN_ID"
mkdir -p "$ROOT/replays"
# mkdir without -p is an intentional no-clobber guard.
mkdir "$OUT"
SOURCE="$OUT/source"
INPUT="$OUT/input/showcase-compact-80x24.pixels.tui.pb"
mkdir -p "$SOURCE" "$OUT/input" "$OUT/baselines-empty" "$OUT/logs" "$OUT/reports" "$OUT/check-artifacts" "$OUT/bin"
python3 "$ROOT/scripts/verify-inputs.py" --source "$ROOT/source-snapshot" --sample "$ROOT/inputs/showcase-compact-80x24.pixels.tui.pb" > "$OUT/logs/verified-original-inputs.json"
cp -a "$ROOT/source-snapshot/." "$SOURCE/"
chmod -R u+w "$SOURCE"
cp "$ROOT/inputs/showcase-compact-80x24.pixels.tui.pb" "$INPUT"
python3 "$ROOT/scripts/verify-inputs.py" --source "$SOURCE" --sample "$INPUT" > "$OUT/logs/verified-run-inputs.json"
{
  date -u '+%Y-%m-%dT%H:%M:%SZ'
  uptime
  printf 'logical_cpus='
  sysctl -n hw.logicalcpu
  sw_vers
} > "$OUT/logs/host-before.txt"
mise trust "$SOURCE/mise.toml"
cleanup() { mise trust --untrust "$SOURCE/mise.toml" >/dev/null 2>&1 || true; }
trap cleanup EXIT
(
  cd "$SOURCE"
  mise exec -- mbx doctor
  mise exec -- mbx check --workspace --locked --offline
  mise exec -- mbx build --release --locked --offline -p tuiscotti-cli
) > "$OUT/logs/build-and-setup.stdout.txt" 2> "$OUT/logs/build-and-setup.stderr.txt"
BIN="$SOURCE/target/release/tuiscotti"
test -x "$BIN"
cp "$BIN" "$OUT/bin/tuiscotti-macos-arm64"
shasum -a 256 "$OUT/bin/tuiscotti-macos-arm64" > "$OUT/logs/binary-sha256.txt"
/usr/bin/time -l -o "$OUT/logs/check.time.txt" "$OUT/bin/tuiscotti-macos-arm64" --json check --sample "$INPUT" --baselines "$OUT/baselines-empty" --artifacts "$OUT/check-artifacts" > "$OUT/logs/check.stdout.json" 2> "$OUT/logs/check.stderr.txt" || CHECK_EXIT=$?
CHECK_EXIT=${CHECK_EXIT:-0}
printf '%s\n' "$CHECK_EXIT" > "$OUT/logs/check.exit-code.txt"
if [ "$CHECK_EXIT" -ne 1 ]; then
  echo "expected missing-baseline check exit 1, got $CHECK_EXIT" >&2
  exit 1
fi
for pass in 01 02 03 04 05; do
  report="$OUT/reports/pass-$pass/index.html"
  mkdir -p "$(dirname "$report")"
  /usr/bin/time -l -o "$OUT/logs/report-$pass.time.txt" "$OUT/bin/tuiscotti-macos-arm64" --json report --artifacts "$OUT/check-artifacts" --out "$report" > "$OUT/logs/report-$pass.stdout.json" 2> "$OUT/logs/report-$pass.stderr.txt"
done
{
  date -u '+%Y-%m-%dT%H:%M:%SZ'
  uptime
} > "$OUT/logs/host-after.txt"
# The Cargo target tree is disposable build output; retain the exact source copy and binary.
python3 - "$SOURCE/target" <<'PY'
from pathlib import Path
import shutil, sys
p=Path(sys.argv[1])
if p.is_symlink(): p.unlink()
elif p.exists(): shutil.rmtree(p)
PY
python3 "$ROOT/scripts/validate-run.py" --run "$OUT" --source "$SOURCE" --sample "$INPUT"
python3 - "$OUT" <<'PY'
from pathlib import Path
import hashlib, sys
root=Path(sys.argv[1])
manifest=root/'checksums.sha256'
files=sorted(p for p in root.rglob('*') if p.is_file() and p != manifest)
manifest.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n' for p in files))
print(f'checksummed {len(files)} run files')
PY
