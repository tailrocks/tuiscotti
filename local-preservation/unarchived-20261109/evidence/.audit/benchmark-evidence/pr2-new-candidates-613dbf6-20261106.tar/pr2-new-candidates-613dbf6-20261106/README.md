# TCB PR #2: new isolated candidate evidence

Separate preservation archive; it does not approve or accept any candidate and does not replace earlier PR #2 evidence. The original `/private/tmp/tcb-pr2-validation-613dbf6-20261106/run-evidence/README.md` and named evidence paths are preserved under `run-evidence/`. Candidate bytes and test evidence remain isolated from production baselines.

## Provenance and scope

The handoff reports disposable TCB checkout HEAD `613dbf6759cfbcedf4992bc0356c98ebbed76643` on macOS arm64, with a temporary local dependency patch to the verified Tuiscotti PR26 snapshot. The 685-entry Tuiscotti `SHA256SUMS` and a local verification receipt are preserved under `tuiscotti-source/`. The evidence README is the source of run-by-run status; no mutable rollout index was used. Production baseline before/after digest maps are included.

Included candidate sets: two paused-mode Holla samples (hashes in handoff), two lifecycle samples (`showcase_help_80x24`, `showcase_popover_resize`), and one corrected Jackin `jackin_first_use_empty` sample. The archived raw capture roots and isolated fixture copies retain their source-relative paths. Holla's age-only comparison found the row 21/column 99 freshness label at 2 seconds paused versus 3 seconds reduced; fixture hashes vary with capture provenance. These are all unapproved.

Evidence also includes the paused-test patch, four normal no-bypass Holla validations and their receipts, capture and fixture validation logs/receipts for lifecycle and Jackin, holla lifecycle/replay context, and the handoff's test partition logs. Associated HTML reports and linked assets in the selected roots are kept.

## Status and limitations

Holla partition: 9/11 pass with two age-only state mismatches; the two paused candidates each passed two normal assertion runs. Showcase 59/59 and Tablepro 11/11 passed. Jackin's original partition was 9/10; the original test sent Space although the app handles Enter/Esc. The one-line Enter correction's focused test passed using the separate candidate fixture. Lifecycle's initial production-root run was 0/2 missing baselines; both new candidates passed exact producer checks against isolated fixtures with bypass unset. The previous five unmatched IDs remain unresolved; no removals are inferred. No approval or baseline acceptance is represented.

`SHA256SUMS` covers every file in this archive except itself. All hashes, selected candidate hashes, report-relative links, and fresh extraction are checked in the preservation validation.
