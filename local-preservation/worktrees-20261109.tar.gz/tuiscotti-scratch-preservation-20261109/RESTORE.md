# Restore instructions

Each worktree is an independent snapshot. Do not merge snapshots together. Restore into a clean checkout/worktree at the recorded `head`; do not overlay this data onto a directory containing user files.

For the selected worktree record in `manifest.json`:

1. Create a clean checkout/worktree at its recorded `head`.
2. If `patches.staged.patch.size_bytes` is greater than zero, apply the object at `objects/sha256/<patches.staged.patch.sha256>` with `git apply --index` from the repository root. Skip this step for a zero-byte patch: Git rejects an empty patch. This restores staged changes.
3. Replay each `files` record. For `action: delete`, remove the leaf path itself with `unlink` (it is safe to do this when it is already absent); never recursively follow or delete a symlink target. For `action: write`, create parent directories as needed and replace the leaf itself. For a regular file, write to a new temporary regular file in the same directory, set its mode on that temporary file descriptor, then atomically replace the destination. For a symlink, create a temporary symlink from the decoded `target_b64` bytes and atomically replace the destination. Remove an existing leaf symlink itself before replacement if the platform's replace operation requires it. Never chmod the destination path: chmod follows symlinks on many systems. The recorded mode for symlinks is metadata only; do not apply chmod to a symlink.
4. For each write, fetch bytes from `objects/sha256/<object.sha256>`. For symlinks use `target_b64` as the link target; for regular files write the referenced object bytes.
5. Verify with `git status --short --untracked-files=all` and compare paths/XY states with the selected `status_porcelain_v1` record.

The manifest records each base HEAD, branch/detached state, status including deletions, and per-path kind/mode/hash. Identical payloads share one SHA-256 object while retaining per-worktree metadata. Paths are relative to the selected worktree root and use JSON surrogate escapes where needed. `.audit` and Git-ignored files/build caches are intentionally absent. The `unstaged.patch` object is retained for audit; the archived final file snapshots are authoritative for restoring the working tree.
