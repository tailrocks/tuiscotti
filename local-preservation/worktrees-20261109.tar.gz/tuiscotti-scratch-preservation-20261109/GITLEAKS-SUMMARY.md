# Gitleaks scan summary

- Tool: Gitleaks 8.30.1
- Scope: all uncompressed, deduplicated payload objects, including staged and unstaged patches.
- Redaction: 100%. No match values are recorded here.
- Findings: 95 records, one rule category: `generic-api-key`.
- Source paths: `.github/velnor/task-execution-manifest-v1.json` and `vendor/zstd-sys/zstd/lib/common/xxhash.h`.
- Patch locations: unstaged patches for `allocation-proof`, `generator-ci`, `roundtrip-audit`, and `tool-lock-audit`.

These are scan findings only; this bundle preserves the captured local state and does not adjudicate the matches.
